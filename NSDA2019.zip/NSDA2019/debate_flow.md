# Debate night (ALEX vs RICKY)

## PRO

### fw: cmp to fiat

### Contention 1 freedom

​	China, Turkey

​	Tracking people is not good

​	Government control, stop, hurt

​	Freedom is core

> we need regulation
>
> stable coin bad
>
> > comparitive
> >
> > we need regulation: gov break social contract
> >
> > at volatile: risk of gov vs risk of vol
> >
> > inc the basic freedom
> >
> > gov can take money anytime
> >
> > > (like a public speech of 2 min?!)
> > >
> > > gov press
> > >
> > > freedom
> > >
> > > Arab spring



# CON

## Hacking 

> any form of exchange is vulnerable to hacking
>
> we need compare it with fiat (warrrant)
>
> government can sieze all money

## 51% attacking

74% hash power in China

> highly unlikely
>
> can't change previous transaction
>
> > china can
> >
> > new changing
> >
> > vergecoin? be hacked

## Quantum computer hacking

google has

> no point, process make crypto valueless
>
> more likely to hack a bank
>
> 





Cfq: my crypto acc is connected to G-mail, G-mail vulnerable to hacking?

Cfq: government control

Cfq: government: 0.000001% hack

at volatile: fiat more volatile, corrupt sys

at USD won't ...: no freedom

at china 51: gov not irrational

















# Debate night (YKPao) CON (LOSE)

# Rebuttal

## fw: impact



they mentioned they should not the cryptocurrency to use like the normal currency, so it means that we can't use cryptocurrency to use it in real life.  And they have no evidence to prove that 





they all think in the imagination with no standing logic and evidecne to support

## Contention 1 : no bias, target

**equal,corruption**

> no evidence!

AT: corruption

> crypto increase corruption by having anonymous system

​	Anonymous system is a main character of cryptocurrency

> evidence

In March 2018, Brazil’s corruption network – a newly discovered, multi-million dollar operation of government corruption has enhanced the way crimes are being committed in the country – cryptocurrency is being used in an attempt to cover tracks. According to media reports, the value of around 13.6 million USD between 2010 and 2015

equality

> they don't use it as normal currency

so they can't solve this problem -- 

> transferring centres

Transferring centres are opened by private , not by officials

Official: education, controls

Private: no controls

## Contention 2 : unbanked

can't access

> can't prove their main basic logic which is there are more and more people getting access to banks

> how many people have phones, how many people have 

> 







hypothesis, no supporting evidence

transferring around the world ==> a new point

| help the unbanked & inequality             |                                                |      |
| ------------------------------------------ | ---------------------------------------------- | ---- |
| acess to banks:<br>internet, phone, ×bank? | no logic, warrant<br />SouthAfrica, have banks |      |
|                                            |                                                |      |
| transferring centre                        | no answer<br>crypto worse                      |      |

| crime&illegal dealing&corruption          |                          |                                    |
| ----------------------------------------- | ------------------------ | ---------------------------------- |
| scam                                      | there are<br>huge impact | theft: low percentage, don't care? |
| terrorist: misunderstand                  | anonymous                |                                    |
| no rebuttal to corruption<br />give it up |                          |                                    |

| climate change |      |      |
| -------------- | ---- | ---- |
| drop           |      |      |
|                |      |      |
|                |      |      |

2%

5%

# feedback

don't repeat too much "no evidence"

even if people have phone, have account, why do they choose crypto rather than online banking

cryptocurrency won't be use?

 AT high transaction fee: 1 evidence 2 people prefer to try banks (-->3) stable&safety

Anti rebuttal energy: those green energy can be used for other things, not a good use of energy

at: bias, the people who are most benefited are people who have much money from the start, which is the white rich men

at: transparent: 



there are many kinds of cryptocurrency, and they wll use the most secure one, Monero















# SH YKPao AD PRO

## Rebuttal

### FW: a lot of things for con to prove

### Contention 1: not safety

Sub a: cheating, stealing, forget password

Sub b: benefit criminal			

Sub c: 51% hack

### Contention 2: efficiency

Sub a: energy

Sub b: hack

### Contention 3: volatility

Sub a: 

Sub b: countries ban

### Also: can't overthrow





## Constructive

### FW: compare



### Contention 1: safety



### Contention 2: help the unbanked

mobile financial account





fiat and centralized banking is main status quo

if a new things is better than the main status quo thing, then it is good. 

| safety           |                                               | impact |
| ---------------- | --------------------------------------------- | ------ |
| 51% attack       | no logic<br>only small coins<br />10 dollars? |        |
| anonymous        | traceable<br>                                 |        |
| cmp to bank      | banks are worse<br>3500                       |        |
| transaction hack | bank is worse (no answer)                     |        |
| password         | inc safety                                    |        |

| 3 poverty & volatile |                                                              | impact |
| -------------------- | ------------------------------------------------------------ | ------ |
| mobile finance app   | no specific example<br>Alipay need bank account<br>cryptocurrency can help,<br>crypto better than bank |        |
| volatile             | volatile benefit<br>give chance for poor to have more money<br>can't cause poverty |        |
| inflation            | not small amouns<br />Zimbabwe, Venezuela make poverty       |        |

| energy                    |              | impact |
| ------------------------- | ------------ | ------ |
| proof of steak, less code | no answer    |        |
| it will be less           | less bitcoin |        |
| renewable energy          | 80%          |        |













# SH YKPao MS CON

## Rebuttal

### fw: social development，economy

### Contention 1: corruption

> Rebuttal A: AT: trackable

​		1 Anonymous system

​		2 Monero. It is proved that Monero can't be tracked. 

> Rebuttal B: anonymous system of crypto cause more corruption

​       Anonymous system of cryptocurrency can make more corruption. When an officer sends 6 bitcoins to another for corrupting purpose illegally, crypto’s anonymous system can show like ”0x25a3 send 6 btc to 0x33e9”, but they never know who they are. They might know that it is corruption, but they never know who corrupts. Then people will be more corrupted, as no one knows if they corrupt. 

> evidence

In March 2018, Brazil’s corruption network – a newly discovered, multi-million dollar operation of government corruption has enhanced the way crimes are being committed in the country – cryptocurrency is being used in an attempt to cover tracks. According to media reports, the value of around 13.6 million USD between 2010 and 2015.

### Contention 2: hyperinflation

> Re1 cryptocurrency’s volatility is more fatal

​		Just as we’ve proved in our contention, crypto’s volatility is serious. Andy Bryant, chief operating officer of Bitcoin Exchange Europe, said, the bitcoin and cryptocurrency markets are relatively small, so market trends can cause huge price changes compared to other asset classes. Crypto is valuable just because people think they are, and how many people are buying it. If bitcoin crashes it can collapse the economy, Similar to a stock market crash, but there’s nothing to bailout cryptic. As many people are using it, people will lose their money, and nothing to bailout anything!

> Re 2 

> AT: zimbabwe

​		1 Zimbabwe's solution is USDollars, Zimbabwe actually ban crypto

​		2 Single case, dollar won't fall

### Contention 3 Quantum Computing, apdotable

quantum computing's existence is a reason that we SHOULDN'T choose cryptocurrency. 

*quantum computer will enable the few users who have them to censor transactions
and to monopolize the addition of blocks to the Bitcoin
ledger (known as mining). These parties could sabotage transactions, prevent
their own from being recorded or double-spend*. So, it means that cryptocurrency blockchain can







cf2: crypto, like Monero, is anonymous, and support crime. How can an anonymous thing be t

| framework                            |                         |      |
| ------------------------------------ | ----------------------- | ---- |
| they only mentioned one small aspect | we consider all aspects |      |
|                                      |                         |      |
|                                      |                         |      |

drop their point of "adapt", so it means they can't prove their own point after our rebut, so their contention doesn't stand.

| transparency<br>corruption & illegal dealing |                         |      |
| -------------------------------------------- | ----------------------- | ---- |
| 1 government control                         | decentralized           |      |
| 3 scams                                      | no solution             |      |
| 2 anonymous<br />not telling truth           | Monero<br>not trackable |      |

impact: crime, corruption

| hyper_inflation |                   |      |
| --------------- | ----------------- | ---- |
| 1 Zimbabwe      | Zimbabwe ban      |      |
| 4 volatility    | worse than dollar |      |
| 3 dollar        | can't fall        |      |
| 2 Brazil        | not decentralized |      |

volatility: money gone overnight bec of cryptocurrency

| climate          |                                              |      |
| ---------------- | -------------------------------------------- | ---- |
| 1 waste of paper | we can regrow trees<br>but can't regrow coal |      |
| 2 evidence       | they have no evi<br>2 celcius                |      |
|                  |                                              |      |

safe the world

## Feedback:











# SH Nord Angila DL Pro

## Rebuttal

## FW: social warefare

### C1: energy, pollution

### C2: crime

#### SUB a: TERRORIST

#### SUB b: crime dealing





## Constructive

### C1: safety

### C2 :  unbanked



| safety    |                                  |      |
| --------- | -------------------------------- | ---- |
| terrorist | misunderstand<br>can't be hacked |      |
|           |                                  |      |
|           |                                  |      |

| energy                     |                                     |      |
| -------------------------- | ----------------------------------- | ---- |
| renewable energy           | 75%, Anton Lucian BA<br>improve the |      |
| electricity energy         | energy consume less<br>             |      |
|                            |                                     |      |
| proof of stake             | no answer<br />minimize the code    |      |
| economy up (help unbanked) | and money an be used                |      |

| crime     |                                 |      |
| --------- | ------------------------------- | ---- |
| trackable | Fordham University<br>can trace |      |
| terrorist | they use cash                   |      |
|           |                                 |      |

| poverty |                     |      |
| ------- | ------------------- | ---- |
| afford  | 1 billion, less 50$ |      |
|         |                     |      |
|         |                     |      |







# SH SHFLS ZZ PRO

## Rebuttal

### FW: cmp

### Contention 1 illegal trading

### Contention 2 volatility

### Contention 3 environment



## Constructive

### FW: cmp

### Contention 1 safety

### Contention 2 help the unbanked





| safety&volatility       |                                           |               |
| ----------------------- | ----------------------------------------- | ------------- |
| cmp to centralized bank | bank: 3500 in 2019                        |               |
| volatility              | hyper_inflation                           | cause poverty |
|                         | volatility                                |               |
| quantum computing       | use it to encrypt<br />quantum hack banks |               |

key     help encrypted, safer

| crime     |                    |      |
| --------- | ------------------ | ---- |
| anonymous | Fordham University |      |
|           | silk road          |      |
|           |                    |      |

| environment      |                                                              |      |
| ---------------- | ------------------------------------------------------------ | ---- |
| renewable energy | 75%                                                          |      |
| China            | **80% of China’s Bitcoin mining operations were based in Sichuan – a province that** 90% |      |
| proof of stake   |                                                              |      |
|                  |                                                              |      |

| help  the unbanked |                             |      |
| ------------------ | --------------------------- | ---- |
| Countries banning  | South Africa<br />1 billion |      |
|                    |                             |      |
|                    |                             |      |





# SH YKPao TX PRO

## Rebuttal

### C1: energy

### C2: tech

### SA: hacking

### SB: no way to cover lost

### C3: scam







C1:  safety

C2: poverty

link to economy: get into poverty --> participate into cryptocurrency

don't accept: cryptocurrency exchange 



decentralized: misunderstand

impolite: they have follow up, but they refuse to let us follow up

| safety       |                                    |      |
| ------------ | ---------------------------------- | ---- |
| cmp to banks | 3500                               |      |
| scams        | small coins<br />10 dollar?        |      |
| refund       | decided by arbiters, and customers |      |

| convenience |                                          |      |
| ----------- | ---------------------------------------- | ---- |
| 10 minutes  | vs 2~3 days<br>no need to compeletly use |      |
|             |                                          |      |
|             |                                          |      |

| energy                 |                                            |      |
| ---------------------- | ------------------------------------------ | ---- |
| renewable energy price | hydro: 0.05<br>never explain<br>solar: 0.1 |      |
| proof of stake         |                                            |      |
| energy comsumption     | America 3 days of cars                     |      |

| poverty  |                                       |      |
| -------- | ------------------------------------- | ---- |
| internet | 1 billion have<br>abandon their lives |      |
|          |                                       |      |
|          |                                       |      |

they don't care 







# AI PRO Mrli deb

## CBA and long term

vs short term

## Contention1: error of machine and lose control

## sub A: lose control

self-learning

Rebuttal: they will not have dark thought because they don't have

stab heart: this is programmed by people, not own thought of AI. 

cf: yes/no, but question is wrong, so our opponent let us answer a false question

cf; environmnent; also a reason for us to develop, to make AI cleaner



## Contention 2: unemployment

AI can do everything: can they have great imagination? can they care us with great care? can

50% is only a prediction, with no exact evidence and logic to prove

**impact**:







Contention 1: 

work: jobless: collaboration, proved

tech: 

overthorow: only when they have own thought will they overthrow us, and ...

Hawking: imagination

Contention 2: 

employment:

1 decrease: every jobs: AI can't program ai, imagination? teachers? 

# Feedback

长期：长期包含短期

short term: 还要说明一下why short term is important

危险不能说我们不能控制，不一定，要明确指出一定是坏事

they concern because they aren't sure, but we know what it will be. It will have a bright future. ....

详细的东西需要简化

预测不reliable，要基于现状

遇到特别aggresive：do u dare to let me finish?

驳论不能是纯立论，更要有纯驳论
纯驳论要放在前面，后面再立论

不到万不得已，不要同意对面的东西



development: 还要再说一下how to development

没有thought: 听不听话

给大家一种潜意识，辩题转移

cf注意举证义务 

cf要救助一个问题向下讨论很深



this topic is about ... , while on this topic, our opponent have lots of misunderstanding on this point.

 