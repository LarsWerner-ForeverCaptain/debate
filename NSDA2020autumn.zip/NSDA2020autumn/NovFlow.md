# VS SH WFLA WW CON

# Rebuttal

## FW

def: poverty: lack of financial resources

welfare: financial support

pi: basic physical system

fw: faster, 

## Contention 1 Healthcare

vulnerable to diseases

700 million lifted out of poverty

turn poverty because of illness

more than 95% covered, decrease 29% for not receiving

cured

## Contention 2 Education

money to maintain education

tuition fees, lunch fees, etc.

can't afford

drop-out of schools

50% 20~30% suburbs

higher salary

## Contention 3 corruption

corruption common in projects

income decrease

# Constructive

## Agriculture & Aquaculture

> 1 not only agriculture solve poverty, no link, unclear

## Education

> 1 tuition fee
>
> 2 no increase on scores
>
> 3 enrolment low

# SUM/FF

## Clash 1 education

First, our opponent mentioned that there are not enough money to go to school. But first, they are mostly public schools, and tuition fee is not the main problem. The main problem is the overcrowded -- tuition fee high because there are too many students trying to get into school.

Second, we're the only side who provides enough care to the left-behinds, by building boarding schools. Boarding schools are needed, for there are over 60 million left-behinds, which can drop-out easily, and according to South China Morning Post, 2018, 34% of them considered suicide. Only building boarding schools solve the problem.

Third, our opponent provides no direct rebuttal towards our subpoint of online courses and vocational school. While in many schools, they don't offer subjects because there are no teachers availuable, and welfare cannot solve this. But infrastructure attracks more teachers, and online classes also solve the problem. Employment is the most important part to get out of poverty, while 90% of extreme poverty graduates can get jobs under vocational schools, so vocational schools also needed to be built in more areas. 

## Clash 2 healthcare

First, our opponent and we also have cards, mentioned that the welfare is quite good now. That means we have no need to increase our spending. 

Second, healthcare infrastructre lack is the main problem. About 650 million Chinese were left without access to a general practitioners in 2017. Our opponent said rural people should get to urban to get treatment, but this is only an unreal assumption. Many urban areas are located  very far from the city, and it cost too much to go away. Our opp is never trying to solve the high price problem, but we are using inf to solve it.

## Clash 3 corruption

First, our opponent said both side have corruption, which means they admit themselves that welfare corruption bad. In just on case, 400 million dollars, a third of pension fund corrupted

Second, we provided, corruption can have better development. Even don't buy, we are trying to solve, ... opponents don't ..

## Clash 4 rural production

First, they said we have no link. But we gave evi on both consumers and producers. Harvesting perios can be fasten by 1.5 months, and aquaculture production is tripled by using the system. According to Journal of Social Studies, it provides a source of income to the 15.9 million people which lives on aquaculture.

Also, the smart agriculture can be used to feed at least 1.4 billion poor and hungry people and reduce the high food price, and essential micronutrients have great impacts on common diseases.

# VS SH Pinghe HM CON

# Rebuttal

## FW

prioritize over

have sufficient & enough

saves more lives

## Contention 1 Diseases

### SA insurance

41.63% illness

480m lifted out of poverty

16% unable to medical expenses

300k yuan

insurance

### SB

doctors all in city

let poor people go to city

## Contention 2 VG

### SA Aging Population

rural pension

86 RMB per person

rural residents

120% higher pension needed

## SB disability

income under 600 yuan

social welfare maintain basic livelihood

social insurance

still a lot of don't get

# Constructive

## Contention 1 Smart Rural Production

> 1 climate, natural disaster, derigation
>
> not all people benefited

### SA Agriculture

### SB Aquaculture

## Contention 2 Education

> 1 tuition fee

### SA Boarding Schools

### SB Online Courses

### SC Vocational Schools



evi: free education

https://www.chinahighlights.com/travelguide/education.htm

Chinahighlights, the law of nine-yeear compulsory education, tuition free education



# SUM/FF

## Clash1 Healthcare

First, what really lacks is medical resources. There are 650 million Chinese left without access to a general doctor. The fewer, the more expensive. If we increase the resources, the expense will decrease.

Second, our opponent said that in their world, the only solution is to left poor people go to urban areas for medical care. But in our rebuttal, we mentioned that Medical Cloud infrastructure, which provide a much cheaper and better solution. Thus, infrastructure is much more effective in healthcare.

## Clash2 Vulnerable group

First, for the poor people, the current pension system is suffering from corruption. Poor old people can't get the real welfare, and increasing spending ineffective.

Second, the pension system has link with the jobs. More employment can solve the problem better. 90% employment vocational schools.

Third, for disablity, the most important part is let them go into the society. They can't get jobs or work badly is because there are not enough assistive support. We increase spending on assistive infrastrucutre, to let their life better and then they can work better. But  opp's solution is only giving them money and let them stay at home, which is not what disabled really wants.

## Clash3 rural production

https://tradingeconomics.com/china/employment-in-agriculture-percent-of-total-employment-wb-data.html

First, our opponent said that not many people can get benefited. But according to traiding Economics, the employment in agriculture is 25%, which means it benefits one-forth of the population, and mostly poor farmers. While also, we mentioned the data in our case, that 16 million people lives on aquaculture in China. Moreover, n the CGTN 2019 card we've mentioned, more than 1.4 billion poor and hungry people can be fed by this. Thus, it can benefit a huge amount of people alleviating poverty.

## Clash4 Education

First, for the tuition fee problem, According to Chinahighlights, the law of nine-yeear compulsory education required tuition free education. So, the main problem is not enough school and overcrowding, not tuition fee.

Second, our opp said giving voc school money is welfare. But no it isn't. Many low quality, and many poor area don't have. Need optimize it, and build high-quality. 

Third, online edu. Internet infrastructure, electronic devices in classrooms and schools. Problem: not enough rural teaches, subjects can't be taught

now:

# VS SH YKPAO ZC CON

# Rebuttal

## FW

urgency

die in short term, then long term

## Contention 1 pensions

elderly people needs pensions to survive

2020, 90b yuan

current pension not enough

CTGN, 60~70 trillion yuan, can cover pension

## Contention 2 disable people

1 working capability, still low income

2 mental disability 27million people in poverty

130b yuan, alleviate people out of poverty

## Contention 3 education

1 free-compulsory education, 2020

rural area

financial shortage

2 drop-outs of financial burden



# Constructive

## Contention 1 Smart Rural Production

### SA Agriculture

> 1 how many people improvished? no evi
>
> 2 no infrastructure
>
> > CGTN, the next generation and smartest farm will need to process large amounts of information, which can only be done with the help of 5G
> >
> > 5G penentration rate only  50%, need infrastructure

### SB Aquaculture

> no rebuttal

## Contention 2 Education

### SA Boarding Schools

> 1 don't improve scores
>
> 2 cost of education
>
> 3 private investment better

### SB Online Classes

> no rebuttal

### SC Vocational Schools

> 1 is welfare
>
> job training

# SUM/FF

## Clash 1 Vulnerable groups

1 elder pension

First, pension corruption make it much worse. 10.03 million yuan in just one case was stolen by corruption. That makes it ineffective.

Second, the better should be employment to make pension better. Vocational schools, built, 90% employment in extreme poverty area.

2 disabilities

First, our opponent solution is only give them money and let them stay at home. Disabled people wanted to get back into the society, and assistive infrastructures decrease barrirers, and provide them the chance to work.

Second, for mental disability, the assistive technology infrastrcutre can reduce the need for help, and have a greater chance of getting a job as we've mentioned in the card in our rebuttal. They can even work longer, and have more money income.

3 left-behind children

60million left-behind children are being forgotten by our opponents. according to South China Morning Post, 2018, 34% of them considered suicide, and they can be easily drop-out because they lack care. boarding schools is the only way out.

## Clash 2 Education

1 the tuition fee not the main problem. the worst part is the school quality and teaching resources, that are not enough in rural areas. they can reduce the cost for schools if we build online education infrastructure some schools don't even offer subjects because they can't get the teachers for these subjects. while our online education can help solve this problem. while our opp gives no effective and direct rebuttal towards this, we win on this point.

2 broading schools: effective, left-behinds

3 vocational education: there is no high-quality in area. need infrastructure

vocational training: infrastructure basis

 According to BW Education, a large part of vocational skillful costs are towards physical infrastructure - training centers. All these leases must be structured as conditional on training outcomes.

## Clash 3 Agriculture & Aquaculture

https://tradingeconomics.com/china/employment-in-agriculture-percent-of-total-employment-wb-data.html

First, Our opponent said they are not the majority. According to the traiding economics, the employment in agriculture percent is about 25%, which is a very high proportion in poverty.

Second, we have cards, telling us that it is mainly casue by the high food price. the high food price can decrease only if we have more production, which can be realized by aquauclture and agriculture

Third, our opp completely ignore our aquaculture point. we can provide more mricronutrients to those who lack it, and for the 16 million who rely on aqauculture, they can get out of poverty only by this. So, on this point, we totally win.



# VS FS Huaying LL CON 

# Rebuttal

## FW

insufficient

1 for poor people

2 stable impact

## Contention 1 HC

## SA Chronic illness

economic burden --> welfare

60% all households at least one patients, can't afford

22.8%

### SB Malnutrition

51% suffer from malnutrition

### SC medical debts

44% 

house insurance

## Contention 2 Education

### SA vocational education

vocational training programmes --> 90%

decent education

get better jobs

### SB college education

drop-out, secondary education

social inequality





## Contention 3



# Constructive

## Contention 1 Rural production

### SA Agriculture

> 1 not biggest problem
>
> most crop are raise with ... fertilizer, overuse it
>
> 2 ecosystem degration

### SB Aquaculture

> 1 no link
>
> 2 not infrastructure

## Contention 2 education

### SA Boarding

> 1 no correlation between resources & increase academic performances
>
> 

### SB online

> 1 can not pay internet, no affordable internet
>
> 2 no smartphone
>
> 3 lack of budget

### SC Vocational

>1 job training needs welfare

# SUM/FF

## Clash 1 rural production

First, our opponent said their own way to reduce malnutrition and solve the hunger problem is to import goods. But first, the rural transportation is not developed, thus better infrastructures need to be built. Second, we provided a cheaper and more effective solution, by applying smart agriculture, aquaculture and rice-fish farming system. Third, our opponent's plan about malnutrition is flawed proved in our rebuttal, which can cause fatal problem.

Second, our opponent said fertilizer and drugs are overuse, but in our case, we mentioned that, it can reduce fertilizer by 39%, and reduce need of drugs. And also, they mentioned ecosystem polluted. But climate-smart-agriculture is the one which reducing environemtal ppollution, and we smartly use the land resources to reduce degration environmental harm.

For aquaculture, the smart aquaculture needs the 5G infrastructure.

https://tradingeconomics.com/china/employment-in-agriculture-percent-of-total-employment-wb-data.html

Third, our opponent mentioned it's not alleviating, the impact is small. But for agriculutre, it can solve the hunger of 1.4 billion poor and hungry people, 25% of people which lives on agriculutre, 15.9 million who lives on fishery farming in poverty, and those who suffer from malnutrition.

## Clash 2 healthcare

First, we've succesfully proved that healthcare resources are lack. There are 650 million Chinese left without access to a doctor.

Second, medical insurance enough now, don't need to increase spending. the government clain 95% of peope living in rural areas coverd by health insurance. for the rest of them, healthcare resources are lack too much

Third, infrastructure solves illness. The Medical cloud can make sure that people in rural area can get access to high-quality doctors.

## Clash 3 Education

First, many students are forced to be kicked out of the schools. Our opponent admit the overcrowding, while China have tens of billions of people, and it can only show that the spending is not enough. While we can also prove that education spending is effective. That will bring the home of 60 million left-behinds children, and and bring the 90% of employment in both urban and rural area.

Second, our opp said lack affordable internet. That's why more affrodable infrastructure should be build to support rural area.

Third, vocational scools. need infrastructure. low quality

# VS SHFLS LL CON

# Rebuttal

## FW

welfare: gov programmes provide welfare

pi: public works in a country (soft and hard)

not only workforces: vulnerable groupd

## C1 Left-behind jobs

lack of interactions

2015, NGo, 70% suffer from mental health issue, suicide

drop-out rate

volunteers, children clubs

fund of left-behind clubs

higher-salary

## C2 Transitive poverty of covid-19

91.7%

ended w/o career

380k fell into poverty

unemployment welfare program

only little are covered

## C3 Job training

vocational taining welfare

over 10m people out of poverty

6b yuan training fund

7m people

invest in training fee

help find a job

## C4 disabled

can't work

disabled population get help

# Constructive

## 1 rural production

### SA smart agriculutre

> pollution

### SB promote aquaculture

> 5G don't increase

## 2 Education

### SA Boarding schools

> increase spending don't increase performance

### SB online classes

> no increase spending
>
> already covered by internet

### SC Vocational schools



# SUM/FF

### 1 vulnerable groups

First, our opp mentioned about disabled people. But now the major question is, the disabled people can not raise the living standards using the money they have now. According to ICED facility, Much of the world’s infrastructure is not designed in an inclusive way, creating unnecessary barriers for people with disabilities. They can not get into the society easily, and can not have their respect in the society.

Second, our opp mentioned about left-behind children. Our opp said that there is not enough funding for programmes. But the boarding schools don't need such programmes, for it itself can be the home of left-behinds. According to SCMP, boarding schools is a solution to the left-behinds. They can get the care by the teachers in boarding schools. While in many rural areas, the boarding schools are not built in high-quality. 

## 2 Jobs

First, our opp mentioned the job training the programme. But pulic infrastructure is the basic of vocational education. In adult According to BW Education, a large part of vocational skillful costs are towards physical infrastructure - training centers. All these leases must be structured as conditional on training outcomes.

Second, vocational schools needed for younger education. Our opponent have no solution to the people still not in adultsent. Vocational schools only way out, providing the 90% employment for them. And tuition fee not the question. According to OCED, Vocational Education Schools are largely covered by national scheme, and some even free.

Third, our opp mentioend the transitory poverty, covid19, employment. jobs are created. our opp said sth about skills. according to brookings, 2015, infrastructure jobs are long term, have relatively low barriers to entry, and consistently paying up to 30 percent more to low-income workers.

## 3 Education

online classes: not only internet, infrastructures in schools, e-campuses

boarding schools: dormitories, expanding

**teaching quality** : online education

neccesary: still many schools can't offer subjects, e-campusses not built

## 4 Rural productionb

First, our opp said individuals can't earn

triple production

Second, our impact of 

1.4b poor and 

malnutrition

third, 5G : CGTN card 

Third, environment. Smart agrri more environemtnal friendly

