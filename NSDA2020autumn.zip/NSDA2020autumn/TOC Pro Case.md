Resolved: In China, increased spending on welfare programs is more effective at alleviating poverty than increased spending on public infrastructure.

# PRO

## Definition

## Framework

## Contention 1 Vulnerable Groups

## Contention 2 Education

### Subpoint A Academic Education

### Subpoint B Vocational Education

## Contention 3 Gender Inequality

## Contention 4 Healthcare

