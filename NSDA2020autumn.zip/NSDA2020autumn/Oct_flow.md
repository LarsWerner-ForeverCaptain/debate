# VS SH Huili XT CON

# Constructive

## FW: living standard

> welfare --> more money
>
> > education:
> >
> > even if they have money, those left-behind children is still lack of care, and teachers are still not enough
> >
> > infrastructures needed

## Contention 1 Smart Agriculture

> not infrastructure
>
> > 5G buildings
> >
> > there are only mentions 98% internet rate, but some of them are much not enough for smart agriculture
> >
> > CGTN, process large amounts of information, need of high quality, 5G
>
> 40% land mitigration
>
> > mitigration are caused because there are not enough money in fields
> >
> > while we are giving them opportunity in the field, so they don't have to risk and migrate
>
> roads
>
> > major clashes
> >
> > the first speakers said there is not enough transportation, but the second speaker is saying that there is the 99% road penetration rate
> >
> > building public transportation, agriculture production rise

## Contention 2 Education

### Sub A Boarding Schools

> teachers not facility
>
> we are building boarding schools to let those poor kids have better education
>
> and we are building internet infrastructures for them to access to good education resources

### Sub B Online classes

## Contention 3 Jobs Creation

> diminishing jobs
>
> hiring workers do nothing a year
>
> new infrastructures, job loss

# Rebuttal

## Contention 1 Health Insurance Welfare

main urban workers

3300 person average

He Wenjiong, retired workers, 20 times more

cover 70% of medical cost

medical gap --> medical in debt city (10%)

deeper into poverty

2017, 45% of poor people poverty

70% burden

John et al, 2019, medical debt 60% ~ 70%

>1 infrastructure needed
>
>only 3 beds and 1 doctors per 1000 population
>
>> need money to afford: 
>>
>> 1 infrastructures make medical care less
>>
>> 2 now even with money, poor people can't go to hospital because medical resources  are too less
>
>2 Infrastructure better
>
>6.7 million housholds
>
>3 welfare don't help
>
>3.4 yuan

## Contention 2 employment ensurement

CNN2020, covid 19, urban unemployment rate

number to 80 million

5 million lost jobs

97% of unemployed don't have insurement

> 1 we need to increase jobs opportunity
>
> agriculture job increase, basic infrastructure create jobs
>
> boost economy by own hands

## Contention 3 retirement pension

1980s

new pension  system

rural vs urban pension

> not only giving money
>
> our opponent is giving money to all poor people all the life, and they themselves don't work, but lie under the welfare

impact

1.4 billion

1/3 children

60 m left behind

90% rural residents

all rural school's teaching quality

student's career

millions of jobs

30% increase in salary

much more healthcare resources



According to V setts Petakaur from the university of Columbia



# VS HZ Basis ZA CON

# Constructive

fw: short timeframe

## C1 Agriculture

agriculture not main reason poverty

> upward of 90 to 99 percent of China’s poverty population either lives in or comes from rural areas. As agriculture is the main occupation in rural area
>
> impact: reduce fertilizer cost by 39%, increase harvesting periods by 1.5 months

## C2 Education

Drop out

### SB online

salaries in rural areas too low --> welfare solves

> online better
>
> much more resource

## C3 Jobs Creation

unemployed

not to poverty

high skills

# Rebuttal

fw: feasible, cost-effective urban

## 1 Infrastructure fails

### 1 corruption

CSIS, corruption

broke down, injured

### 2 high cost

inc spending --> economy worse

wasting money

Wang, 9.4 trillion RMB

## 2 Education

lower than 1k RMB income

financial burden

25k

63%

drop out

poverty alleviation important education

## 3 Healthcare

health insurance

cancer

low productivity

corona virus



rural & urban

## Clash 1 Education

### Rural Education

we've give both two solutions to rural education

we build boarding schools for those left-behinds, and the studying quality is much better in boarding schools. study by Harvard economist, low-income kids had significantly higher scores

online education: online education better than giving welfare to rural teachers

1 teachers are soft infrastructures

2 better resources, qualified and good teachers in city, to solve teaching quality problem

### Urban Education

1 boarding schools. evidence mentioned, better scores for them

2 mainly caused by school overcrowding

public schools are mostly free. they can't and need much money to get into these schools are because of overcrowding. infrastructure is the only solution

## Clash 2 Healthcare

1 healthcare resources needed

even with money, can't enoy healthcare

3 beds, 1 doctors / 1000

2 welfare ineffective

## Clash 3 Jobs

1 opponent no solution

2 30% more income to poor workers

solve both urban and rural poverty

## Clash 4 high cost and corruption

> Kuhn 2016 (Lena Kuhn, PhD student at the China Research Group of the Leibniz Institute of Agricultural Development in Transition Economies (IAMO), Dr. Stephan Brosig, agricultural economist, senior researcher in the Agricultural Markets Department of the Leibniz Institute of Agricultural Development in Transition Economies, also coordinator, IAMO China Research Group, and Dr. Linxiu Zhang, Professor, and deputy director, Center for Chinese Agricultural Policy, Chinese Academy of Sciences, “The Brink of Poverty: Implementation of a Social Assistance Programme in Rural China”, Journal of Current Chinese Affairs, 2016, first published online April 1, 2016, https://doi.org/10.1177/186810261604500105, https://journals.sagepub.com/doi/full/10.1177/186810261604500105)

Corruption in welfare also bad: corrpution exclusion errors were mentioned in 38 percent in the research 

high cost: our opponent said infrastructure cost money, but 

## Clash 5 Agriculture

1 high skills: our opponent is misunderstanding them all. farmers know agriculture well because they works them all life. the only knowledge need is being familiar with the field

# VS SH YKPao CY CON

# Constructive

## Contention 1 Smart Agriculture



## Contention 2 Education

inc spending \neq good performance

school resources 

## Contention 3 Job Creation

1 no knowledge

2 job losses

3 highly skills

# Rebuttal

fw: vulnerable group

## Contention 1 lives

### SA food & water supplies

underastronished

education

6.5m beneftied from programme

### SB healthcare

extreme poverty

51.63% illness 

60 m one patient

can't afford expensive

disease

## Contention 2 education

rural & urban

### School lunches

malnutrition

shorter

development

good nutrition



# Summary

First, there's one thing needs to be explained.

In all our opponents' contention, they are only trying to prove that it is good to put money on that, but didn't prove that we should accelerate and increase this money spending. In order to get their so-called benefits, we only need to maintain or even reduce our spending now with no need to increase. 

And also, all our opponents' point are based on infrastructure. W/o enough food, or healthcare resources, or schools, or education, or jobs, they can never get out of poverty. While we're the only side solving this problem.

Thus, we're winning based on this.

## Clash 1 FW

we're aiming to alleviate whole poverty, and poverty is by raising all's living standard.

## Clash 2 Education

we're not only increasing educational resources

we're also caring for those poor rural kids, like left-behinds

the 60m left behinds 

According to SCMP, 34% of left behinds considered suicide

they can go to shcool, no qualified teachers (online resources)

## Clash 3 Food & Neccesities supply

1 the food welfare is already carrying out, no need to increase spending

2 our opponent give no direct rebuttal towards our contention 1 about smart agriculture

we're talking about the usage in technology including 5G internet in agriculture and increase the agriculture products

## Clash 4 Healthcare

1 not rejecting, but increase spending

2 expensive because no resources

3 whole life

## Clash 5 Jobs



# VS HZ Basis ZA

