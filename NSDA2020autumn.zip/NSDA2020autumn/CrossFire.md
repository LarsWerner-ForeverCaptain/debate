# Con CF

## AT Job Training

**(Covid-19)** According to the diplomat, after covid-19, at least 20 million new jobs are needed. Do our opponent have cards to prove that after covid-19, we still have plenty of jobs as covid-19 caused a huge job loss?

## AT Pension

**(False distribution & Cost too much)** Why is the spending on a flawed pension system and worsen the economic spending and losing billions of money more effective than simply reform it?

## AT Jobs training

**(vocational schools)** 

# Pro CF

## AT Teaching Quality

**(Teachers Welfare) **According to CLB, only 40% of rural teachers are getting the social insurance coverage, and half of rural teachers failed to obtain their salaries in full and on time. How can our opp attract teachers and teaching quality without increasing welfare?

## AT Economic Benefit

**(Cost overruns)** Why is infrastructure economic beneficial when three-quaters suffered cost overruns and the total cost overruns have equalled one-third of China's $28.2 trillion debt?

## AT Jobs

**(Jobs enough)** What is the purpose of creating more jobs instead of training them when there are huge jobs vacancy, for example, according to Forbes 2020, 78% of companies in Shanghai don't have enough workers.

**(Low income)** How is building more infrastructure and creating unsuitable jobs increase the income of 65 million working poor?

## AT Education

**(Drop-out)** How can they enjoy the so-called high-quality education in high school when 60% of the rural students dropped out in middle schools because of the cost?

## AT Migrant & Remittance

**(Poor employment)** Where does the money for remittance to migrant workers' rural families come from, when they themselves don't have enough money, are in vulnerable employment and only 22% of them have insurance?

## AT Electricity

**(Inherency)** What is the meaning of increase spending on electricity when it has reached a 100% access rate two years ago?

