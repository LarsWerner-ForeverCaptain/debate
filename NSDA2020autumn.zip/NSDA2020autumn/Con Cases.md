Resolved: In China, increased spending on welfare programs is more effective at alleviating poverty than increased spending on public infrastructure.

# CON

## Definition

Welfare refers to **government** programs that provide financial or other aid.

> https://www.investopedia.com/terms/w/welfare.asp

Public Infrastructure includes soft, hard and critical infrastructures.

> https://corporatefinanceinstitute.com/resources/knowledge/economics/public-infrastructure/

## Framework

Poverty alleviation is not only about having money but also about using money and raising living standard. We also need to prevent people from getting back into poverty. Whichever side is more effective at that wins this debate.

## Contention 1 Agriculture

### Sub A Irrigation

In rural area, irrigation efficiency is only 0.55,, much lower than the level of developed countries at around 0.7, and only 48% of irrigated areas have water saving technologies <sup>53</sup>, causing low production. First, according to FAO, the most important reason for that is insufficient funds to irrigation facilities. <sup>54</sup> Second, the lack of water resources can be solved by infrastructures, for according to FAO, less than 30% of groundwater resources in China were efficiently used. <sup>55</sup>  As according to Asian Development Bank, a 1% increase in irrigation results in a 1.13% drop in poverty <sup>56</sup>, more spending is needed for poverty alleviation.

### Sub B Precise Agriculture

The usage of big data and 5G in precise agriculture increase income and production. In Qingyuan, after the 5G agriculture project, the working income of each poor household increased by 57 thousand dollars. According to CGTN, smartest farm will need to process large amounts of information, which can only be done with the help of 5G. <sup>[22]</sup>. But according to China Daily, the 5G penetration rate is less than 50%. <sup>[23]</sup> 

According the World Bank, about 78% of poorest people rely on agriculture, and 65% of poor working adults made a living through agriculture. <sup>51,52</sup> Thus it is more effective to increase spending on agriculture infrastructure.



51 https://www.worldbank.org/en/news/feature/2014/11/12/for-up-to-800-million-rural-poor-a-strong-world-bank-commitment-to-agriculture

52 https://www.worldbank.org/en/topic/agriculture/overview

53 https://www.chinawaterrisk.org/resources/analysis-reviews/8-reasons-to-invest-in-irrigation-in-china/

54 http://www.fao.org/3/X5647E/x5647e0a.htm

55 https://www.bbc.com/news/science-environment-27978124

56 Ali, Ifzal. “Infrastructure and Poverty Reduction - What Is the Connection?” Asian Development Bank, Jan. 2003.

57 https://borgenproject.org/tag/quingyuan/



## Contention 2 E-Commerce (don't use)

In rural areas, it is often difficult to sell products. But some of China’s most impoverished areas have been finding new growth through e-commerce sites, according to the latest report from the Alibaba Poverty Relief Fund, and livestreaming has been an important driver of rural sales in the past few months. In just one event in July, it helped sell over 150 thousand units of agriculture produce. <sup>[2]</sup> Pinduoduo saw the order value of sales soar over 200 percent and expected the number to top 120 billion yuan. <sup>[9]</sup>

According to an official report E-Commerce in China, till 2017, online retail sales in rural China increased  to 1.2 trillion, a compound annual growth rate of 91%. And the potential for continued growth remains strong. <sup>[3]</sup> With E-Commerce, the sales of rural products increase, and thus alleviate poverty from the root.

The E-Commerce strongly relies on internet. But the internet coverage, according to Nanjing Marketing Group, the rural internet penetration rate is only 18.5%, and only increase spending in building internet infrastructure can solve the problem <sup>[10]</sup>. To make exchanges easier, increase spending on public infrastructure is an important step to alleviate poverty.

## Contention 3 Education (need changes)

### Sub A Boarding School (0'35'')

According to UNECO, boarding schools can be a means of socializing children coming from rural areas, and  for families which can't provide study environment or even without electricity, boarding schools can offer a better study. <sup>[12]</sup> A 2012 study by a Harvard economist found that low-income kids in one such boarding school had significantly higher scores than others.<sup>[13]</sup> 

According to China's National Plan, Establishment of rural boarding schools shall be accelerated, with priority given to the needs of the 60 million left-behind, and the dormitories should be expanded. <sup>[14]</sup> The infrastructure building is now in urgent need in order to help more children, so increasing spending should be put on boarding schools building and expanding.

### Sub B Online Classes

There are less teachers that are willing to teach in rural areas. According to China News Service, the amount of rural teachers dropped from 4.7 million to 2.9 million in 2018. <sup>[15]</sup> And some schools don't even offer subjects because they can't get the teachers for these subjects. This can be solved by online classes. Online classes are taught by experienced teachers based in cities. Electronic devices should be built in classrooms to get access to those teachers. Then the teachers from the cities can taught the whole class at the same place.

While the electronic devices coverage in schools is not enough now. According to the report by MOE, there are 18 thousand schools which do not meet the need, and for some provinces, there are only 58% schools which meet the basic need. <sup>62</sup> 

62 http://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/s5987/201805/t20180510_335564.html





## Contention 4 Jobs Creation (1') (don't use)

As more infrastructures will be built, more workers are needed, and also many jobs will be created to maintain the public infrastructures. And more jobs are stable and available because of the built infrastructures. According to FHWA, more than 25,000 jobs are created pre billion dollars spent on highway.<sup>[18]</sup> And according to China Daily 2019,  in the belt and road infrastructure projects, 88 million jobs are expected to be created by 2027. <sup>[19]</sup> The poor can easily get jobs and earn much, as according to brookings, 2015, infrastructure jobs are long term, have relatively low barriers to entry, and consistently paying up to 30 percent more to low-income workers. <sup>[20]</sup>

Employment is one of the most important way to alleviate poverty. Only with jobs, the family can have a stable income, and prevent them getting back to poverty. While welfare is doing the opposite thing. According to the Heritage Foundation, welfare recipients lose welfare benefits when income grows, and they do not work as they find it more profitable to remain wards of the state. <sup>[21]</sup> While also, welfare can not help anyone to get a job. Our opponent do not have a way to decrease the unemployment and solve the poverty. The best form of welfare is a job. The increasing spending on welfare discourage job seeking and is ineffective, while the most effective way is to create jobs.



## Contention 5 Sanitation and Water supply

According to WHO, unsafe water and poor sanitation accounted for 62 thousand death and 2.9 million life disability in China. <sup>57</sup> Thus water supply and sanitation is necessary to alleviate poverty.

First, water supply. Poor rural area lack water supply. 35% of rural population in China still do not have access to improved water supply, and 30% of water withdrawals are lost because of aging water supply infrastructure. <sup>58,59</sup> 

Second, for sanitation, only 15% of rural sewage is properly treated, and the penetration rate of rural sanitary remains lower than 50%. <sup>60,61</sup>  And poor sanitation contributes to childhood stunting and debilitating diseases, which trap them in poverty. <sup>62</sup> 

While the increasing spending is going to solve them. According to the World Bank, 2020, in Sichuan, nearly 235 thousand residents are expected to benefit from the improvement. <sup>60</sup> And it also create jobs, as according to UNESCO, every 1 million dollars in expanding water supply and sanitation network would directly result in 10 thousand jobs creation, which according to the World Bank, is simple that anyone can operate and maintain. <sup>59</sup> 

57 https://www.who.int/bulletin/volumes/90/8/11-098343/en/

58 https://en.wikipedia.org/wiki/Water_supply_and_sanitation_in_China  https://washdata.org/sites/default/files/documents/reports/2017-06/JMP-2015-Report.pdf

59 https://en.unesco.org/news/water-drives-job-creation-and-economic-growth-says-new-report

60 https://www.worldbank.org/en/news/press-release/2020/03/03/innovating-water-and-sanitation-services-in-chinas-rural-areas

61 https://news.cgtn.com/news/2019-11-18/How-the-Toilet-Revolution-is-changing-China-LH2SCXCemQ/index.html

62 https://www.worldbank.org/en/news/press-release/2017/08/28/millions-around-the-world-held-back-by-poor-sanitation-and-lack-of-access-to-clean-water



## Contention 6 Tourism

Tourism to rural area is becoming popular. According to official report, last year, rural areas received 3.2 billion tourists, generating a revenue of more than 850 billion yuan. <sup>63</sup> Poor rural regions can easily earn money from tourism sites establishment. First, tourism create jobs. According to NRTDP, it is predicted that the tourism will promote over 36.8 million jobs. <sup>64</sup> Second, tourism reduce education fee. In the KAFRED project because of tourism revenue (spent on schools) there, parents pay about 50% less for fees. <sup>65</sup> 

While current spending is not enough. According to Global Times, 6 million people in eight ethnic minorities provinces which have great potential for tourism are in poverty. <sup>67</sup> And according to Travel Biznews, China listed 680 villages to plan to promote rural tourism. Increase spending is needed to complete the plan and alleviate poverty.



63 http://en.people.cn/n3/2020/0515/c90000-9690953.html

64 https://www.researchgate.net/publication/257704914_Rural_tourism_development_in_China_Principles_models_and_the_future Rural Tourism Development in China: Principles, Models and the Future WANG Ling-en1,2, CHENG Sheng-kui1, ZHONG Lin-sheng1*, MU Song-lin1,2, DHRUBA Bijaya GC1,2, REN Guo-zhu1 

65 https://bigoditourism.com/about-kafred/

66 https://www.globaltimes.cn/content/1163662.shtml

67 https://www.globaltimes.cn/content/1163662.shtml



## Contention 7 Vocational Schools Infrastructures

Vocational schools teach students technical skills required to complete certain jobs, like plumbing, car mechanic, air-conditioner repair, etc. The average employment rate of vocational school students has exceeded 95 percent, contribute to 70% of the fresh workforce. ^[68]^ Infrastructures like physical, digital infrastructure and quality of teachers, according to business world, are needed. While the schools need funding. According to China Youth Daily, 54.4% respondents think vocational colleges lack government support and funding. ^[69]^ To solve this problem, the government made a three-year action plan published on sept, 2020, vocational schools should be optimized, and more high-quality vocational schools must be built in poverty stricken areas. <sup>29</sup> To complete the plan, increase spending is needed.



68 http://www.chinadaily.com.cn/a/201902/19/WS5c6c0593a3106c65c34ea2ed.html

69 http://zqb.cyol.com/html/2015-05/25/nw.D110000zgqnb_20150525_1-07.htm

70 http://bweducation.businessworld.in/article/Importance-Of-Infrastructure-For-Vocational-Skilling/07-02-2019-166967/



## References

1 The Economist 2014 https://www.economist.com/china/2014/06/13/the-hungry-and-forgotten

2 "e-commerce still the key tool in poverty alleviation in China", Christine Chou, Alizila, 2019, https://www.alizila.com/e-commerce-still-key-tool-in-poverty-alleviation-in-china/

3 World Bank, Xubei Luo https://blogs.worldbank.org/eastasiapacific/e-commerce-poverty-alleviation-rural-china-grassroots-development-public-private-partnerships 
E-Commerce in China, 2017, http://images.mofcom.gov.cn/dzsws/201807/20180704151703283.pdf

4 IoT Agenda, Margaret Rouse, https://internetofthingsagenda.techtarget.com/definition/smart-farming

5 The Word Bank, Urban Population, https://data.worldbank.org/indicator/SP.URB.TOTL.IN.ZS

6 Wall Street Journal, https://www.wsj.com/articles/BL-CJB-1817
https://borgenproject.org/10-facts-about-rural-poverty-in-china/

7 Food and Agriculture Organization of the United Nations, 2018, Director General Qu Dongyu “Agriculture must get smarter to end poverty and hunger” http://www.fao.org/director-general/news/news-article/en/c/1262624/

8 Nanjing Marketing Group, Tait Lawton, https://www.nanjingmarketinggroup.com/blog/rural-chinese-internet-usage-2011_10_27

9 Xinhua Net, 2020-01-13 http://www.xinhuanet.com/english/2020-01/13/c_138701286.htm

10 Nanjing Marketing Group https://www.nanjingmarketinggroup.com/blog/rural-chinese-internet-usage-2011_10_27

12 https://unesdoc.unesco.org/ark:/48223/pf0000139720

13 https://scholar.harvard.edu/files/fryer/files/seed23.pdf https://www.dallasnews.com/news/education/2018/01/15/could-a-boarding-school-experience-help-kids-living-in-poverty-a-dallas-businessman-says-yes/

14 Outline of China’s National Plan for Medium and Long-term Education Reform and Development (2010-2020), http://ncee.org/wp-content/uploads/2016/12/Sha-non-AV-5-China-Education-Plan-2010-2020.pdf

15 China Daily HK, Liu JIantong (inspector in the ministry's department of teacher education) https://www.chinadailyhk.com/articles/135/54/119/1551242941750.html
Yahoo News, 2018, https://sg.news.yahoo.com/china-boost-broadband-speeds-rural-133439759.html?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAAthK9D05s2G91FhI8HorzNZ63meF0TjxqOgr4ugM_-FpsRxTmpTT4P_VARykVEbE7_OPftAypEAjRO85UMwmNXcGu2uj3wQCTummT2Dp5L9LtLQAxw3g-uR84dNGNYaIB14d1JXixrUHV-9cOVKPcHcN8fLQmyUKAFoHAVv9JiO

16 SCMP, https://www.scmp.com/news/china/society/article/2129821/could-online-classrooms-be-answer-teacher-shortage-rural-china

17 Infectious Diseases of Poverty, 2020, published January 30, 2020, https://doi.org/10.1186/s40249-020- 0626-5, https://link.springer.com/article/10.1186/s40249-020-0626-5) 

18 FHWA, https://ops.fhwa.dot.gov/freight/freight_analysis/highway_ops/hiway_ops2.htm

19 Zhong 2019 (Zhong Nan and Ren Xiaojin, 2019-07-22, "BRI to cause boom in project management jobs," China Daily, https://www.chinadaily.com.cn/a/201907/22/WS5d351735a310d830564003e1.html)

20 Brookings, 2015, https://www.brookings.edu/research/expanding-opportunity-through-infrastructure-jobs/

21 The Heritage Foundation's Center for International Trade and Economics, Patrick Tyrrell, 2015, https://www.heritage.org/welfare/commentary/many-who-are-trapped-welfare-dont-apply-jobs

22 CGTN, Dec 2019, https://news.cgtn.com/news/2019-12-13/Feeding-1-4-Billion-Smart-farming-in-China-s-big-grain-warehouse-MohBFcaajK/index.html

23 China Daily, 2020, http://www.chinadaily.com.cn/a/202003/18/WS5e71f83ca3101282172802d2.html

25 https://www.was.org/article/Intelligent-aquaculture.aspx#.X6VELYgzYuU

26 https://english.cw.com.tw/article/article.action?id=2563

27 Palanca-Tan, Rosalina. "Aquaculture, poverty and environment in the philippines." The Journal of Social, Political, and Economic Studies 43.3/4 (2018): 294-315. http://search.proquest.com/openview/579b706e97854d55896ccd84cc6a375b/1?pq-origsite=gscholar&cbl=22044

28 **De Silva,** Sena S., and F. Brian Davy. "Aquaculture successes in Asia: contributing to sustained development and poverty alleviation." Success stories in Asian aquaculture. Springer, Dordrecht, **2010**. 1-14. http://library.enaca.org/emerging_issues/success_stories/success-stories-asian-aquaculture.pdf#page=13

29 Ministry of Education, 2020/09/16, http://www.moe.gov.cn/srcsite/A07/zcs_zhgg/202009/t20200929_492299.html

30 Xinhua Net 2019, Vocational education helps with poverty alleviation in China: report http://www.xinhuanet.com/english/2019-11/29/c_138592951.htm

31 https://edition.cnn.com/2008/WORLD/europe/12/09/starvation.united.nations/

32 http://english.www.gov.cn/premier/news/2019/04/30/content_281476637627986.htm

33 http://www.ipsnews.net/2017/06/asia-pacific-farming-rice-fish-together-reduce-poverty/

34 http://www.fao.org/fishery/facp/CHN/en