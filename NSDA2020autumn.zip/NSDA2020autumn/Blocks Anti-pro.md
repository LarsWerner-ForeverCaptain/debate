# Blocks Anti-Pro

### AT Children

###### 1: Many children problem are caused by malnutrition

The way to get our future generation better is to go through our smart agriculture program. For the reason why the poor kids are considered stupid is for the the lack of nutrition. Our evidence shows that A third of children in poverty have iron deficiency which can stunt brain development , and the only way to solve this problem is to increase the growth of agriculture and stop the hunger and malnutrition. And the only way to solve this problem persistently is to have greater agriculture by increasing spending of infrastructure.

### AT Education

###### 1: Education is caused by school overcrowding. We can solve this. (2) Anti-rebuttal

There is only one acceptable solution to the problem of school overcrowding: the construction of new and permanent schools.  Larger classes in the upper grades, more temporary and portable classrooms, the reorganization of spaces meant to enrich children's educational experiences into classrooms, building new schools with modular units, and multi-track year round schooling. Although all of these responses seem to temporarily "relieve" what is obviously an enormous problem, each has been shown to have negative effects on children's learning.  Infrastructure can do this, better.

###### 2:  Vocational education(1)

We can provide a sustainable vocational education. China launched a program to establish 100 quality schools for training talent for its rural vitalization within two years. The expansion of higher vocational colleges this year has opened the door of higher education to farmers according to an official from the Ministry of Education. Around 35,000 farmers and more than 6,000 members were enrolled in agriculture-related vocational colleges as a result, figures from the newspaper show.

###### 3: Boarding School(1)

Boarding schools can be a means of socializing and mainstreaming children coming from rural and remote areas. Children are introduced to new ways of living; new routines and responsibilities. Children from remote communities increase their options for the future by learning skills that will assist them in contributing to their own communities, Boarding schools can be a choice for many families that cannot offer adequate facilities for study.  Where homes are overcrowded and do not have electricity, boarding schools can offer a better study environment.

### AT urban poverty

###### 1 Smart agriculture boost economy.  

It can raise sales, and lower down the price, make food more affordable, thus let more people living both in the urban area and rural area stop suffering from hungers. Booming and new information consumption services valued at over 8.3 trillion yuan. (Which is considered as a typical kind of infrastructure) Thus proving our contention can work. 

###### 2 When building infrastructure, jobs will be created. (our point)

According to Kane, 2015, every $1 billion in infrastructure spending can directly and indirectly create up to 13,000 jobs a year. Another piece of evidence directly indicates the construction of 5G in the cities,  China's 5G industry will directly create over 3 million jobs by 2025.   Some estimations predict that $5 billion stimulus would create almost 100,000 new jobs directly in short term and almost 2.5 million jobs as network effects 

###### 3 These people build our world into a better place.

Our opponent is having discriminative ideas towards these people. These people do not want to commit crimes.  They want to make money. Infrastructure give them a choice to make 30% more money  in their hometown accompanying their children.  The left-behind children problem won't even exist.  So for the better future of mankind vote for us. 

### AT Health care

###### 1 More health care infrastructure needed

There were only 3.66 beds per 1000 population, and 1.28 certified medical doctors or assistants per 1000 population in the 832 poverty stricken counties in China. This show out the lack in infrastructures. Social capital, as an important component of soft infrastructure, should be fully considered by the authority in promoting regional economic growth. 

######  2 Health care reduce poverty

These activities proved effective in responding to health-related poverty and 6.7 million households have been lifted out of the trap of impoverishment due to illness.  This shows the contribution of the con side solution directly to the topic.

###### 3 Welfare won't help

The non-transfer (or administrative) cost of the program is approximately 67.2 billion - an extraordinary running cost which equates to a spending of Yuan 3.4 in administrative costs for every Yuan transferred to beneficiaries.  Our opponents are wasting money and people's lives. It is inefficient of way compared to ours which is more effective. 

So. If people get a bunch of money but do not have medical resources to use them, than what's the point? More hospitals built can lower the price. Solving the problem

### AT left-behind children

###### 1 Smart agriculture create job opportunities.

Smart agriculture makes the job opportunities availiable in the rural areas. As the sustainable and long-lasting our side bought clearly benefits the farmers in both long-term and short-term. They also make 30% more money working in the smart agriculture fields. There is no longer reason for them to leave their hometown and abandon their children! We are trying to achieve better world in the future. But our opponents are exactly the opposite.

###### 2 Boarding school solved

We build boarding schools to help them. Boarding schools can be a means of socializing and mainstreaming children coming from rural and remote areas. Children are introduced to new ways of living; new routines and responsibilities. Children from remote communities increase their options for the future by learning skills that will assist them in contributing to their own communities, Boarding schools can be a choice for many families that cannot offer adequate facilities for study. Boarding schools can offer a better study environment.

### AT Dibao

###### 1 Corruption during the process

76% of 2007 urban Dibao recipients were actually ineligible. A separate study found that an incredible 86% of 2009 rural Dibao recipients did not actually meet the program requirements.  While the high leakage and mis-targeting rate is in large part due to poor administrative practices, it is an open secret that corruption also plays a key role. Thus shows Dibao sucks.

###### 2 It is dehumanizing and stigma

A survey reported an interviewee’s humiliation at having to publicly disclose that she was suffering from a  disease that prevented her from working, while another deliberately hid the family’s Dibao status from their child to prevent him from having to carry a “psychological burden.” Many potential recipients even applying for the Bilbao in the first place.  But the disqualified are still not stopped. some 86% of people receiving Dibao are thought to be ineligible, while just 11% of those who are eligible for Dibao receive it. 

###### 3 Welfare Inefficient

The administrative cost of the program is approximately 67.2 billion - an extraordinary running cost which equates to a spending of Yuan 3.4 in administrative costs for every Yuan transferred to beneficiaries. We calculated this loss to equal Yuan 86 billion, which when subtracted from the disposable income available to the population without the programme equates to social welfare totaling Yuan 6,003 billion. Our opponents are just wasting money on meaningless stuffs. 

###### 4 Strict-means testing

Because of the strict means-testing requirements, Dibao recipients are often effectively prevented from investing in supposedly frivolous things, such as cell phones, computers, and education that would bolster their chances of moving into regular paid employment. Many recipients are further prevented from finding paid work . One 2015 study even found that compared with those eligible but not receiving the Dibao, Dibao recipients were at an increased likelihood, by an incredible 128%, of feeling unhappy.     

### AT Job Training

###### 1 Lack of infrastructure

If you have a bunch of skilled workers but they do not have factories to work inside. Than what's the point of doing job training? Today in the topic we do a comparison. Skilled workers are meaningless without infrastructure or other construction program. But with infrastructure built, it will easily attract a bunch of new skilled workers and thus bring more impact compared to our opponent's plan of wasting money in welfare programs. Our side's impact weighs heavier.

###### 2 Better job opportunities

More jobs can be created by the con side through infrastructure building. There are clear evidences proving this. . An oft-cited statistic, for instance, notes that every $1 billion in highway spending can directly and indirectly create up to 13,000 jobs a year.  In the transit scenario, the access to retail jobs by transit increased on average by 11 times. 88 million jobs expected to be created by BRI by 2027. All show that our plan works better. 

###### 3 Don't need to do so

If one can live on his own skills originally, we should we even have job training through welfare programs? Our smart agriculture contention exactly prove that point. As people can make a better living directly through farming and living on their own lands. I don't see why wasting money on this is necessary. For out plan is more cost-effective, we should win this point.

### AT Vulnerable groups 

###### 1 Pension won't work

The old people need accompany from their children to full fill their mental needs.  Instead of more money, they want help from their children. Our opponents are trying to take these people to the urban cities and away from the family. Our side propose the plan for the vulnerable groups that they will still work on the fields with the smart agriculture technology.   They will make 30% more money. Solving the pension problem by themselves and enjoy the happiness of staying together.

###### 2 More old people's home needed.

These old people are lack of professional community services.  Evidence has shown that the world average of old people having beds in old people's home equals 7%, in China the number is only 1.5%.  This shows that old people in China is in emergent need for these kinds of infrastructures. Our side is trying to heap these people find a sustainable way to solve the problem and find a place to live. 

### AT Government Budget (feasibility)

###### 1 Government can go into debt

the US. spent like $3 trillion on corona virus aid but it just went into debt to pay for it. China is a big enough country with enough trustworthy credit that it can do something similar.

###### 2 It's not a cost

The investments that you pay for will help decrease poverty and it will grow the economy.. (plus, we can tax Jack Ma and other rich people and companies to pay for it)

It is a clear con ballot , thanks.