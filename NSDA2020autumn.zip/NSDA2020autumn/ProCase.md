Resolved: In China, increased spending on welfare programs is more effective at alleviating poverty than increased spending on public infrastructure

# CON

## Definition

## Framework

Whichever side is more effective at alleviating poverty in China in the long term wins this debate, as alleviating poverty is a long-term goal.

## Contention 1  Agriculture

According to The World Bank, 40% of Chinese population live in rural areas. <sup> [5] </sup> And based on a report by the Wall Street Journal, upward of 90 to 99 percent of China’s impoverished population either lives in or comes from rural areas. <sup> [6] </sup>As agriculture is the main occupation in rural area, the improvement of agriculture is a huge part in alleviating poverty.

### Subpoint A Agriculture E-commerce

E-Commerce is the best way to help sell agriculture products and alleviate poverty in rural areas. Some of China’s most impoverished areas have been finding new growth through e-commerce sites, according to the latest report from the Alibaba Poverty Relief Fund, and livestreaming has been an important driver of rural sales in the past few months. In just one event in July, it helped sell over 150 thousand units of agriculture produce. <sup>[2]</sup> Pinduoduo saw the order value of agricultural sales soar over 200 percent and expected the number to top 120 billion yuan. <sup>[3]</sup>

According to an official report E-Commerce in China, till 2017, online retail sales in rural China increased  to 1.2 trillion, a compound annual growth rate of 91%. And the potential for continued growth remains strong. <sup>[3]</sup> With E-Commerce, the sales of rural products increase, and thus alleviate poverty from the root.

### Subpoint B Smart Agriculture

Smart farming focused on providing the agricultural industry with the infrastructure to leverage advanced technology for tracking, monitoring, automating and analysing operations. <sup>[3]</sup> By bringing in technology infrastructure, agriculture can be smarter under machines' help. Then, the increase of agriculture production, together with E-Commerce, brings in economic benefits and help alleviate poverty. According to Food and Agriculture Organization, the use of these technologies can reduce fertilizer cost by 39 percent and increase harvesting periods by 1.5 months. <sup>[7]</sup>

There are over 150 million people in China that are considered undernourished and lack food according to the Economist. <sup>[1]</sup> And a third of children in poverty have iron deficiency which can stunt brain development <sup>p1]</sup>, and the only way to solve this problem is to increase the growth of agriculture and stop the hunger and malnutrition. 

## Contention 2 Education

## Contention 3 Health Care



## References

1 The Economist 2014 https://www.economist.com/china/2014/06/13/the-hungry-and-forgotten

2 "e-commerce still the key tool in poverty alleviation in China", Christine Chou, Alizila, 2019, https://www.alizila.com/e-commerce-still-key-tool-in-poverty-alleviation-in-china/

3 World Bank, Xubei Luo https://blogs.worldbank.org/eastasiapacific/e-commerce-poverty-alleviation-rural-china-grassroots-development-public-private-partnerships 
E-Commerce in China, 2017, http://images.mofcom.gov.cn/dzsws/201807/20180704151703283.pdf

4 IoT Agenda, Margaret Rouse, https://internetofthingsagenda.techtarget.com/definition/smart-farming

5 The Word Bank, Urban Population, https://data.worldbank.org/indicator/SP.URB.TOTL.IN.ZS

6 Wall Street Journal, https://www.wsj.com/articles/BL-CJB-1817
https://borgenproject.org/10-facts-about-rural-poverty-in-china/

7 Food and Agriculture Organization of the United Nations, 2018, Director General Qu Dongyu “Agriculture must get smarter to end poverty and hunger” http://www.fao.org/director-general/news/news-article/en/c/1262624/

