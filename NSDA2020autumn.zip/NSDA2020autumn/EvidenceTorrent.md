# PRO Evidence

## Left-Behinds

### Numbers

> https://www.policyforum.net/protecting-the-welfare-of-chinas-left-behind-children/
>
> Jason Hung,intern at United Nations Economic and Social Commission for Asia and the Pacific

​	There are an estimated 61.03 million left-behind children in China – or approximately 38 per cent of all rural children.

​	These left-behind children are particularly educationally disadvantaged. The Junior high school dropout rates of left-behind students is much higher than other rural children.

> https://www.sciencedirect.com/science/article/pii/S0190740917306424
>
> Care for left-behind children in rural China: A realist evaluation of a community-based intervention
> [ChenyueZhaoa](https://www.sciencedirect.com/science/article/pii/S0190740917306424#!) [XudongZhoub](https://www.sciencedirect.com/science/article/pii/S0190740917306424#!) [FengWangb](https://www.sciencedirect.com/science/article/pii/S0190740917306424#!) [MinminJiangc](https://www.sciencedirect.com/science/article/pii/S0190740917306424#!) [ThereseHesketh](https://www.sciencedirect.com/science/article/pii/S0190740917306424#!)

​	According to a survey by Kaihua Women's Federation (unpublished), about 55% of school-age children in the Kaihua county were left behind。

### Mental

> Lijia Zhang, 26 May, 2018, "Left-behind children a poignant reminder of the cost of China’s development," South China Morning Post, https://www.scmp.com/comment/insightopinion/article/2147787/left-behind-children-poignant-reminder-cost-chinas)

The lack of interaction between parents and children has led to psychological and developmental problems for some children. 70 per cent of left-behind children suffered from mental health issues, such as anxiety and depression, and 34 per cent considered suicide.

### Crime & Discriminating Judiciary system

> https://www.economist.com/briefing/2015/10/17/little-match-children
>
> Oct 17th, 2015

Juvenile offences are rising in China, which may well in part be because of the increased numbers of left-behind children. Two-thirds of all Chinese juvenile offenders came from rural areas. 

When they are brought before the law, left-behind children are much more likely to go to jail than other children because courts are reluctant to grant probation in the absence of a guardian. In Shanghai, the children of migrant labourers get probation in only 15% of cases, compared with 63% of cases involving local juveniles.

### Solution - Left Behind Children Club



## Infrastructure Corruption

### 10-30% corruption

> The World Bank, http://documents1.worldbank.org/curated/en/571281468137721953/pdf/wps4271.pdf

The World Bank estimates that public infrastructure projects lose on average 10-30% of their budget to corruption. 

### impact to poverty

> Gupta et. al 02  http://web.a.ebscohost.com.libpublic3.library.isu.edu/ehost/detail/detail?sid=e4c33f6e-6eea4737-8d15-752dc2c108de%40sessionmgr4001&vid=0&hid=4212&bdata=JnNpdGU9ZWhvc3QtbGl2ZQ%3d%3d#AN=6446767&db=bth

An increase of one standard deviation in corruption increases income inequality by about 11 points and reduces income growth of the poor by about 5 percentage points per year. 



## Overspent

> https://review.sbs.ox.ac.uk/Why-Chinas-infrastructure-investment-may-be-doing-more-harm-than-good.html

<div style="font-size:10px">One of the things we see is that Chinese projects face similar cost overruns to the rest of the world – so they’re not building on budget. Our observation was that</div> there was a 31% overspend on these projects on average<div style="font-size:10px">,’ says Dr Budzier, Fellow in Management Practice, Saïd Business School.</div> ‘Three-quarters of the projects in the study suffered cost overruns.’



## AT Education

### Drop-outs

> https://www.goodcall.com/news/strong-correlation-continues-poverty-graduation-rates-09275/
>
> report from National Student Clearinghouse Research Center

The data show that only 50% of students from high poverty public schools entered college in the fall following graduation, and only 18% completed college in six years.

> https://projectpartner.org/poverty/chinas-education-gap-a-surprising-factor-in-rural-poverty/
>
> Project Partner

​	As high school nears, a financial barrier starts to widen the gap between rural and urban students. Only about 40% of rural students even attend high school because of the cost. 60% decide to drop out in middle school.

​	By the time students are ready to take college entrance exams, 95% of rural students have dropped out of the system. The remaining 5% of rural students reach a Chinese university through an unfair and discriminatory system.

## AT Water Supply

### Corruption

> https://www.devex.com/news/the-high-cost-of-water-corruption-and-how-to-stop-it-98223

Every [10%](http://www.waterintegritynetwork.net/wigo/) of investment in the water sector that is lost to corruption equates to over $75 billion in losses per year, according to a 2016 study. Corruption also increases the price of a water connection by up to [30%](https://www.sida.se/contentassets/6a4a390a3efd48bba700edb3f0ea89c3/information_brief_anti-corruption_water_and_sanitation_webb.pdf) for individual households, according to separate research.



## AT Green Infrastructure

> https://www.admcf.org/wp-content/uploads/2019/11/4-Resource-Water-in-China-Responsible-Research-February-2010.pdf

Reports suggest that only half of the money earmarked for environmental protection was spent on legitimate projects.



## AT Migrant

**Migrant worker vulnerable employment**

> https://chinapower.csis.org/poverty/

About 43.8 percent of China's working population was considered to be vulnerable employment, which is characterized by inadequate earning, low productivity and difficult conditions of work.

**Welfare low**

> https://clb.org.hk/content/migrant-workers-and-their-children#hukou

just [22 percent](https://clb.org.hk/content/migrant-workers-and-their-children#hukou) of migrant workers had a basic pension or medical insurance, and only 17 percent were covered by unemployment insurance

## AT Jobs

> http://davidpublisher.com/Public/uploads/Contribute/5950c419af79e.pdf

There are nearly 65 million people who are defined as working poor in the labor market. And there are estimated 53 million working-age people with income below the poverty line, who have higher risk into poverty. 

## AT Electricity

> https://tradingeconomics.com/china/access-to-electricity-percent-of-population-wb-data.html

Access to electricity in China was reported at 100% in 2018.





# CON Evidence

## Agriculture Benefits

> https://www.scidev.net/asia-pacific/agriculture/news/climate-smart-agriculture-must-address-poverty.html
> Joel D. Adriano, regional coordinator for the Asia Pacific edition of *SciDev.Net*.

​	“Growth in agriculture is 2–4 times more effective in lifting people out of poverty ...” Allaster Cox, deputy head of the Australian mission in Jakarta.
​	“Productive, efficient agriculture is a strong foundation for economic development. It provides employment and income and reduces poverty,” Cox said.

> http://www.fao.org/director-general/news/news-article/en/c/1262624/
> Food and Agriculture Organization of the United Nations (FAO)

​	Using data as its foundation, precision agriculture involves collecting and processing biological and physical information, analysing weather and farm data to optimize productivity. The Director-General noted that the use of these technologies can reduce fertilizer cost by 39 percent and increase harvesting periods by 1.5 months, thus increasing the productivity. Agriculture must get ‘smarter’ to end poverty and hunger.

> https://www.oecd.org/indonesia/agriculturalprogressandpovertyreduction.htm
> OECD

​	An OECD study finds that rapid and sustainable progress to reduce extreme poverty is next to impossible except where agricultural productivity increases and incomes increase for poor farmers.
​	More than half of the reduction in poverty achieved under study can be attributed to growth in agricultural.

> https://www.worldbank.org/en/news/feature/2014/11/12/for-up-to-800-million-rural-poor-a-strong-world-bank-commitment-to-agriculture

​	About 78 percent of the world’s poorest people live in rural areas and rely largely on agriculture.
​	Long acknowledged as one of the most powerful tools for raising the incomes of very poor people, agriculture is integral to ending poverty and boosting shared prosperity.

> https://weeffect.org/app/uploads/2018/12/we-effect-reducing-poverty-through-agriculture.pdf
> weeffect

​	For China, 35% of people work in agriculture.
​	The World Bank pointed out in its report that economic growth within agriculture is at least twice as effective as others with regard to reducing poverty.

> https://www.worldbank.org/en/topic/agriculture/overview

Analyses in 2016 found that 65 percent of poor working adults made a living through agriculture.

Better water-use efficiency on 44,000 hectares of farmland and new technologies have improved soil conditions, and boosted production of rice by 12 percent and maize by 9 percent. More than 29,000 farmers’ cooperatives report higher incomes and increased climate resilience.

> https://borgenproject.org/quingyuans-agricultural-sector/

In the Lianyi village of Quingyuan, farmers are using an intelligent agricultural base to increase labor input while alleviating poverty.

After the execution of the project, the [land rental income of villagers increased by around $6,298](http://en.people.cn/n3/2020/0601/c98649-9696360.html). The working income of poor households and villagers also saw an increase of about $57,109 after the implementation of the project.



## Aquaculture

> https://www.was.org/article/Intelligent-aquaculture.aspx#.X6VELYgzYuU

Through advanced equipment and robotics, intelligent aquaculture can realize the precise control of water quality, and can feed the fish in an appropriate and timely way to ensure healthy and fast growth of the fish. 

Although aquaculture involves more and more technologies, it is still far from the level of other agro‐food industries. 

> Aquaculture in China: Success Stories and Modern Trends. Germany, Wiley, 2018. Page 8
>
> https://www.wiley.com/en-us/Aquaculture+in+China%3A+Success+Stories+and+Modern+Trends-p-9781119120766

In order to ensure product safety and public health, the Chinese government has to attach greater importance to improving aquaculture product safety and quality in the country.

>**De Silva,** Sena S., and F. Brian Davy. "Aquaculture successes in Asia: contributing to sustained development and poverty alleviation." Success stories in Asian aquaculture. Springer, Dordrecht, **2010**. 1-14. http://library.enaca.org/emerging_issues/success_stories/success-stories-asian-aquaculture.pdf#page=13

Fish and all aquatic products are easily digested, and though perishable, are easily processed into various forms avoiding wastage.

Fish provides essential micronutrients in the form of vitamins, mineral, with clear evidence being brought forward with regard to its impacts on common diseases such as cardio vascular.

>**Olaganathan**, Rajee, and Alicia Tang Kar Mun. "Impact of aquaculture on the livelihoods and food security of rural communities." International Journal of Fisheries and Aquatic Studies 5 (**2017**): 278-283. https://commons.erau.edu/cgi/viewcontent.cgi?article=1869&context=publication

Aquaculture contributes to the livelihood of the poor through improved employment and income. Aquaculture creates job opportunities for rural communities. With increased financial ability, household manage to reflect stronger purchasing power and have better access to the resources. 

Child blindness, infant mortality and non-communiscable disease (NCDs) have substantively decreased with the help of rural aquaculture.

> De Silva, Sena S. and F. Brian Davy. "Success Stories in Asian Aquaculture." Aquaculture Successes in Asia: Contributing to Sustained Development and Poverty Alleviation. Springer, 2010, pp. 1-14, doi:10.1007/978-90-481-3087-0_1.

The sector has provided direct and indirect livelihood means to millions, a significant proportion of which is rural. And it has contributed to food security and poverty alleviation.

>Palanca-Tan, Rosalina. "Aquaculture, poverty and environment in the philippines." The Journal of Social, Political, and Economic Studies 43.3/4 (2018): 294-315. http://search.proquest.com/openview/579b706e97854d55896ccd84cc6a375b/1?pq-origsite=gscholar&cbl=22044

As it continues to develop, aquaculture will continue to play an important role in ensuring food supply and alleviating rural poverty.

Government special efforts are also planned to assist the seafood processing industry.

> Palanca-Tan, Rosalina. "Aquaculture, poverty and environment in the philippines." The Journal of Social, Political, and Economic Studies 43.3/4 (2018): 294-315. http://search.proquest.com/openview/579b706e97854d55896ccd84cc6a375b/1?pq-origsite=gscholar&cbl=22044

Aquaculture potentially has a role in poverty alleviation by providing an alternative to municipal fishing and a supplementary source of income to rural poor communities. 

Sea-weed farming and small-scale freshwater fishpond and cages have provided low-income communities with means of livelihood and hence helped improved their economic conditions.

> http://www.fao.org/state-of-fisheries-aquaculture

The aquaculture production is projected to reach an increase of 32% over 2018.



## E-Commerce

### Alibaba E-Commerce help increase sales

> "e-commerce still the key tool in poverty alleviation in China", Christine Chou, Alizila, 2019, https://www.alizila.com/e-commerce-still-key-tool-in-poverty-alleviation-in-china/

Some of China’s most impoverished areas have been finding new growth through E-Commerce.

The report, found that sales of goods from counties recognized as poverty-stricken, grew by 80% year-on-year in the past six months on Alibaba's platforms. The 242 poverty counties that have signed on have generated more than RMB 110 billion through Alibaba's platforms. 

Livestreaming has been an important driver of rural sales. The channel plans to cultivate 1000 livestream hosts across poverty-stricken areas in 100 counties, helping them each to generate over RMB 10 thousand in monthly income. IN its latest even in July, the channel hosted nearly 100 sessions, and helped sell over 150,000 units of agricultural produce.

### Pinduoduo E-Commerce Agriculture

>World Bank, Xubei Luo https://blogs.worldbank.org/eastasiapacific/e-commerce-poverty-alleviation-rural-china-grassroots-development-public-private-partnerships 
>E-Commerce in China, 2017, http://images.mofcom.gov.cn/dzsws/201807/20180704151703283.pdf

E-commerce platforms like Pinduoduo have worked with local governments to include poor households in a sound industrial chain ranging from produce cultivation to processing and sales, lending steam to the country's anti-poverty campaign.

Pinduoduo saw the order value of agricultural and sideline products sales via its platform soar over 200 percent year on year in 2018 to exceed 65 billion yuan and expected the number to top 120 billion yuan in 2019.

## Healthcare

### More Medical Infrastructure Needed

> “The year 2020, a milestone in breaking the vicious cycle of poverty and illness in China”, Infectious Diseases of Poverty, 2020, published January 30, 2020, https://doi.org/10.1186/s40249-020- 0626-5, https://link.springer.com/article/10.1186/s40249-020-0626-5)

There were only 3.66 beds per 1000 population, and 1.28 certified medical doctors or assistants per 1000 population in the 832 poverty stricken counties in China.

## Education

### Boarding School

> https://www.scmp.com/news/china/policies-politics/article/2129910/jack-ma-has-solution-chinas-left-behind-kids-boarding

Many rural schools in China have very low enrolments – some have fewer than 10 students – and most of them are “left-behind children”.

Ma’s solution was to merge rural schools that had under 100 students and would struggle to hire and retain teachers and provide a quality education. He proposed boarding schools be created instead, with a bus service to collect children at their village entrance on a Monday morning and drop them off again on a Friday.

Local women could be hired as dormitory supervisors, he said, and they should also be given training so they could provide counselling for the children as needed.

> https://unesdoc.unesco.org/ark:/48223/pf0000139720

 Boarding schools can be a means of socializing and mainstreaming children coming from rural and remote areas. Children are introduced to new ways of living; new routines and responsibilities.

Boarding schools provide a centralized location for learning and living that can bean effective link between the remote communities of origin and the larger society. Children from remote communities increase their options for the future by learning skills that will assist them in contributing to their own communities,

Boarding schools can be a choice for many families that cannot offer adequate facilities for study.  Where homes are overcrowded and do not have electricity, boarding schools can offer a better study environment.

> chinadaily.com.cn/china/2013-08/20/content_16908994.htm

The report said that only 45 of the 101 boarding schools surveyed have managers to look after children and manage the dormitories.

>https://scholar.harvard.edu/files/fryer/files/seed23.pdf
>https://www.dallasnews.com/news/education/2018/01/15/could-a-boarding-school-experience-help-kids-living-in-poverty-a-dallas-businessman-says-yes/

​	A 2012 study by a Harvard economist found that low-income kids in one such boarding school with 24-hour support had significantly higher math and reading scores than kids who didn't get into the program.

### Vocational School

> http://www.xinhuanet.com/english/2019-12/07/c_138613219.htm

China launched a program to establish 100 quality schools for training talent for its rural vitalization within two years.

The expansion of higher vocational colleges this year has opened the door of higher education to farmers according to an official from the Ministry of Education.

Around 35,000 farmers and more than 6,000 members from village Party branches and village committees were enrolled in agriculture-related vocational colleges as a result, figures from the newspaper show.

> http://english.www.gov.cn/premier/news/2019/04/30/content_281476637627986.htm

## Education (overcrowded)

https://www.sixthtone.com/news/1000089/chinas-most-understaffed-school-has-113-children-class

 The most overcrowded conditions among the schools sampled in the study were found at a primary school in central China’s populous Henan province that averaged 113 pupils per classroom.

## Vocational School fee

https://www.oecd.org/education/skills-beyond-school/45494135.pdf

Vocational Education Schools are largely covered by national scheme, and some even free.

## Speed

https://globalnews.ca/news/3984178/1500-chinese-engineers-build-train-station-in-9-hours/

A Chinese train station was built in less than nine hours.

## Jobs & Income

https://www.who.int/water_sanitation_health/resources/povertyreduc2.pdf

According to World Development Report, a 1% growth in a country's mean income can be expected to reduce poverty by 2.4%.

## Sanitation & Water Supply

### Economic Benefit

https://www.who.int/water_sanitation_health/resources/povertyreduc2.pdf

The benefit far outweigh the cost of making improvements by 60 times. Improving water and sanitation can bring about $85 billion to poorer regions.

### Job Creation

https://en.unesco.org/news/water-drives-job-creation-and-economic-growth-says-new-report

Every 1 million dollars in expanding the water supply and sanitation network would directly result in 10 thousand jobs.

### Easy to operate

https://www.worldbank.org/en/news/feature/2020/03/10/access-to-sanitation-services-improves-the-quality-of-life-in-rural-china

According to World Bank, the bio-trickling technology operation is traditional, simple and low-cost, that anyone can operate and maintain.

### Inherency

https://en.unesco.org/news/water-drives-job-creation-and-economic-growth-says-new-report

Now infrastructure is aging. 30% of global water withdrawals are lost through leakage. 

https://en.wikipedia.org/wiki/Water_supply_and_sanitation_in_China  https://washdata.org/sites/default/files/documents/reports/2017-06/JMP-2015-Report.pdf

According to WHO, about 36% of rural population in China still do not have access to improved water supply.

https://www.worldbank.org/en/news/feature/2020/03/10/access-to-sanitation-services-improves-the-quality-of-life-in-rural-china

According to World Bank, more than 290 million Chinese rural people lack access to improved water supply and sanitation.

https://www.worldbank.org/en/news/press-release/2020/03/03/innovating-water-and-sanitation-services-in-chinas-rural-areas

Only 15% of rural sewage is properly treated. Local government lack financial means for delivering sanitation services.

https://news.cgtn.com/news/2019-11-18/How-the-Toilet-Revolution-is-changing-China-LH2SCXCemQ/index.html

The penetration rate of rural sanitary remained lower than 50% in northeast and northwest regions.

### Impact

https://www.who.int/bulletin/volumes/90/8/11-098343/en/

Unsafe water and poor   sanitation accounted for 62 thousand death and 2.9 million life disability.

https://www.worldbank.org/en/news/press-release/2020/03/03/innovating-water-and-sanitation-services-in-chinas-rural-areas

In Sichuan, nearly 235 thousand residents are expected to benefit from the project and these improvement. 

### Spent now

https://news.cgtn.com/news/2019-11-18/How-the-Toilet-Revolution-is-changing-China-LH2SCXCemQ/index.html

In 2019, China invested one billion dollars in sanitation improvement.



## Tourism

### Impact & Solvency

**Direct poverty alleviation**

http://www.xinhuanet.com/english/2019-09/28/c_138429477.htm

Citing figures from an official report in 2017, rural tourism helped lift some 10 million people out of poverty in the country since 2011.

**Education**

https://bigoditourism.com/about-kafred/

Because of tourism revenue (spent on schools), parents pay about 50% less for fees compared to other private or community schools.

**Employment**

> https://www.researchgate.net/publication/257704914_Rural_tourism_development_in_China_Principles_models_and_the_future
>
> Rural Tourism Development in China: Principles, Models and the Future WANG Ling-en1,2, CHENG Sheng-kui1, ZHONG Lin-sheng1*, MU Song-lin1,2, DHRUBA Bijaya GC1,2, REN Guo-zhu1 

Based on data from CNTA, the revenue created by rural tourism in China was more than 120 billion yuan, and promoted employment over 15 million farmers. According to NRTDP, it is predicted that the tourism will promote direct employment for 989 million people and 36.8 million indirect jobs.

**Example of Guizhou**

https://www.chinadaily.com.cn/business/2017-10/30/content_33884076.htm

In southwest China's Guizhou province, authorities have identified thousands of tourism resources and supported 14 impoverished counties to build tourist areas.

**Last Year**

http://en.people.cn/n3/2020/0515/c90000-9690953.html

Last year, rural areas received 3.2 billion tourists, generating a revenue of more than 850 billion yuan.

### Inherency

**Government Plan**

https://travelbiznews.com/china-lists-680-villages-to-promote-rural-tourism/

China listed 680 villages to plan to promote rural tourism.

## Jobs needed

https://thediplomat.com/2020/06/how-china-can-avert-an-employment-crisis/

(Covid-19) [at least 20 million](https://www.scmp.com/economy/china-economy/article/3083513/coronavirus-china-faces-historic-test-pandemic-stokes-fears?utm_medium=web&utm_source=series&utm_campaign=grim-outlook-chinese-unemployment&utm_content=20200605) new jobs are needed.



# CON IMPACT

By agriculture, we increase household income by 57 thousand dollars, and solve the 78% poor people problem who rely on agriculture.

We saved the 30% of wasted water, and properly treat the rest 85% rural sewage, which prevent the 62 thousand death and 2.9 million life disability.

By tourism, we help the 6 million poor people in ethnic minorities, and will lift 680 villages out of poverty.

For jobs, every 1 million dollars in water and sanitation can create 10 thousand easy jobs, and we also provide 36 million jobs for poor. Moreover, we let more than 95% vocational graduates have jobs.