As the pro side we strongly affirm the resolution.

**Definition:** Welfare program: refers to a range of government programs that provide financial or other aid to individuals or groups who cannot support themselves. [Merrian-Webster Dictionary] 

**Framework :** Our criteria for determining effectiveness is that whichever team helps the most people effectively with the least spent should win this debate.

## **Contention 1: Education.**

### **Sub point a): School lunch programs**

A team doing fieldwork in Shanxi found that the school kids had limited, nonnutritive food for lunch. Could they have anemia? They suspected, and immediately conducted a survey involving 4,000 kids. They found that students often do not eat breakfast and many times must cook their own dinner. [1]

China launched the Free Lunch for Children (FLC) Initiative in 2011 because students in remote poverty-stricken villages had to endure hunger because their families were too poor to afford lunch or their families were too far away from their schools. Ten years later, official data shows that over 40 million students have benefited from the scheme. [2]

**Impact:** Every ten thousand RMB investment in education welfare can lift 7 individuals out of poverty, which has 30% higher return than agricultural D&G investment (Lin, 2005). [LINK: Since the CDRF is continuously implementing, from primary school until they finish their 9-year education, which means 90billion yuan for 100000 students, 10thousand yuan for 1 student, that’s the reason for them to get rid of poverty] Therefore, using welfare programs to give the children better lunch is extremely important to give them health and give them the opportunity and ability to alleviate themselves out of poverty. [3][LINK: We have improvement measures. Invest more money and hand over the links in the project to professional companies. We should first give the children the basic food and drink. For example, more than 75 million consumers have participated in the eight-year "one yuan donation" welfare program. The total amount of donations has exceeded 100 million yuan, including more than 20 million yuan donated by Yum and its employees. At present, the public welfare project has provided nearly 29 million nutrition plus meals for nearly 145000 primary school students in poverty-stricken mountainous areas in Yunnan, Guizhou, Sichuan, Guangxi, Hunan and Hubei provinces, and has built "love kitchens" including cookers, steamers, operating tables and other equipment for more than 500 aided primary schools. And no one has ever complained about this project.]

### **Sub point b): Funding to go to school**

Only about 40% of rural students even attend high school because of the cost. 60% decide to drop out in middle school. By the time students are ready to take college entrance exams, 95% of rural students have dropped out of the system. The remaining 5% of rural students reach a Chinese university through an unfair and discriminatory system. [4]

However, welfare can solve this problem. According to statistics from the Gansu provincial education department, from 2016 to 2019, a total of 17.33 billion yuan of educational funds or student loans were issued, benefiting 12.12 million students in the province.

**Impact:** On the national agenda, China aims to achieve the goal of eradicating absolute poverty by the end of this year. By March, the poor population in Gansu had been reduced to 17000 from 1.11 million (a decrease of 93000 people) in 2018. [5]

## **Contention 2: Health care.**

The health care targets of China's poverty alleviation campaign, as it nears its final year, 2020, the country's goal of eliminating all absolute poverty within sight. The proportion reduced to poverty, or returned to poverty, because of illness is as high as 40%. Thus, poverty alleviation via health care has become a primary focus of China's fight against poverty. And evidence has shown welfare programs are making this situation better. [6]

By 2010, over 80% of Chinese citizens were covered by social health insurance programs, up from only 34.4% in 2004. Meanwhile, the increase in generosity is substantial. In September of last year, the State Medical Insurance Administration added 17 cancer-fighting drugs to the public medical insurance plan, reducing their cost to patients by an average of 56.7%. Since March, China has decreased the value-added tax applied to 21 drugs for treating rare diseases, including six used to treat pulmonary hypertension. [7]

**Impact:** Since 2018, the central government has allocated eight billion yuan for medical aid. China's National Health Commission sets up clinics for endemic diseases and extends remote medical services to all county hospitals. From 2013, when "targeted poverty alleviation" was first introduced, to the end of 2018, 6.7 million registered poor households in China have been lifted out of illness-induced poverty. [8]

## **Contention 3: Entrepreneurship funding.**

According to the data, by the end of 2015, the number of migrant workers returning home to start businesses has exceeded 4.5 million, accounting for about 2% of the total number of migrant workers. The proportion of university graduates returning to start their own businesses has increased from 0.5% a few years ago to 1%.

The Ministry of Agriculture said it benefited from some measures to support and promote entrepreneurship in recent two years. For example, they have carried out the action plan of developing agricultural and rural resources to support returning home entrepreneurship and promoting farmers' innovation; at the same time, they have spent 2.6 billion yuan from the central government to subsidize 5200 farmers' cooperatives to set up primary processing of agricultural products, and promote the development of 31000 e-commerce in rural areas.

**Impact:** After funding the entrepreneurship, the graduates got the funds and work hard to start businesses and earn money for themselves and also for their homeland. For instance, in Shuangpai County seat, Hunan Province,they have sold more than 1 million kilograms of agricultural products annually, created an annual economic income of more than 100 million yuan, helped more than 36000 people out of poverty, and increased the income of more than 60000 yuan.

[LINK: These graduates come back to their hometown and start businesses there, the welfare programs fund them money, they get the money and work hard, since they have had good education, they succeed in business and can boost the whole country’s economy and lift people out of poverty.]

Therefore, we strongly urge a pro ballot.

Evidence sources:

[1]: Song, Jialan. “Reduce Poverty by Offering Quality Education to Rural China.” People, vol. 27, no. 2, 2013.

[2]: https://news.cgtn.com/news/2020-09-26/Ten-years-on-the-launch-of-China-s-free-lunch-campaign-U69VLPdlSM/index.html

[3]: Liu, Jialu. “IMPACT OF PUBLIC EDUCATIONAL EXPENDITURE ON POVERTY IN CHINA.” 2019. 

[4]: https://projectpartner.org/poverty/chinas-education-gap-a-surprising-factor-in-rural-poverty/
[5]: http://www.xinhuanet.com/english/2020-10/08/c_139426434.htm
[6]: https://news.cgtn.com/news/2019-10-17/Poverty-alleviation-via-healthcare-KQ2aiQGjiE/index.html
[7]: https://www.sixthtone.com/news/1003649/chinas-health-insurance-to-cover-more-lifesavingdrugs
[8]: https://news.cgtn.com/news/2019-10-17/Poverty-alleviation-via-healthcare-KQ2aiQGjiE/index.html