# PRO rebuttal

Our opponent first contention is about infrastructure helps economic growth. We have two responses.

First, as most infrastructure is enough, increase spending on infrastructure do not have economy benefit because of additional corruption and overspent. According to the world bank, public infrastructure projects lose on average 10 to 30% of their budget to corruption. And there was a 31% overspend on these projects, and three-quaters suffered cost overruns. Data from oxford university shows that infrastructure cost overruns have equalled approximately one-third of China’s $28.2 trillion debt.

Second, we see no relationship between poverty reduction and economic growth. In 2001 to 2012, the economy develop fast, while the poverty reduction speed dropped from 10% to 7%. This tells you judge that economic growth do not alleviate poverty.

Our opponent second contention is about transportation. But we tell you judge that transportation infrastructure is enough now, with no need to increase spending. According to official report in 2019, China has already provided more than 99 percent of villages with paved roadways. And in January 2020, the last villages without a road is connected to the outside now. 

And then they mentioned about e-commerce. Two responses. First, e-commerce sites are enough. According to CGTN, China's e-commerce has covered all 832 poor counties. Thus there is no need to increase spending. Second, what e-commerce need is welfare to solve talent gap as we've mentioned in our contention three. According to Techinasia, poor villages know little about the internet, not to mention e-commerce, and a shortage of local talent is the major problem. According to China Agricultural University, the talent gap would be risen to 3.5 million in 2025. The only way to solve is to provide more e-commerce training welfare programmes.

> http://www.sixthtone.com/news/1326/tourism-traps-ethnic-minority-in-tradition/

They also mentioend about tourism. First, tourism hurt local culture and cause overcommercialization, lead to decreased local support. For example, when armed forces ordered to stop any further construction, about 1000 people protested. Second, we tell you that tourism force people to relocate, and welfare is needed. It costs at least 100 k yuan to build a new house, and vulnerable groups can't support themself to relocate. 

Their sub point B is about TVE. First, we tell you that if people build up an enterprise, they should be already have enough funding, so it is not TVE itself which is alleviating poverty. Second, TVEs in 120 of China's poorest counties employed only four percent of local rural labour, which do not have more effective solvency to the problem. 

Move on to their sub point C about remittance. Remittance don't have to be such offline. Alipay has already had remittance partnership with WorldRemit, and the only things need for that is internet which we already have and phones which can be provided with welfare. We don't see the need of building more remittance infrastructure. Second, migration workers can still have a poor life as more welfare is needed. According to China Labour Bulletin, just 22 percent had a basic pension, only 17 percent were covered by unemployment insurance, and only 27% have work-related injury insurance. (Moreover, during the Covid-19, China's economy likely lost $100 billion in rural migrant workers wages.) Remittances from migration workers will never help if workers themselves still have a poor life. 

Their final contention is about education. Three responses. First, we tell you that drop out is a more serious problem. Because of the cost, 60% decide to drop out in the middle school, and 95% of rural students have dropped out in high schools. And according to World Socialist Web Site, low-income students are six times more likely to drop out of high schools. Second, urban children already have high quality education but still need welfare. And according to Reuters, only 37% of labour forces in China in urban areas have attended high school. Thus, increase spending on welfare is needed for urban poverty. Third, we tell you that welfare is the key to improve teaching quality. According to Guangming Daily, 2015, only 40 percent of staff getting the social insurance coverage they were entitled to. National Education Monitoring Group revealed half of rural teachers failed to obtain their salaries in full and on time. Poor job satisfaction of rural teaching results in high turnover rates of quality rural teachers, leading to decrease teaching quality. Thus welfare helps solving the problem.



