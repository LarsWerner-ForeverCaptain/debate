# Pro Constructive Draft

On today's topic, we firmly stand on the Pro side. 

## Definition

Welfare means aid in the form of money or necessities for those in need according to Merriam-webster. 

> https://www.merriam-webster.com/dictionary/welfare

Poverty Alleviating aims to improve the quality of life for those people currently living in poverty according to borgen project. 

> https://borgenproject.org/what-is-poverty-alleviation/

## Framework

Refering to the definition, if one side prove that their option improve the quality of life in these poor families better than the other team on the scale of considering both longterm and shorterm benefits. We should win this debate. Otherwise, they should win this debate.

## Contentions

### Contention 1: Education

​    Only about 40% of rural students even attend high school because of the cost. 60% decide to drop out in middle school. By the time students are ready to take college entrance exams, 95% of rural students have dropped out of the system. The remaining 5% of rural students reach a Chinese university through an unfair and discriminatory system.

> https://projectpartner.org/poverty/chinas-education-gap-a-surprising-factor-in-rural-poverty/

​      Infrastructure cannot solve the education problem, the reason why children aren't allowed to have education is for the economic pressure on the poor families. As the coverage of school is already enough in Chinese rural areas, the children is actually prevented to have education by their own parents.  The reason is the economic burden on the family forcing quiting school and childlabour somewhat. 

​    Welfare can solve the problem.On the 2020 Agricultural & Applied Economics Association Annual Meeting a presentation suggests that rural welfare participation boosts rural children’s learning, which could indicate a long-term anti-poverty effect, and that if the program can resolve targeting problems, this effect could be even greater.  

>  https://ageconsearch.umn.edu/record/304258/files/18049.pdf

​    Helping to reduce the gap between rich and poor by two points, reducing the gender discrimination in rural areas and at last, solving the poverty problem directly to the root are the impacts that our side could bring. The sustainable development it can bring is a huge impact for poverty alleiviation. 

>  https://www.cambridge.org/core/journals/social-policy-and-society/article/divided-chinese-welfaresystem-do-health-and-education-change-the-picture/2469C3A7B7344D4825638048A5A9A7C4/corereader

### Contention 2 : Healthcare

​    According to Yun-Ping Wang , researcher at China national health development research centre, the health care insurace provided by our welfare program is currently urgently needed.  Among the poor in China, more than 44% are still impoverished by illness, long-term chronic diseases reached 22.14%. The rural population had a serious economic burden. 

>  https://link.springer.com/article/10.1186/s40249-020-0626-5

​     According to a research paper in China agriculture economic review. Returning to poverty due to illness had become one of the largest factors contributing to the poverty of the rural population.  Experts also point out that China’s medical sector is still underdeveloped, and the social security system is not comprehensive yet, manifested by a considerable shortage of medical services in mental health. 

>   https://www.emerald.com/insight/content/doi/10.1108/CAER-12-2018-0243/full/html?skipTracking=true)  

​    Healthcare welfare can help. Statistics have shown that in the past three years 15 million poor people (98% of the poor population) with infectious and chronic diseases had been treated and taken care of thanks to financial support through multiple health insurance schemes and other governmental subsidies. 

>  https://link.springer.com/article/10.1186/s40249-020-0626-5

​    As we consider life to be most important. If people's lives cannot even be saved, then poverty alleiviation would be completely meaningless. Secondly, as our plan suggests, it can also reduce the economic burden of these families and thus make it a whole lot easier. 

### Contention 3: Employment

​    Dibao program indicating the general program Chinese government promoted through out the nation in order to keep the basic standard of living.  So Dibao should be considered as most typical kind of welfare for the poor people. 

​    We find robust positive effect of rural Dibao participation on recipients’ life satisfaction and persistent mediation effects of both perceived social status and confidence about future in this relationship. The evidence suggests that welfare programs such as rural Dibao can help improve recipients’ subjective well-being. Dibao aims at directly solving the poor's problem.  

​    Our initiative can actually help them to solve real life problems with their own autonomy choices. The results show that rural dibao recipient households shifted their consumption patterns by prioritising health and food over other expenses. These shows out they are using the money effectively and happily.

>  https://www.muse.jhu.edu/article/719408

​    The Dibao program contributes a lot to the poverty alleviation. Poverty gap and severity were reduced by 16 and 25 percentage points respectively in 2007, as compared to 3 and 1 percentage points respectively in 2002. The benefit amount that poor received was substantially higher in 2007 than in 2002, which in turn led to greater poverty reduction in 2007 than in 2002, according to Qin Gao of Fordham university. 

>  https://booksc.xyz/dl/39857382/6a1e6f

Please vote for the pro side, thanks. 