# Mock Debate CON

# Rebuttal

## FW

everykind of poverty, short term

## C1 transitive poverty8

91.7% of rural poverty

covid-19, w/o jobs

380k falls into poverty because of virus

infrastructure not feasible

transitive poverty will die

not enough (workers welfare etc.)

## C2 job training

### SA Migrants

5k yuan

provide job opportunity can't solve

lack of skills

50k receive training

wages double

over 10m people out of poverty in china

### SB Disabled

can't work

autism

90% can't work

opt them free jobs training

blind people

1.95m disabled people out of poverty by job training

## C3 Healthcare

price 11 times highers

medical debts

price drop because of insurance

expand healthcare coverage

adding more drugs to the insurance

# Constructive

## C1 agriculture

### Sub A Irrigation

30% evi falicy

55% enough & satisfied

current spending enough

overuse of ground water

### Sub B Precise Agriculture

internet penetration enough (trend)

don't care about people's welfare, decrease income

machine replacement

## C3 tourism

already enough

not feasible for every places

## C4 vocational schools

welfare better

fees expensive

9000 yuan / year

# SUM

## Clash 1 Jobs

1 jobs training programmes: if we can better fund those vocational schools, no need for increase spending on jobs training for the graduates employment rate will be over 95%

2 disabled people: infrastructure solve better: all-in-one facilities for disabled people and training

also, online jobs solve problems

while welfare suffer great corruption

3 jobs creation more important: Brookings 2015, infrastructure jobs low barrier for entry. and we also build jobs by sanitation and tourism

4 vocational schools: fee not high: According to OECD, Vocational Education Schools are largely covered by national scheme, and some even free.

## Clash 2 Transitive poverty

1 disaster: disaster relief better

2 jobs creation solves

## Clash 3 Healthcare & Water & Sanitation

1 44% card invalid; opp admit that price high --> unsustainable; infrastructure more need

2 water & sanitation problem: more than 30% do not have access to that

and water infrastructure solve the problem of water shortage by preventing water loss

3 opp doubt importance: an essential and important step, prevent death and disability

## Clash 4 Agriculture

1 irrigation: our opp mentioend rivers polluted. but the evi simply said that urban rivers not drinkable, and we don't see why that has anything to do with the rural poverty

2 smart agriculture: 5G is still less than 50% --> need increase spending

also, precise agriculture is not using machines to replace humans, thus rebuttal invalid.

## Clash 5 Tourism

1 not enough, and still make plans to increase spending on that. complete the plan

2 impact huge: jobs & lower tuition fee

## IMPACT

By agriculture, we increase household income by 57 thousand dollars, and solve the 78% poor people problem who rely on agriculture.

We saved the 30% of wasted water, and properly treat the rest 85% rural sewage, which prevent the 62 thousand death and 2.9 million life disability.

By tourism, we help the 6 million poor people in ethnic minorities, and will lift 680 villages out of poverty.

For jobs, every 1 million dollars in water and sanitation can create 10 thousand easy jobs, and we also provide 36 million jobs for poor. Moreover, we let more than 95% vocational graduates have jobs.



# Benastalk BS LH PRO

# Rebuttal

## 1 Health Infrastructure

access to healthcare infrastructure

capacity of delivering healthcare

educational training of healthcare

6.7 million lift out of poverty

quality healthcare

hospitals not enough rural

beds

---

**Infrastructure Enough**

> Fang 2020. (Fang Hai. 2020. “International Health Care System Profiles China” Commonwealth Fund. June 5 2020 https://www.commonwealthfund.org/international-health-policycenter/countries/china)
>
> https://www.statista.com/statistics/276545/hospital-bed-density-in-china/
>
> https://economictimes.indiatimes.com/industry/healthcare/biotech/healthcare/delhi-has-2-71-hospital-beds-per-1000-who-recommends-5/articleshow/47803958.cms?from=mdr

First, there is no need to increase the infrastructure spending. Our opp said hospitals, but According to Common Wealth Found, In 2018, there were already more than 500 thousand public primary care facilities in rural areas. Also, our opp said about bed, but, in 2018, the china's hospital density amounted to 6.03 beds per thousand people, far more than the WHO recommendation.

**Lack of money for healthcare**

> Zhou, Y., Guo, Y. & Liu, Y. Health, income and poverty: evidence from China’s rural household survey. *Int J Equity Health* **19,** 36 (2020). https://doi.org/10.1186/s12939-020-1121-0

While second, spending should go to welfare.16% households are still unable to bear their medical expenses. Those households need more welfare in order to get access to healthcare.

**Medical Debt**

> https://www.reuters.com/article/us-china-healthcare-debt-idUSKCN0ZQ03A
>
> https://doi.org/10.1186/s12913-020-05551-5
> https://bmchealthservres.biomedcentral.com/articles/10.1186/s12913-020-05551-5

Third, medical debt problem is the most serious in healthcare today, which can only be solved by welfare. According to Reuters, medical loans has tripled to nearly 21 trillion yuan. And according to BMC Health Services Research, in two counties of China, the percentages of patients incurring medical debt exceeded 50% and the debt load was 20,000 yuan. That is causing poverty, as official data show up to 44 percent of families pushed into poverty were impoverished by illness.

## 2 Resettlement

more than 9.2 million escape poverty, increase income

---

**first, we don't need the infra**

> https://allthatsinteresting.com/chinese-ghost-cities

We tell you that The country's ambitious plans for urban growth have led to more than 50 cities have enough infrastructure but few people. So we tell you that infra enough. Instead, more welfare is needed for resettlement. 

**second, Resettle doesn't mean good life**

> https://thediplomat.com/2017/02/chinas-hukou-reforms-and-the-urbanization-challenge/

Research into urban resettlement in Chongqing showed that over half of surveyed migrants found it difficult to find stable jobs, with many citing a lack of familiarity with the city and a lack of social networks. Thus, resettle does not reduce poverty as they don't have jobs, which is much less effective than welfare.

## 3 Dibao bad

### 1 dehumanlization

### 2 corruption & mistargetting

not receiving Dibao

---

First, dibao is not the only kind of welfare. We don't see why dibao failure prove we should not inc spending on other welfare.

**Dibao works and necessary in poverty alleviation**

> https://www.scmp.com/week-asia/article/2087486/getting-paid-do-nothing-why-idea-chinas-dibao-catching

Second, Dibao works and is necessary. World Bank data indicates that the policy has helped lower poverty by 6.5 per cent. 

**Infrastructure Worse**

>Liu & Mikessel 2014. Indiana University. https://onlinelibrary.wiley.com/doi/abs/10.1111/puar.12212
>
>The World Bank, http://documents1.worldbank.org/curated/en/571281468137721953/pdf/wps4271.pdf
>
>Gupta et. al 02  http://web.a.ebscohost.com.libpublic3.library.isu.edu/ehost/detail/detail?sid=e4c33f6e-6eea4737-8d15-752dc2c108de%40sessionmgr4001&vid=0&hid=4212&bdata=JnNpdGU9ZWhvc3QtbGl2ZQ%3d%3d#AN=6446767&db=bth

Third, we tell you that infrastructure is even worse. According to Transparency International, corruption is a major risk for China with infrastructure worth billions of dollars a year and rising. The World Bank estimates that public infrastructure projects lose on average 10-30% of their budget to corruption. 

And the impact of it is huge. According to Gupta, et. al,  an increase of one standard deviation in corruption increases income inequality by about 11 points and reduces income growth of the poor by about 5 percentage points per year. 



# Constructive

## 1 Transitory Poverty

## 2 Disabled

## 3 Entrepreneurship funding

## 4 Gender inequality



# FF

1 long term: we solve both in long term and short term, while opp can't solve the short term, and we've proved that they also don't have solvency for long term.

## 1 Healthcare

1 infrastructure enough, give evi showing that beds enough, much higher than WHO recomendation

2 welfare needed

3 solve the medical debt of 50% in rural area

## 2 Resettlement

opp gives no proof that infrastructure needed for resettlement, but we give evi showing that infra is enough

schools: we said that schools closed for low enrollment, which can only be solved by welfare.

## 3 Dibao bad

1 infra corrupted and overspending worse

2 dibao neccessary, great impact

## 3 Inequality & Vulnerable Group

1 we can solve these 80% disabled poor people by giving welfare, and job training, while opp never give direct rebuttal towards that

2 gender inequality is caused by limitations of social and not enough money. impact: inc employment rate of 14% of women, alleviate 18% of poverty

## 4 transitory poverty

1 accounts for 91% of poverty, can't be ignored

2 long term impact: if we do not treat them now, then they will get into chronic poverty, which is worse

## 5 entrepreneuship funding

1 no welfare dependency, we gave evi that  welfare increase the working hours of each households by 31 hours

2 by providing them more funding to set up rural business, we increase income by 60 thousand yuan and alleviate the poverty of 7 million



# SUIS HQ XJ PRO

# Rebuttal

## Def

pov: lack financial resources

welf: gov programme

infra: construction

> increase spending
>
> infra enough

## 1 easily accessible

roads

> We tell you that transportation infrastructure is enough now, with no need to increase spending. According to official report in 2019, China has already provided more than 99 percent of villages with paved roadways. And in January 2020, the last villages without a road is connected to the outside now. 

hospitals

>There is no need to increase the infrastructure spending. According to Common Wealth Found, In 2018, there were already more than 500 thousand public primary care facilities in rural areas.

dehumanizing: check personal data

> 1 didn't tell us why letting gov checking poor's house in order to let gov help them more, is harmful for poverty
>
> 2 infra corruption worse
>
> According to Transparency International, corruption is a major risk for China with infrastructure worth billions of dollars a year and rising. The World Bank estimates that public infrastructure projects lose on average 10-30% of their budget to corruption. 
>

## 2 jobs creation

short term

incentive to work

---

**Jobs need high skills**

>Heritage Foundation 2016 (“Additional Infrastructure Spending Would Employ Few New Workers." The Heritage Foundation. N.p., n.d. Web. 09 Mar. 2016. . ) 
>
>http://thf_media.s3.amazonaws.com/2013/pdf/IB4081.pdf

First, we tell you judge that many rural workers can't get that job as it needs high skill. According to Heritage Foundation, road and bridge construction requires number of highly skilled workers using advanced equipment and machinery, which is just 0.2 percent of all workers. Thus infrastructure jobs can't solve the problem. 

**Jobs enough**

> https://www.forbes.com/sites/russellflannery/2020/02/17/factories-facing-severe-labor-shortages-in-china-u-s-business-group-says/

Second, jobs are enough as there are huge jobs vacancy. According to Forbes, 78% of companies in Shanghai said they don’t have enough workers

**Giving jobs doesn't mean out of poverty**

> Economic Policy Institute 2015 “Poor People Work” https://www.epi.org/publication/poor-people-work-a-majority-of-poor-people-who-can-work-do/
>
> http://davidpublisher.com/Public/uploads/Contribute/5950c419af79e.pdf

Third, even if you buy that they can go to work, this does not means they are out of poverty. Among the current workers in poverty, 62.6% are working full-time while they're still in poverty. There are nearly 65 million people who are defined as working poor in China. And there are estimated 53 million people with income below the poverty line. Thus only welfare can help in jobs.

## 3 solves school overcrowding

40% oversized in Shandong, less than 1/5 get help

teaching quality

---

first, our opp said overcrowding is the problem. but actually, we tell you that the most important question is drop-out. if students can't go to schools, then all those education quality won't matter to them.

**Drop out main problem -- only solved by welfare**

> https://projectpartner.org/poverty/chinas-education-gap-a-surprising-factor-in-rural-poverty/
>
> https://www.wsws.org/en/articles/2013/04/10/hsdo-a10.html
>
> https://doi.org/10.1017/S0305741015001277

Because of the cost, 60% decide to drop out in the middle school. And according to World Socialist Web Site, low-income students are six times more likely to drop out of high schools. While welfare solve this, as according to Cambridge, the compensation agreement can reduce dropout rate by 60%.

second, we tell you that our opp don't have solvency to the teaching quality as the teaching quality is caused by lack of teachers welfare and salary.

> https://www.clb.org.hk/sites/default/files/Teachers%20final.pdf
>
> https://bitterwinter.org/closing-the-door-how-rural-youth-are-denied-educational-rights-in-china/

According to Guangming Daily, 2015, The average salary of teachers in one rural county in Jilin was just 2,500 yuan a month, with only 40 percent of staff getting the social insurance coverage they were entitled to.  Poor job satisfaction of rural teaching results in high turnover rates of quality rural teachers, leading to decrease teaching quality. Thus welfare helps solving the problem.

## 4 renewable energy

1 our opp said about electricity, but according to trading economics, access to electricity in China was already reported 100% in 2018. so we don't see why we should increase the spending

2 renewable energy and environemntal protection infra corruption

Reports suggest that only half of the money earmarked for environmental protection was spent on legitimate projects. Thus, the spending is not efficient.



# FF

long and short term: we provide both solvency for long and short term, while opp have no solvency for neither

## 1 Education & Jobs

1 education overcrowding         many schools have low enrolment because of drop out, so we don't need more infra but welfare

2 teaching quality can only be ensuered when teachers have enough welfare and salary, while opp don't have a solvency to that

3 we tell you that jobs enough, with no need to increase spending on infra to create jobs

## 2 Corruption and Dehumanization

1 Dibao needed, no proof of why it is bad for poverty alleviation

2 infra corruption worse, 30% lost to corruption

## 3 Renewable Energy

1 we tell you that it is not efficient, and lost a lot to corruption. so their impact can't stand

## 4 Vulnerable Group

1 our opp have no solvency to vulnerable group and ignore them, while we tell you that 80% of poor people have disability

2 girl's education: we tell you that it's not only about girls. girl education increase women employment by 14%, and women employment can decrease general poverty by 18%

## 5 Transitory poverty

1 91%

2 long term

## 6 entreprenuewer funding

opp no rebuttal

helped more than 36000 people out of poverty, and increased the income of more than 60000 yuan.

should go to the whole china



# HZ Basis ZW CON

# Constructive

## 1 agriculture

## 2 sanitation & water supply

## 3 tourism

## 4 vocational schools infrastructures

# Rebuttal

fw: urgent

## 1 education welfare

low family income

63% financial concern drop out

low school enrolment rate

drop out rate reduce by 60%

## 2 disabilty welfare

### SA Orphans

caregivers

no welfare to disabled now

### SB Vocational training

95% disabled found a jobs

2.54 disabled women found a job

## 3 healthcare benefits

medical debt

long term

no need for infra



# SUM

## 1 education

1 spending enough and already too high

2 education quality important. even if they can go to school in pro's world, they are going to receive low quality years of education. while we con provide the better quality education, better than pro

3 tourism reduce education fee by 50%

## 2 vulnerable groups

1 95% from the US. US welfare different from chinese. so we don't see why that evi is effective

2 our evi tell you that only 17% of them were able to find jobs

3 disabled can work with the job created by us con side

## 3 healthcare & water supply & sanitation

1 our opp said enough, but we tell you that still 30% water is lost becasue of aging infrastructure. more spending is still needed to renew it. and also, this is the way to solve the water pollution and water shortage

2 our opp ignored our sanitation point, by 

impact: 62 thousand death and 2.9 million life disability in China.

## 4 jobs

1 jobs nedede. 20 million

2 vocational schools

already covered by welfare, many free

needs funding. solve jobs problem

## 5 agriculture

1 our opp said it turns the agriculture. but actually we tell you that we increase spending in agri in some places and tourism in other places. they don't contradict

2 do not replace jobs. precise

instead, 36 thousand $



# SH YKPao LM PRO

# Rebuttal

> our opp mentioned many evi saying infra not enough. but we tell you judge that their evi are outdated. while i'm going to explained the newest evi in my rebuttal

fw: multidimentional poverty

> their impact evidence of poverty alleviation is all based on the financial poverty line
>
> so we should not use their multidimentional framework

## 1 economic growth

### 1 gov poverty

e-commerce inc economy

> First, increase spending on infrastructure do not have much economy benefit because of corruption and overspent. According to the world bank, public infrastructure projects lose on average 10 to 30% of their budget to corruption. And there was a 31% overspend on these projects, and three-quaters suffered cost overruns. Data from oxford university shows that infrastructure cost overruns have equalled approximately one-third of China’s $28.2 trillion debt.
>
> Second, we see no relationship between poverty reduction and economic growth. In 2001 to 2012, the economy develop fast, while the poverty reduction speed dropped from 10% to 7%. This tells you judge that economic growth do not alleviate poverty.

### 2 private investment

shorten inequality

IMF: one dollar, welfare improve

> But, we tell you that increase public investment has nothing to do with private investment. According to official data, the share of state investment increase from 37% to 42% in 2019, while the private investment drop from 48% to 44%, showing there is no relationship between them. 

## 2 job creation

20 million new jobs needed

generates 1 million jobs per year

poverty drop

>First, jobs are enough as there are huge jobs vacancy. According to Forbes, 78% of companies in Shanghai said they don’t have enough workers.
>
>Second, even if you buy that they can go to work, this does not means they are out of poverty. Among the current workers in poverty, 62.6% are working full-time while they're still in poverty. There are nearly 65 million people who are defined as working poor in China. And there are estimated 53 million people with income below the poverty line. Thus only welfare can help in jobs.

## 3 e-commerce

only 44% access

10% boardband increase

5 billion create 1 hundred thousand

GDP increase by 1%, poverty drop by ...%

fill deficit

> First, we've already have e-commerce in rural area. According to Xinhua Net,the boardband coverage has already reached 98%, and that is the newest evi. According to CGTN, China's e-commerce has covered all 832 poor counties. Thus there is no need to increase spending.
>
> Second, the real problem is the talaent gap. According to Techinasia, poor villages know little about the internet, not to mention e-commerce, and a shortage of local talent is the major problem. According to China Agricultural University, the talent gap would be risen to 3.5 million in 2025. Only by increasing spending on welfare on funding entrepeuner, we can have solvency.

## 4 social infra

### 1 hospital

needs 50b to provide 10 million beds

> 1 it is enough.
>
> In 2018, the china's hospital density amounted to 6.03 beds per thousand people, far more than the WHO recommendation.
>
> 2 needs welfare
>
> spending should go to welfare.16% households are still unable to bear their medical expenses. Those households need more welfare in order to get access to healthcare.

### 2 education

surpass Zhongkao

finish high school

75% shutdown

drop out

> 1 drop out issue caused by tuition fee
>
> Acocring to project partner, 60% drop out, 95% drop out
>
> 2 low-enrollment

## 5 roads

53% villages don't have paved roads

1.5\$ and 2$

ADB, every 10k yuan, 3.24 people out of poverty

> According to official report in 2019, China has already provided more than 99 percent of villages with paved roadways. And in January 2020, the last villages without a road is connected to the outside now. 



# FF

> improve welfare: infra helps welfare is not a reason not to increase spending in welfare. we still need to increase spending in order to get the benfits
>
> drop out case: agree to all the benfits

## 1 infra inherency

opp evi outdated

99% paved road coverage, opp give no evi about how many villages trucks can't get in

boardband coverage 98%. our opp said access, but access can only be solved by welfare as they need personal phones and computer

hc beds enough

## 2 e-commerce

first we tell you that it is enough

our opp said about trade, but they don't have solvency on trade because of talent gap, and entreprenues don't have money, can only solved by welfare

in just one project, 36k people out of poverty, increaseincome of more than 60k yuan

## 3 vulnerable group & jobs

jobs vacancy: 78% companies lack workers in 2020

also, our opp have no solvency on vulnerable groups, wchihc we tell you that accounts for 80% of the poverty

## 4 economy

we tell you that it is not a bit beneficial for the economy, for infra is enough, and it has already taken much debts

second, for private: truth

## 5 education

1 needs welfare for drop out

2 we have the solvency fo the 3/4 schools close because of low-enrolment

## 6 transitory poverty

91%

can only solved by welfare

## 7 gender inequality

no rebuttal

drop this

14% employment increase, 18% poverty drop



# SH YKPao LT

# Rebuttal

## 1 HC

infra enough

lower 25 drug cost by 90%

## 2 educational benefits

10% every year of education

60% drop out due to the cost

3/4 shut down due to low student enrolment

15 years of education

## 3 vocational training

## 4 vulnerable group

### SA disability

money support

### SB pension





# CON sum

## 1 Healthcare & Water & Sanitation

1 in our rebuttal we tell you that the infra is not enough, and our opp evi is only for the whole country not for the poor counties

2 simply cutting drug price is not feasible. gov already dump much money into hc, while it is still not actting well, showing the fundemental problem is not welfare not enough, but welfare ineffective and not feasible

3 while we prevent many bad diseases, and prevent the 36 thousand death and 2.9 million life disability which our opp gave no solvency. our opp said corruption, but they themselves don't have a answer to the loss of livs. but we tell you that and the water shortage can only be solved by us by building new infrastructure

## 2 Education & Jobs

1 we tell you that welfare spending is too much, and increase spending is also not effective. while we also tell you that tourism can reduce 50% of education fee

2 we tell you that infra is more needed for educatio to provide qualified education. and teachers quality is still not promised. fresh college graduates from rural families [earn](https://new.qq.com/omn/20191124/20191124A02UAM00.html) much less than urban ones. so, even if they don't drop out, because of the poor quality, they still don't have solvency

3 for enrolment, we say that our opp evi is outdated enrolment rates for China's senior high schools has already reached 82.5 percent and is expected to reach 90 percent by 2020.

4 vocational training. first we have already told you what infra we need. second we tell you that teaching in the vocational schools is more effective than welfare vocational training. In welfare vocational training, only 17% find jobs, but we tell you that graduates from those schools have exceeded 95.

## 3 vulnerable group

1 infra helped them by providing those jobs created by infra like online stores

2 job training mentioned by opp is not working

3 pension funds reformation more needed. we also proved that after reforming, it is going to solve the pension problem

## 4 agriculture

1 irrigation: our opp said about irrigation ineffective. that is supporting our side as it proves the lack of irrigation water saving technology and enough irrigation

2 5G: we've given cards that because it needs huge amount of information, thus it needs 5g. and also, in order to create the 57 thousand dollars income benefit, 5G is needed

support 78% of people

## 5 tourism

1 our opp said low satisfiction. but they only gave one example. we don't build tourism site where peple don't want. if they want the benefit, we give them. if they don't, we don't force them. so it don't pose a rebuttal towards our sides.

provide 36.8 million jobs for poor peole