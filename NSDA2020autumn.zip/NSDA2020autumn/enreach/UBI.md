## AT Expensive

1 not that expensive

https://qz.com/1355729/universal-basic-income-ubi-costs-far-less-than-you-think/

Universal basic income costs far less than you think

Cost estimates that consider the difference between upfront and real cost are a fraction of inflated gross cost estimates.

Economist Karl Widerquist, UBI of 12k \$ per adult only cost 539 billion in US, less than 3% of GDP

2 efficient in helping poverty



## AT dec incentive

1 poor people increase incentive

poor people get money from gov -> thankful -> have a chance to work -> work harder

2 dec unemployment

unemployment

https://www.forbes.com/sites/sarahhansen/2020/07/24/30-million-are-unemployed-and-more-pain-is-on-the-way-here-are-8-numbers-that-sum-up-the-destruction-in-the-us-labor-market/#1ed44a99161b

30 million in US

destruction in us labor market



## AT environment

1 jobs change

https://www.sciencealert.com/a-universal-income-can-help-us-mitigate-our-climate-emergency-here-s-how

[UBI therefore eliminates extreme poverty and reduces dependency](https://www.thersa.org/discover/publications-and-articles/reports/basic-income). It gives people the agency to say "no" to undesirable work, including much environmentally damaging work, and "yes" to opportunities that often lie 2out of reach.

2 more jobs to help environment

Environmental policy can cause substantial job reallocation: fewer jobs in some industries and more jobs in others. In many cases, this reallocation will primarily involve reduced hiring in the industries that are negatively affected.

unemployment will inc if we do cc mitigation, and ubi is needed



## AT not solving root problem

1 poverty needs welfare

https://thehill.com/opinion/finance/424766-universal-basic-income-is-the-solution-to-a-worsening-problem

However, right now, in the wealthiest country in the history of the world, in the eighth year of an economic expansion, 44 percent of Americans can’t afford an unexpected $400 bill. ubi is the only way to solve

people suffer 

2 root problem is education and unemployment

10 k additional jobs

dropout rate dropped from 40% to almost 0%, solving the root problem





# PRO

## Constructive

## C1 poverty, jobs, dropout

> 1 laziness, get the money and don't work
>
> 2 even more jobs, no impact, can't force hire more people (no profit)
>
> > impact too small
> >
> > ignore the employment

## C2 less gender equality

>1 it doesn't have
>
>can only stay home
>
>(they can only listen if don't have )
>
>> more choice

## Rebuttal

## C1 expensive

to evey adults

1.9 t dollars

accidents

corona virus

> UBI make sure that people have enough money to prevent corona virus
>
> make corona spread less
>
> > country, not individual
> >
> > country have no money
>
> 1 not that expensive
>
> https://qz.com/1355729/universal-basic-income-ubi-costs-far-less-than-you-think/
>
> Universal basic income costs far less than you think
>
> Cost estimates that consider the difference between upfront and real cost are a fraction of inflated gross cost estimates.
>
> Economist Karl Widerquist, UBI of 12k \$ per adult only cost 539 billion in US, less than 3% of GDP
>
> 2 efficient in helping poverty, eductaion, unemployment -> gain more

## C2 laziness

>1 poor people increase incentive
>
>poor people get money from gov -> thankful -> have a chance to work -> work harder
>
>2 dec unemployment
>
>unemployment
>
>https://www.forbes.com/sites/sarahhansen/2020/07/24/30-million-are-unemployed-and-more-pain-is-on-the-way-here-are-8-numbers-that-sum-up-the-destruction-in-the-us-labor-market/#1ed44a99161b
>
>30 million in US
>
>destruction in us labor market
>
>3 poor people not lazy, but they can't have edu and job
>
>https://thehill.com/opinion/finance/424766-universal-basic-income-is-the-solution-to-a-worsening-problem
>
>However, right now, in the wealthiest country in the history of the world, in the eighth year of an economic expansion, 44 percent of Americans can’t afford an unexpected $400 bill. ubi is the only way to solve
>
>10 k additional jobs
>
>dropout rate dropped from 40% to almost 0%, solving the root problem
>
>> farmers don't work
>>
>> dec of gdp
>>
>> can't fight ever issues