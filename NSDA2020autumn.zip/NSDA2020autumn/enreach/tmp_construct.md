The agriculture E-Commerce and Smart Agriculture strongly relies on internet. But the internet coverage, according to Nanjing Marketing Group, the rural internet penetration rate is only 18.5%, and only increase spending in building agriculture and internet infrastructure can solve the problem, and make great impact.

https://www.nanjingmarketinggroup.com/blog/rural-chinese-internet-usage-2011_10_27

# Healthcare

According to CGTN, At the end of 2018, after over 700 million people had been lifted out of poverty. But among them, the proportion reduced to poverty, or returned to poverty, because of illness is as high as 40 percent. Thus, poverty alleviation via healthcare has become a primary focus of China's fight against poverty. [1] That is mainly caused by a lack of medical infrastructures,  by 2015 there were only 3.66 beds per 1000 population, and 1.28 certified medical doctors or assistants per 1000 population in the 832 poverty stricken counties in China. [2] Moreover, the impact is more severe in endemic diseases, and it could be even persistent without strong health infrastructure. Poorer neighbourhoods are more likely to have higher rates of pre-existing health problems, such as [heart or lung disease, which can exacerbate the impact of the virus](https://www.washingtonpost.com/nation/2020/04/07/coronavirus-is-infecting-killing-black-americans-an-alarmingly-high-rate-post-analysis-shows/?arc404=true).

Welfare isn't effective on healthcare. The health problem is still huge in poor people, Almost 90 percent of the medical bills of needy patients are now covered by the government in China, but still those who get the welfare are suffering from diseases. The welfare can only solve one small and specific disease for one guy, but infrastructure is helping the people's health lifelong. And in special occasion such as epidemic, only infrastructure help solve problems as the quarantine and daily care.





https://news.cgtn.com/news/2019-10-17/Poverty-alleviation-via-healthcare-KQ2aiQGjiE/index.html 



AT urban poverty

1 smart agriculture raise sales, and lower down the price, make food more affordable, thus let more people living both in the urban area and rural area stop suffering from hungers.

2 when building infrastructure, jobs will be created. According to Kane, 2015, every $1 billion in infrastructure spending can directly and indirectly create up to 13,000 jobs a year.

 https://www.brookings.edu/research/expanding-opportunity-through-infrastructurejobs/) 

AT children

1 many children problem are caused by malnutrition

A third of children in poverty have iron deficiency which can stunt brain development <sup>p1]</sup>, and the only way to solve this problem is to increase the growth of agriculture and stop the hunger and malnutrition. 

And the only way to solve this problem persistently is to have greater agriculture by increasing spending of infrastructure