## $\texttt{what is welfare}$

- is it okay for our society to let poor people die
- if not, what should we do
- basic human needs
- social security
- equal opportunity
- state intervention

## $\texttt{employment}$

- unemployment insurance
- worker's compensation
- minimum wage
- sick leave

## $\texttt{disability}$

## $\texttt{healthcare}$

- medical insurance
- Medicare & Medicaid (US)
- how much should this cost
- what if i can't afford it

## $\texttt{elderly}$

- retirement
- pensions
- why don't the families provide for this instead

## $\texttt{childcare}$

- maternity leave
- parental leave
- tax deductions
- free kindergarten>
- pre-K?

## $\texttt{welfare}$

- free / universal
- subsidized
- vouchers
- did they pay into it before?
- means-tested
- which welfare programs have the biggest impact on alleviating poverty?

## $\texttt{what is infrastructure}$

- just the buildings and roads?
- why can't the free market provide for this?
- who benefits from this?
- how benefit people in poverty?

## $\texttt{transportation}$

- highways, streets, oads
- bridges
- mass transit & metro
- ...

## $\texttt{water}$

- water supply
- water resources
- filtration
- irrigation
- canals
- levees
- dams

## $\texttt{sanitation}$

- wastewater
- solid-waste
- hazardous waste treatment
- 垃圾分类

## $\texttt{energy}$

- electric power generation
- power plants
- dams
- wind power, solar power, etc.
- electricity transmission
- power grid

## $\texttt{communication}$

- telecommunications
- information technology
- internet
- 5G
- postal service

## $\texttt{education}$

- schools
- primary
- university
- vocational schools

## $\texttt{financial}$

- banks
- loans
- debit, credit cards
- alipay

## $\texttt{military}$

- military bases
- deployment
- airfields
- aircraft carriers

## $\texttt{iron rice bowl}$

- guaranteed job security
- government will provide
- don't have to worry about losing job & not having money

## $\texttt{hukou}$

- household registration
- permanent resident
- based on location
- rural / urban
- re
- revised & reformed

## $\texttt{SOE}$

- state-owned enterprises
- government has a lot of control
- not necessarily to make profit
- public policy goals

## $\texttt{stakeholders}$

- people in poverty
- homeless
- jobless (job training programmes)
- disabled 
- migrant workers
- retired
- left-behind children
- farmers

## $\texttt{PRO Contentions}$

- healthcare, medical
- elderly
- disabled
- job training, employment
- education
- childcare, left-behind children
- dibao
- urban poverty

## $\texttt{CON Contentions}$

- transportation
- 5G
- technology, internet
- energy infrastructure
- financial, microcredit
- agriculture
- resettlement
- belt and road

## $\texttt{__}$

- corruption
- inequality
- hukou
- extreme/mild poverty
- cost-effectiveness
- direct/indirect
- short-term/long-term

