# Class3

## $\texttt{3 major types of evidence }$

### Anecdote

one example of the claim being true

a personal story

a story you read about

### Statistics

numerical data

scientific studies

surveys

### Testimony

expert opnion

statements from academics or professionals



# CLASS 5

| Deontology               | Ultilitarianism                                      |
| ------------------------ | ---------------------------------------------------- |
| Means > Ends             | Ends > Means                                         |
| Do the right thing       | Greatest good for the<br />greatest number of people |
| Based on principle       | Maximize happiness<br />Minimize suffering           |
| *Categorical Imperative* |                                                      |

### Contention

#### PRO

1. autonomy
2. alleviate pain, reduce suffering
3. efficient use of resources
4. people support
5. helps the families cope psychologically
6. families avoid financial debt
7. dignity
8. regulations
9. underground PAS

#### CON

1. hippocratic oath
2. ethics: sanctity of life
3. 
4. misdiagnosis
5. slippery slop $\to$ euthanasia
6. hospice instead
7. suicide contagion
8. bias
9. no consent, pressure
10. harms PC (med dev)
11. moral hazard

