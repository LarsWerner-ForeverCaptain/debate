based on biology, if the body needs medicine to stay alive, then he has the right to live; else, he doesn't.

equality: current thing not equal (some people can refuse treatment and die while others don't)

### intend

- different from 'impact' / result
- to kill? to let die? to minimize pain? to respect autonomy?
- "the law of double effect" 
- **allow everyone to refuse treatment, prohibit PAS for everyone**

### limits of autonomy

- should healthy people have PAS ? 
  - Yes $\to$ everyone has PAS = bad
  - No $\to$ but doesn't this destroy their autonomy

### CodeForces

1 "Can you clarify the logic behind contention 1"

   no open-end questions

2 expose errors

- make them look weak
- question their author qualifications
- ask about the specifics of their evidence
- don't be obvious about setting a trap
- listen if their evi actually supports their claim

3 obtain admissions

- delimma questions - be prepared for no matter how they answer
- answer with qualification first before saying "yes/no

4 set up arguments

- alley-loop (set up / assist)
- don't answer their question "i reject the premise of your question"
- ask about common framework dilemmas: morality vs economy
- do they give you clues

5 save prep time

- work backwards - imagine your goal

- make a list of prepared questions

6 questions to avoid

- How do you guarantee ___?
- Don't you agree that 
- What do you think of that

