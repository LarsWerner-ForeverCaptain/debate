# PRO

## Evidence

### Economy Benefit

> https://www.theglobeandmail.com/news/national/assisted-suicide-could-save-canada-up-to-138-million-a-year/article33701475/

​	Canada's medical-aid-in-dying law could save the country's health-care system as much as $138.8-million a year

>https://hospicecare.com/policy-and-ethics/ethical-issues/essays-and-articles-on-ethics-in-palliative-care/euthanasia-and-physician-assisted-suicide-are-they-clinically-necessary-or-desirable/

​	13% of the 1.6 trillion dollars spent on personal health care in the USA was devoted to care of individuals in their last year of life. But if PAS is legalized, the saving would be enormous - at least 21 billion dollars. (in US)

### Impact of inequality

> [Chandran Kukathas](https://en.wikipedia.org/wiki/Chandran_Kukathas), "Ethical Pluralism from a Classical Liberal Perspective,"

Equality before the law is one of the basic principles of liberalism. This principle arises from various important and complex questions concerning equality, fairness and justice.

> https://ilr.law.uiowa.edu/print/volume-99-issue-3/equal-law-in-an-unequal-world/

The principle that the law must be general—that it must apply equally to all—is a fundamental demand of legal morality, associated with the ideal of the rule of law.

### Regulation Possible

> https://theconversation.com/safe-assisted-dying-laws-are-possible-so-lets-make-them-13653

​	There are now also a number of reports around the world concluding that safe reform is possible. This was the view of the [Quebec Select Committee on Dying with Dignity](http://www.assnat.qc.ca/en/actualites-salle-presse/nouvelle/actualite-25939.html) in 2012 and the position taken in Tasmania by the premier, Lara Giddings, and leader of the Greens, Nick McKim, in their 2013 [consultation paper](http://www.premier.tas.gov.au/__data/assets/pdf_file/0007/185578/Voluntary_Assisted_Dying_-_A_Proposal_for_Tasmania.pdf).

​	Legislative safeguards can be drafted to ensure only patients who are “eligible” can receive legal assistance to die.

> https://www.researchgate.net/publication/288752064_The_regulation_of_euthanasia_How_successful_is_the_Dutch_system

​	From 1998 until 2008, more than 2 million cases have been reported to the review committees. Only in 38 cases they have concluded that the doctor had not satisfied the legal criteria of careful action.

​	The system as a whole has a clear restrictive effect on the conditions in which patients are considered to be eligible for having their request accepted.

### Autonomy

> https://healthresearchfunding.org/physician-assisted-suicide-statistics/

In 2013, some 34% of Americans stated in a Pew Research poll that they had given serious consideration to their end of life decisions. Some 35% of those said that they had put their wishes in writing.

## <font color = gren> Blocks</font>

## AT Abuse

> E Dahl and N Levy The case for physician assisted suicide: how can it possibly be proven? J Med Ethics. 2006 Jun; 32(6): 335–338. doi: 10.1136/jme.2005.012864     

==Permitting PAS== or voluntary active euthanasia (VAE) ==may actually decrease the number of cases in which doctors withhold or withdraw life sustaining medical treatment without the patient's explicit request.==

​	That it is  possible that legalising PAS reduces the number of abuses, for several reasons: because patients are able to remain  rational longer when they do not fear losing control over the timing and manner of their death; because the stricter oversight reduces the potential for abuses, and because doctors respond to requests for PAS by improving end of life care.

### AT Vulnerable group

>https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1995535/

​	A study by Battin and colleagues published in ***Journal of Medical Ethics* that analyses existing databases from Oregon and the Netherlands**... **They found no increased incidence of PAS in vulnerable groups.** (Elderly people, women, people with low socioeconomic status, minors, people in racial and ethnic minorities, and people with physical disabilities or mental illness.)

### AT Palliative Care / Hospice Care

**Complaints, Unsatisfied**

> https://www.nytimes.com/2018/01/06/opinion/sunday/hospice-good-death.html

​	Kaiser Health News discovered there had been 3,200 complaints against hospice agencies across the country in the past five years.

**Expensive**

> https://www.griswoldhomecare.com/blog/hospice-palliative-care-at-what-cost/

​	The price of the cheapest hospice & palliative care is \$151 per day, and the most expensive on is \$976.

**Worse phychological symptoms**

> https://khn.org/news/palliative-care-sometimes-adds-to-families-stress-burden-study-finds/

​	Researchers found no significant difference in anxiety and depression symptoms between the groups, but the meetings with palliative care specialists “may have increased post-traumatic stress disorder symptoms,” they reported.

**Side Effect**

> https://www.webmd.com/palliative-care/qa/what-are-side-effects-of-drugs-taken-for-pain-during-palliative-or-hospice-care

​	The drugs during palliative or hospice care have side effects such as drowsiness, nausea, and constipation.

> https://www.verywellhealth.com/morphine-and-pain-side-effects-and-use-1132339

​	Serious side effects of morphine ... include slow, shallow or irregular breathing, blue color to the skin, seizures, ...

**Still not good enough**

> https://www.theguardian.com/society/2016/mar/31/end-of-life-care-in-nhs-still-not-good-enough-report-finds

​	Those who die... may be denied the right care because only 11% of hospital trusts in England provide specialist palliative services around the clock, according to a detailed audit of end-of-life care.

​	Case notes showed that only 31% of patients were reviewed by a member of a specialist palliative care team within 24 hours of admission to hospital.

>https://www.cihi.ca/en/access-data-and-reports/access-to-palliative-care-in-canada/palliative-care-in-canada-inconsistent-patients-say

​	Few Canadian doctors specialize in providing palliative care, and just 12% of medical students were required to participate in mandatory clinical rotations in such care.

​	Only 15% of people who died in Ontario and Alberta in 2016-2017 received publicly funded palliative home care.

**Discrimination**

> https://www.forbes.com/sites/judystone/2017/12/19/racial-disparities-in-end-of-life-care/#f2c074e28a3e

​	Of 145,000 Medicare beneficiaries in these hospices for end of life care, 92 percent were white patients and 8 percent black patients.

​	Black hospice patients were significantly more likely than white patients to disenroll from hospice prior to death. (18.1% to 13.0%)

> https://www.nytimes.com/2019/06/29/opinion/sunday/hospice-end-of-life-racism.html

​	While 74 percent of white patients with bone fractures in an Atlanta emergency room received pain medications, 57 percent of African-Americans did. African-American children with an appendicitis were 44 percent as likely to receive medications for pain as white children.

​	Why is this? ... On the patient side, there is often powerful distrust of the health care system, a fear that we doctors — who are mostly white — will deprive them in their time of need. On physicians' side, the fear of being perceived as racist or somehow embodying an oppression he is often blind to. When these factors collide, doing more can be a temporary salve.

> https://www.who.int/news-room/fact-sheets/detail/palliative-care

**Worldwide, only about 14% of people who need palliative care currently receive it.**



# CON

## <font color = gren>Evidence</font>

### Misdiagnosis

​	The Voluntary Euthanasia Society is prepared to accept a certain level of ‘collateral damage’ (mistaken killing) in order to achieve its aims and objectives.None of the visiting pro-euthanasia experts such as ever expresses any sorrow for the thousands of people who have been euthanized either as a result of poor diagnosis

also, see https://www.ftadviser.com/pensions/2017/11/28/most-over-50s-underestimate-life-expectancy/

### Vulnerable group

**Burdened people are pushed to PAS**

> Packet P91 University of Washington School of Medicine
> http://depts.washington.edu/bioethx/topics/pad.html

​	Vulnerable populations, lacking access to quality care and support, may be pushed into assisted death. 
​	 Burdened family members and health care providers may encourage loved ones to opt for assisted death and the protections in legislation can never catch all instances of such coercion or exploitation.

**Requests for burdened has rised to 1:3**

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1226254/

​	Requests for physician assisted suicide because of “being a burden” have risen in Oregon to 1:3 since its Death with Dignity Act was implemented.

**40% because of burden**

>https://euthanasiadebate.org.nz/resources/answering-our-opponents/legal-safeguards-cannot-protect-vulnerable-people/

​	In Oregon, where assisted suicide is legal, 40% of people who requested legal assisted suicide cited concern about being a burden as a reason for their decision.

**Legislation can't help**

>https://euthanasiadebate.org.nz/resources/answering-our-opponents/legal-safeguards-cannot-protect-vulnerable-people/

​	The relationship between a doctor and a patient is confidential. Much may happen behind closed doors with the doctor and the patient as the only witnesses. When a doctor has performed euthanasia on a patient, the doctor is the only remaining witness.

**New Zealand's Warning**

[	In the *New Zealand Herald*, ](https://www.smh.com.au/opinion/assisted-dying-laws-pose-a-grave-risk-to-the-vulnerable-20170904-gyaim0.html#)Simon O'Connor, the chairman of New Zealand's recent parliamentary commission into euthanasia warned:
	"It is very difficult to see how there could be sufficient safeguards to actually protect vulnerable people in New Zealand. And that's been the experience overseas as well."

### Discrimination



### Slippery Slope



### Worse care because of PAS

>https://www.smh.com.au/opinion/assisted-dying-laws-pose-a-grave-risk-to-the-vulnerable-20170904-gyaim0.html

​	Medical professionals report that the overwhelming majority of people in palliative care just want good care, not to have their death hastened. Euthanasia laws often create a disincentive to direct resources to palliative care.

**Physicians don't and are poor and helping because of PAS**

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1226254/

​	An average general practitioner cares for fewer than five dying patients a year; educational programmes consistently find general practitioners and hospital consultants are poor at controlling symptoms and relieving suffering... 

​	Many clinicians have seen suffering patients who they have been unable to help. Many doctors assume that they already kill frequently with PAS when they do nothing of the sort.

> http://www.hospicevolunteerassociation.org/HVANewsletter/0120_Vol6No1_2009Dec9_NowTheDutchTurnAgainstLegalisedMercyKilling.pdf

​	Legalised euthanasia has led to a severe decline in the quality of care for terminally-ill patients in Holland, it has been claimed. 

​	Even the architect of the controversial law has admitted she may have made a mistake in pushing it through because of its impact on services for the elderly. Without elaborating, she admitted that medical care for the terminally-ill had declined since the law came into effect.

​	Dr The, who has studied euthanasia for 15 years,  added that a crisis had developed and that 'to think that we have neatly arranged everything by adopting the euthanasia law is an illusion'.  



### Palliative Care

> https://www.who.int/3by5/en/palliativecare_en.pdf

**Money Saving**

> https://www.nbcnews.com/health/health-news/palliative-care-saves-money-study-finds-n870226

​	Those who got palliative care ended up with hospital bills that were more than \$3,200 lower than those who did not get palliative care, the study found. Cancer patients ended up spending more than ​\$4,200 less if they got palliative care.

### Suicide Contagion

> https://jemh.ca/issues/v9/documents/JEMH%20article%20Boer%20final%20proof.pdf

​	A 2017 study by Dutch researchers published in the Journal of Mental Health came to an even more startling conclusion: “… the option of euthanasia for people with psychiatric conditions does not reduce the number of nonassisted suicides [but] rather contributes to a rise in their numbers.”

> https://www.pthu.nl/over-pthu/organisatie/medewerkers/t.a.boer/downloads/2017-boer-jemh-euthanasia-suicide.pdf

​	‘There is [much] public discussion about ending your life,’ Latten said, ‘and people will tend to act accordingly’.

​	the Netherlands of all countries shows the largest increase in suicide numbers.

### Voluntary Issues

> https://link.springer.com/article/10.1007/s00134-019-05702-1

​	According to NEJM, of the 3882 deaths due to physician-assisted suicide or euthanasia in Flanders, Belgium, in the year 2013 alone, 1047 (27%) involved physicians deciding to administer medication dosages to hasten death without patients’ consent.

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	One in every 5 people is euthanized without having given explicit consent. Attempts at bringing those cases to trial have failed, providing evidence that the judicial system has become more tolerant over time of such transgressions.

​	A recent study found that in the Flemish part of Belgium,32% of euthanasia occurred in the absence of request or consent.

#### Hospital Economic Resource Saving Push

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	Of physicians in the Netherlands, 15% have expressed concern that economic pressures of hospital may prompt physicians to consider euthanasia for some of their patients; a case has already been cited of a dying patient who was euthanized to free a hospital bed.

### Mental Issues

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	In 2007, none of the people who died by lethal ingestion in Oregon had been evaluated by a psychiatrist or a psychologist.

​	In 2010, none of patients requiring PAS reveiced psychiatric consultation.

### Harm PC

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	At the UK parliamentary hearings, one Dutch physician asserted that “We don’t need palliative medicine, we practice PAS.”

​	In Switzerland in 2006, the hospital in Geneva reduced its already limited palliative care staff after a hospital decision to allow PAS.

​	Attracting doctors to train in and provide palliative care was made more difficult because of access to PAS.

### Slippery Slope

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	In 30 years, the Netherlands has moved from PAS of terminal illness to mental and chronically ones, and now to euthanasia simply if a person is over the age of 70 and “tired of living.” And Dutch protocols have also moved from explicit consent to involuntary euthanasia.

> https://healthresearchfunding.org/physician-assisted-suicide-statistics/

​	The practice (of PAS in Netherlands) is even legal for infants and newborns who are considered extremely disabled and has reportedly also been administered for those who were deemed “chronically depressed.”

### Human right (impact)

>https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	The UN has found that the pas law in the Netherlands is in violation of its *Universal Declaration of Human Rights* because of the risk it poses to the rights of safety and integrity for every person’s life. The UN has also expressed concern that the system may fail to detect and to prevent situations.



### Autonomy

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

Autonomy and choice are important values in any society, but they are not without limits. Our democratic societies have many laws that limit individual autonomy and choice so as to protect the larger community. These include, among many others, limits on excessive driving speeds and the obligation to contribute by way of personal and corporate income taxes. Why then should different standards on autonomy and choice apply in the case of euthanasia and pas?





## PAS Failure

> https://healthresearchfunding.org/physician-assisted-suicide-statistics/

​	The Netherlands report a failure rate of PAS upt to 25%



## <font color = gren>Blocks</font>

### AT Reduce Pain

**Only 1/3 use PAS because of pain**

> http://www.bbc.co.uk/ethics/euthanasia/overview/introduction.shtml

​	...Some surveys in the USA and the Netherlands showed that less than a third of requests for euthanasia and PAS were because of severe pain.

**Not becasue of pain**

> https://www.wsj.com/articles/SB852599842290814000

​	... Not a single rigorous study has demonstrated that it is patients in pain who, as a rule, are motivated to seek euthanasia.



**Pain can be controlled and treated** 

> Packet P193 Yuill 13 (University of Sunderland, UK) 

​	Pain control continues to improve with techno- logical advances being made.

​	Palliative sedation, whereby patients in pain are put into a deep sleep until they die naturally, might be posed as an excellent compromise, preventing the need for assisted suicide. 

> Packet P195 Pellegrino (Director; Center for Clinical Bioethics Georgetown University) 98 

​	What is often diagnosed as untreatable pain is actually inadequately treated pain which can be relieved without rendering the patient unconscious. With the optimum and judicious use of those measures, there are virtually no patients whose pain cannot be relieved.

**PAS not painless**

> http://opinionator.blogs.nytimes.com/2012/10/27/four-myths-about-doctor-assisted-suicide/

​	It turns out that many things can go wrong during an assisted suicide. Patients vomit up the pills they take. They don’t take enough pills. They wake up instead of dying. Patients in the Dutch study **vomited up their medications in 7 percent of cases**; **in 15 percent of cases, patients either did not die or took a very long time to die — hours, even days**.

### AT Regulation (Report)

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1226254/

​	**Dutch legislation has failed to improve reporting beyond 54% of all cases **or to limit therapeutic killing without consent which accounts for about 14% of reported cases.

> https://euthanasiadebate.org.nz/resources/answering-our-opponents/legal-safeguards-cannot-protect-vulnerable-people/

​	In Belgium and the Netherlands euthanasia laws are regularly circumvented by some health professionals. Each of the safeguards have been ignored. According to a 2010 study, **32% of euthanasia deaths in Flanders, Belgium, occurred without an explicit request.**

**Not Reported**

>https://www.smh.com.au/opinion/assisted-dying-laws-pose-a-grave-risk-to-the-vulnerable-20170904-gyaim0.html

​	In a study of states with euthanasia law, published in *Current Oncology*, Dr J. Pereira writes that  "About 900 people annually are administered lethal substances without having given explicit consent, and in one jurisdiction, **almost 50 per cent of cases of euthanasia are not reported**."

> https://pure.uva.nl/ws/files/1519079/126649_395121.pdf

​	 The number of cases of euthanasia and physician-assisted suicide was lower than most observers had expected.

### AT Right to Die & Live, Autonomy

**A right to live $\neq$ a right to end lives**

> https://oneill.law.georgetown.edu/an-international-human-right-to-die-with-dignity/

​	According to the European Court of Human Rights (ECHR), "the right to live ... cannot be interpreted as conferring the diametrically opposite right, namely a right to die", nor does the right to life "created a right to self-determination in the sense of conferring on an individual the entitlement to choose death rather than life."

**Harm Vulnerable group**

### AT Financial Issues

> https://www.statista.com/statistics/571530/netherlands-national-health-expenditure/

​	In 1998, the healthcare spending in Netherland is 30 billion euros, while in 2018, the healthcare spending in Netherland is 90 billion euros, and the number keeps rising. That shows that euthanasia doesn't really have great economy benefit, or even have no economic benefit, or even worsen it.