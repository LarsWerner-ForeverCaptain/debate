# PRO

## AT Abuse

We've proved that the legalization of PAS can make PAS clean and decrease or solve the underground PAS problem. How can regulations under current system stop all that?

## AT Misdiagnosis

How many people who can live much more than 6 months but are misdiagnosed and euthanized?

## AT PC

According to Forbes, Judy Stone, Black hospice patients were significantly more likely than white patients to disenroll from hospice. Even if hospice can reduce pain, how are those black terminally ill patients who are discriminated going to have a peaceful death in our opponent's world?

## AT Insurance Company

How much money can insurance company purely gain if they refuse services?

How much money do insurance companies lose if PAS become legalized that they have to push person to death?

## AT Family, Financial Pressure

Can those people who have family burden enjoy autonomy and the right to have a peaceful death?

Why family enrollment is all bad, and considering for family is no autonomy?

Are there any way for those who have financial pressure and can't afford palliative care to die in peace?

## AT Suicide Contagion

Why all the suicide rate increase is directly linked to the legalization of PAS ?

What's the suicide rate changes in Belgium? (2005~2015, 8.5% dec, 23 to 21)

## AT Vulnerable Group

How many vulnerable people can have the autonomy to decide to have a peaceful death or not in con's world?

## AT PAS painful

How is PAS more painful then weeks of months of suffering in severe pain?

How unclean and underground PAS which will exist in con's world be better than the clean and regulated PAS in our world?

## Underground PAS

Do our opponent think that regulations for PAS is needed?



# CON

## AT Organ Donation

​	How many more people will be saved in pro's world than in status quo, and compared to those innocent lives being abused and lost in pro's world, how is the number of people saved greater? 

## AT Economy

> https://www.sprc.org/about-suicide/costs

​	What's the total medical cost changes in ...,  (Dutch, 30b -> 90b)

​	The average cost of one suicide was $1million. How much more economy benefits does it have compared to the more than billions of dollars it can take due to suicide contagion?

## AT Autonomy

Is every self-determination autonomy and are there limits?

## AT Pain Relief

1 how are they going to follow the regulation after pas legalized, if they don't follow the law now about not to 





