## Euthanasia vs PAS

difference: Euthanasia made by doctors, PAS made by patients and taught or assisted by physicians (like giving the pills).

- **Voluntary**: conducted with consent
- **Not Voluntary**: unable to consent
- **Involuntary**: does not give consent
- **Passive**: withhold life-sustaining treatments
- **Active**: use lethal substance to end their life`

r