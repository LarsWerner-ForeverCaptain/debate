# PRO

## IMPACT

Abuse of power of physicians to subjectively mistaken killing non-ti patients



## AT Status Quo Good

### Grey areas

> Cohen-Almagor, Raphael and E. Wesley Ely. "Euthanasia and palliative sedation in Belgium." BMJ Supportive & Palliative Care, vol. 8, no. 3, 1 Sept. 2018, pp. 307-13, doi:10.1136/bmjspcare-2017-001398.

​	There are many grey areas in the status quo, and we need to fix that and make PAS legalize in a clear way. First, physicians understand different practices as being complicit with ‘euthanasia’. Second, there is a grey area between sedation intended only to relieve suffering versus sedation deliberately intended to hasten death. Third, the use of sedation abuse occurs when clinicians sedate patients at the end of their lives with the primary goal of hastening death.

## AT Abuse & Crime

### (Link Turn) PAS reduces abuse

> E Dahl and N Levy The case for physician assisted suicide: how can it possibly be proven? J Med Ethics. 2006 Jun; 32(6): 335–338. doi: 10.1136/jme.2005.012864     

​	Permitting PAS may actually decrease the number of cases in which doctors withhold or withdraw life sustaining medical treatment without the patient's explicit request.

​	That it is possible that legalising PAS reduces the number of abuses, for several reasons: because patients are able to remain  rational longer when they do not fear losing control over the timing and manner of their death; because the stricter oversight reduces the potential for abuses, and because doctors respond to requests for PAS by improving end of life care.

## AT Vulnerable Group (financial pressure)

### Non-uniqueness (evi fallacy)

1 pressure appears in everything in healthcare system, and not legalizing PAS can't make it better.

2 basically almost everyone who make to the end of life would have such kind of so called burden or pressure, so it is not biased to vulnerable group.

### Evi against it

>https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1995535/

​	A study by Battin and colleagues published in ***Journal of Medical Ethics* that analyses existing databases from Oregon and the Netherlands**... **They found no increased incidence of PAS in vulnerable groups.** (Elderly people, women, people with low socioeconomic status, minors, people in racial and ethnic minorities, and people with physical disabilities or mental illness.)

> Ganzini, Linda, et al. "Experiences of Oregon Nurses and Social Workers with Hospice Patients Who Requested Assistance with Suicide." N. Engl. J. Med., vol. 347, no. 8, 22 Aug. 2002, pp. 582-8, doi:10.1056/NEJMsa020562.

​	Only 3 percent reported that the family members of patients who received prescriptions were more financially burdened. 

### Regulations solve

The regulation of PAS have a lot of confirmation and 15 days to let you think whether you really want to have PAS or not. 

### Poor's autonomy / peaceful death

> https://www.theguardian.com/us-news/2020/jan/07/americans-healthcare-medical-costs

The poor can't afford treatment —— According to The Guardian, 2020, Millions of Americans – as many as 25% of the population can't get enough medical help because of skyrocketing costs. And palliative care, which can cost at least \$ 150 per day is also unaffordable for the poor. If we don't legalize PAS, then those poor people will die in severe pain. But if we legalize it, the bias in way to end their lives can be solved, and poor can have such peaceful death with dignity.

### Sign of autonomy and shows respect for the disabled

> Ouellette, 6 – Associate Lawyering Professor, Albany Law School; Director, Program in Health Law and Ethics, Alden March Bioethics Institute (Alicia, 85 Or. L. Rev. 123, “Disability and the End of Life”, lexis 

​	The theory that laws allowing choice in dying perpetuate disability discrimination is flawed by conflation, inflation, misidentification, and a misplaced operational definition of disability. Specifically, the theory conflates dying with disability and misidentifies a persistent vegetative state as a disability that permits meaningful life. The conflation and misidentification allow the community to cast decisions to withhold or withdraw feeding tubes as disability prejudice, when such decisions are, in fact, an affirmation of autonomy and a showing of respect for individual values.



## AT Insurance Company

> Life Insurance, Living Benefits, and Physician-Assisted Death
>
> Frederick R. Parker, Jr., J.D., LL.M., Harvey W. Rubin, Ph.D.,y and William J. Winslade, J.D., Ph.D.

​	PAS warrant steps by the insurance industry to seek a contract structure designed to remove the risk that a person would choose that option because of financial concerns. And life insurers should provide generous living benefit options to insureds who contract a terminal illness.

​	Insurance Company don't pay for the most expensive option, but pay for the reasonably priced palliative care. And patients still have to pay to companies when they're still alive, so that means in order to get more money, insurance companies won't urge patients to die. 

## AT Family problem

### Family's involvement could prevent against rash decision (at family inv.)

> Brody, Howard. "Physician-Assisted Suicide: Family Issues." Michigan Family Review, vol. 01, no. 1, 1995, doi:10.3998/mfr.4919087.0001.103.

​	According to Brody, Howard, "Close family members prevent the suicide of patients who act precipitously, or who are acting out of character in a way that may signal an as-yet-undiagnosed mental illness." The involvement of family can prevent patients' unwise decision and rash, and actually prevent the patients' death of pressure and feeling that they have too much burden.

### Family get less mental diseases

> https://www.ohtn.on.ca/rapid-response-impact-of-medical-assistance-in-dying-on-family-and-friends/

​	In several studies, the family and friends of patients who requested medical assistance in dying had less traumatic grief symptoms compared to family and friends of patients who died of natural causes.



## AT Depression

> https://arizonalawreview.org/pdf/60-1/60arizlrev115.pdf 
> Arizona Law Review (Spring 2018) In the landmark MacArthur Treatment Competence Study

​	Researchers found that people who are severely depressed generally retained the capacity to make treatment decisions. Most hospitalized patients with serious mental illness have abilities similar to persons without mental illness for making treatment decisions.

## AT Physician's Duty / HO

## AT Palliative Care

### Unaffordable for poor

> https://www.griswoldhomecare.com/blog/hospice-palliative-care-at-what-cost/

​	The price of the cheapest hospice & palliative care is \$151 per day, and the most expensive on is \$976. That makes palliative & hospice care unaffordable for many people. Then our opponent is depriving the right of the poor to have a peaceful death, which is truly discrimination.

### Side Affect of PC

>https://khn.org/news/palliative-care-sometimes-adds-to-families-stress-burden-study-finds/
>
>https://www.webmd.com/palliative-care/qa/what-are-side-effects-of-drugs-taken-for-pain-during-palliative-or-hospice-care

​	Researchers found that the meetings with palliative care specialists “may have increased post-traumatic stress disorder symptoms,” Apart from that, the drugs during palliative or hospice care have side effects such as drowsiness, nausea, and constipation. So during palliative & hospice care, patients can’t be peaceful and might suffer from disorder symptoms.

### Immature and unsatisfying

>https://www.nytimes.com/2018/01/06/opinion/sunday/hospice-good-death.html
>
>https://www.theguardian.com/society/2016/mar/31/end-of-life-care-in-nhs-still-not-good-enough-report-finds
>
>https://www.cihi.ca/en/access-data-and-reports/access-to-palliative-care-in-canada/palliative-care-in-canada-inconsistent-patients-say

​	Kaiser Health News discovered there had been 3,200 complaints against hospice agencies across the country in the past five years. [4] Those who die... may be denied the right care because only 11% of hospital trusts in England provide specialist palliative services around the clock. [5] The terminal illness patients can’t get the right palliative care as there are not enough places, and hospice agencies can’t let them satisfied. 

### Discrimination & Bias

> https://www.forbes.com/sites/judystone/2017/12/19/racial-disparities-in-end-of-life-care/#f2c074e28a3e
>
> https://www.nytimes.com/2019/06/29/opinion/sunday/hospice-end-of-life-racism.html

​	The bias in end of life care system is a huge problem. Of all Medicare beneficiaries in these hospices for end of life care, 92 percent were white patients and 8 percent black patients. Also, black hospice patients were significantly more likely than white patients to disenroll from hospice prior to death.

​	There are also bias in treatment and care. According to NY Times, 2019, While 74 percent of white patients with bone fractures received pain medications, 57 percent of black did. African-American children with an appendicitis were only 44 percent as likely to receive medications for pain as white children.

### Can't solve emotional trauma

> Dr. Keith, Institute for Rehabilitation Research and Development, The Rehabilitation Centre, Ottawa, Ontario, “Attitudes of Terminally Ill Patients Toward Euthanasia and Physician-Assisted Suicide”, 2000, http://www.eutanasia.ws/hemeroteca/t369.pdf 

​	According to Dr. Keith, Institute for Rehabilitation Research and Development, even with good care, there will still be patients who would prefer to end their lives, it is not necessarily extreme physical distress that motivates this desire. Rather, the psychological and existential dimensions of suffering, which are no less central in determining quality of life-also emerge as important reasons behind requests for PAS. 

## AT Harm PC 

### Improves PC

> LISA SCHENCKER，“Assisted-Suicide debate focuses attention on palliative, hospice care”, Modern Healthcare, 05/16/2015, https://www.modernhealthcare.com/article/20150516/MAGAZINE/305169982/assisted- suicide-debate-focuses-attention-on-palliative-hospice-care

​	Studies in 2015 indicate that Oregon's law has led to improvements in palliative and hospice care. Thirty percent of Oregon doctors who responded to a 1999 survey said they had increased the number of patients they referred to hospice after voters approved the law. Three- quarters of responding doctors who had cared for terminally ill patients said they had worked to improve their knowledge of pain medication for those patients, according to a 2001 article in JAMA. 

## AT suicide contagion

### Evidence against

> https://www.macrotrends.net/countries/BEL/belgium/suicide-rate

​	In Belgium, the suicide rate from 2005 to 2015 has an 8.5% decrease (23 to 21).

> https://en.wikipedia.org/wiki/List_of_countries_by_suicide_rate

​	In Netherland, where PAS has been legalized for a long time, the suicide rate is only ranked 81 on the list of countries by suicide rate. And no PAS legalized states is in the top 20 countries where the suicide rate is the highest.

## AT Misdiagnosis

1 no exact evidence to prove how many people who can live more than 6 months but are misdiagnosed and e uthanized.

2 patients will go to many doctors to make sure it's true

> https://www.sutliffstout.com/wrongful-death-guide/average-settlement-amount/

3 if the doctors or hospital make a mistake and a healthy person take PAS, they will sued for hundred thousand dollars or even millions of dollars according to sutliffstout, so even from a money perspective they will make sure they don't make a mistake. So, for not to lose such much money, when PAS is legalized, doctors would try even better not to misdiagnose.

4 the misdiagnosis that con is talking about is usually not a healthy person misdiagnosed into terminal illness. the misdiagnosis they  mean is usually some moderate terminal illness who are judged into serious terminal illness, or even some patients' life expectancy be overestimated.

## AT Harm PC

### (Link turn) PAS improves PC

> LISA SCHENCKER，“Assisted-Suicide debate focuses attention on palliative, hospice care”, Modern Healthcare, 05/16/2015, https://www.modernhealthcare.com/article/20150516/MAGAZINE/305169982/assisted- suicide-debate-focuses-attention-on-palliative-hospice-care

​	Studies in 2015 indicate that Oregon's law has led to improvements in palliative and hospice care. Thirty percent of Oregon doctors ... said they had increased the number of patients they referred to hospice after voters approved the law. 75% of responding doctors who had cared for terminally ill patients said they had worked to improve their knowledge of pain medication for those patients, according to a 2001 article in JAMA. 

> https://www.sciencedirect.com/science/article/pii/S0885392419310668

​	Research on assisted dying practices in Canada, the U.S., and some European countries indicates that 80% of persons who opt for assisted dying also receive hospice or palliative care services. Assisted dying and palliative care practices have each developed separately in differing periods and geographies.

## AT Pressure

### Non-Unique

Pressure appears in everything in healthcare system, and not legalizing PAS can't make it better, so it don't affect autonomy.

### EVI against it

>https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1995535/

​	A study by Battin and colleagues published in Journal of Medical Ethics* that analyses existing databases from Oregon and the Netherlands... They found no increased incidence of PAS in vulnerable groups including those pressured.

> Ganzini, Linda, et al. "Experiences of Oregon Nurses and Social Workers with Hospice Patients Who Requested Assistance with Suicide." N. Engl. J. Med., vol. 347, no. 8, 22 Aug. 2002, pp. 582-8, doi:10.1056/NEJMsa020562.

​	Only 3 percent reported that the family members of patients who received prescriptions were more financially burdened. 

# CON

## WTF of don't risk it

Legal P.A.S. could lead to extra deaths. Illegal P.A.S. could not lead to extra deaths. Even if there’s only one extra death, vote CON. PRO’s best benefit is supposedly to minimize pain of those already going to die. Vote CON and not a single extra person would die. Vote PRO and this may happen.

## AT Organ Donation

### Can't be widely done

> Wallis, C. (2020, May 01). The Morally Complex Mix of Euthanasia and Organ Donation. Retrieved July 08, 2020, from https://www.scientificamerican.com/article/the-morally-complex-mix-of-euthanasia-and-organ-donation/     

​	Combining euthanasia with organ donation is ethically fraught and not widely done. In Canada, [nearly two thirds](https://www.canada.ca/en/health-canada/services/publications/health-system-services/medical-assistance-dying-interim-report-april-2019.html) of people who qualify for PAS have active cancer and are therefore ineligible to donate organs; others may be too elderly. And for the rest, only a half went on to donate.

### Organs too damaged to donate

> Wallis, C. (2020, May 01). The Morally Complex Mix of Euthanasia and Organ Donation. Retrieved July 08, 2020, from https://www.scientificamerican.com/article/the-morally-complex-mix-of-euthanasia-and-organ-donation/     

​	Even if the patient is on life support and a decision is made to pull the plug, about 30 percent of the time the organs become nonviable as blood pressure drops and circulation grinds to a halt.

> https://www.noeuthanasia.org.au/assisted_suicide_a_lucrative_live_organ_market

​	Both European and Canadian laws require that ... organ procurement can’t begin until after the patient has been declared dead – typically between 2 and 10 minutes after the onset of pulselessness. As a result, organs are compromised by the period of ischemia that occurs before retrieval.

## AT Family Benefits

### Family Harm

> file:///C:/Users/chris/Documents/WeChat%20Files/wxid_l9rdwwm08rlm12/FileStorage/File/2020-08/wardle2016.pdf

 Family members of the person who commits suicide are neglected victims of assisted suicide. The evidence reviewed shows that the impact of assisted suicide upon the family is overwhelmingly destructive and devastating.

### Family mental problem

> https://www.ohtn.on.ca/rapid-response-impact-of-medical-assistance-in-dying-on-family-and-friends/
>
> Wagner B, Muller J, Maercker A. Death by request in Switzerland: Posttraumatic stress disorder and complicated grief after witnessing assisted suicide. European Psychiatry. 2012;27(7):542-6.

​	Studies have shown a higher prevalence of post-traumatic stress disorder (PTSD) and depression among family members or friends witnessing medical assistance in dying (5).

​	A larger quantitative study from Oregon, published in 2009, examined family members of patients... After a mean of 14 months post-death, 11% of family members in the medical assistance in dying group were depressed, 2% had prolonged grief, and 38% were receiving mental health care. One study from Switzerland published in 2012, 13% met the criteria for full PTSD, the prevalence of depression was 16%.



### TI pats (even children) pressured by family members

> https://www.nationalrighttolifenews.org/2015/07/dutch-expert-children-may-be-pressured-by-family-members-to-die-by-euthanasia/

​	... Boer explained, Around one in five patients who choose euthanasia in the Netherlands acts under pressure from family members, therefore children who die by PAS are also likely to be pressured by family members. 	

## AT Economic Benefits

> https://www.statista.com/statistics/571530/netherlands-national-health-expenditure/

​	In 1998, the healthcare spending in Netherland is 30 billion euros, while in 2018, the healthcare spending in Netherland is 90 billion euros, and the number keeps rising. That shows that euthanasia doesn't really have great economy benefit, or even have no economic benefit, or even worsen it.

## AT Physicians Benefits

### Doc's pressure increase

> https://www.nationalrighttolifenews.org/2015/07/dutch-expert-children-may-be-pressured-by-family-members-to-die-by-euthanasia/

​	Doctors are also feeling pressured by euthanasia. According to a study that was published by the KNMG last December, 70% of doctors had experienced pressure, while 64% felt it had increased in recent years.

## AT Resource Saving

### Palliative care also save money & resources

> https://www.nbcnews.com/health/health-news/palliative-care-saves-money-study-finds-n870226

​	Those who got palliative care ended up with hospital bills that were more than \$3,200 lower than those who did not get palliative care, the study found. Cancer patients ended up spending more than \$4,200 less if they got palliative care.

​	Sending terminal illness patients to hospice is also a way to solve the medical resources problem. Patients in hospice don't need too much medical resources, and these resourced saved can also be used to cure other people.

## Doctor urge death to save resources

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	Of physicians in the Netherlands, 15% have expressed that economic pressures of hospital may prompt physicians to consider euthanasia for some of their patients; a case has already been cited of a dying patient was hastened death to just free a hospital bed.

## AT Autonomy (right to die)

### Not true autonomy -- Doctors influence choice

>DutchNews.nl “Number of official cases of euthanasia rise 10% in the Netherlands” April 12, 2017

https://www.dutchnews.nl/news/2017/04/number-of-official-cases-of-euthanasia-rise-10-in-the-netherlands/

​	Boost of suicide death which is the doctors are using their authority both intentionally and unintentionally encourage the patient who are hesitating to choose PAS instead of palliative care. Convincing patients to suicide are nothing different to abet in a murder which is obviously harmful to the society. That is not autonomy, when physicians urge pats to die.

### Decrease Autonomy

> https://lawreview.avemarialaw.edu/wp-content/uploads/2020/04/WARDLE-CORRECT.pdf

​	PAS would radically decrease, not increase, individual self-determination, due to the significant risk of abuse. It poses substantial danger to people with disabilities and many other people in vulnerable circumstances. People with disabilities and depression are given lethal drugs in Oregon. The supposed safeguards in the Oregon and Washington don't really protect patients. 

### Autonomy aren't w/o limits

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	Autonomy and choice are not without limits. Our democratic societies have many laws that limit individual autonomy and choice so as to protect the larger community. 

​	The UN has found that the pas law in the Netherlands is in violation of its *Universal Declaration of Human Rights* because of the risk it poses to the rights of safety and integrity for every person’s life. Since PAS harm ..., ...

### Not Voluntary

> https://link.springer.com/article/10.1007/s00134-019-05702-1

​	According to NEJM, 27% of PAS in Flanders, Belgium involved physicians deciding to administer medication dosages to hasten death w/o consent.

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​	One in every 5 people is euthanized without having given explicit consent. Attempts at bringing those cases to trial have failed, proving that regulations can't help.

​	A recent study found that in the Flemish part of Belgium, 32% of hastening death are lack request or consent.

## AT Pain

### Not because of pain

> http://www.bbc.co.uk/ethics/euthanasia/overview/introduction.shtml
>
> https://www.wsj.com/articles/SB852599842290814000

​	According to WSJ, "Not a single rigorous study has demonstrated that it is patients in pain who, as a rule, are motivated to seek euthanasia.", and according to BBC. Some surveys in the USA and the Netherlands showed that less than a third of requests for euthanasia and PAS were because of severe pain.

​	While in Oregon, more than 40% of people who requested legal assisted suicide cited concern about being a burden as a reason for their decision, showing that more people do PAS are because of burden and pressure, (vulnerable group, pushed to PAS)



### PAS not painless

>http://opinionator.blogs.nytimes.com/2012/10/27/four-myths-about-doctor-assisted-suicide/

​	It turns out that many things can go wrong during an assisted suicide. Patients vomit up the pills they take. They don’t take enough pills. They wake up instead of dying. Patients in the Dutch study **vomited up their medications in 7 percent of cases**; **in 15 percent of cases, patients either did not die or took a very long time to die — hours, even days**.

> Emanuel, Ezekiel. "Euthanasia and physician-assisted suicide: focus on the data." Med. J. Aust., vol. 206, no. 8, 1 May. 2017, pp. 339-40, doi:10.5694/mja16.00132.

​	Technical problems, including difﬁculty ﬁnding a vein and administering oral medications, occurred in 9% of cases, and 8.8% of PAS cases had complications.

### Pain can be solved

>Packet P195 Pellegrino (Director; Center for Clinical Bioethics Georgetown University) 98 

​	According to Pellegrino, Georgetown University, What is often diagnosed as untreatable pain is actually inadequately treated pain which can be relieved without rendering the patient unconscious. With the optimum and judicious use of those measures, there are virtually no patients whose pain cannot be relieved.

​	(PC)

### More painful

> file:///C:/Users/chris/Documents/WeChat%20Files/wxid_l9rdwwm08rlm12/FileStorage/File/2020-08/Oregon_Pall_Care_Study.pdf

​	The prevalence of family-reported moderate or severe pain or distress before death in Oregon decedents increased from 30.8% to 48% after legalising PAS.

​	Decedents in 2000–2002 (after PAS legalized) remained approximately twice as likely to be reported to be in moderate or severe pain or distress during the last week of their live.

## AT Regulation

### Fail to report

​	**Dutch legislation has failed to improve reporting beyond 54% of all cases **or to limit PAS without consent which accounts for about 14% of reported cases. 	In a study of states with euthanasia law, published in *Current Oncology*, Dr J. Pereira writes that  "About 900 people annually are administered lethal substances without having given explicit consent, and in one jurisdiction, **almost 50 per cent of cases of euthanasia are not reported**."

## Slippery Slope

> https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/

​		In 30 years, the Netherlands has moved from PAS of terminal illness to mental and chronically ones, and now to euthanasia simply if a person is over the age of 70 and “tired of living.” And Dutch protocols have also moved from explicit consent to involuntary euthanasia.

## AT Popularity

> www.abc.com

1 not all things that are accepted by many people is right

  many people even don't know the true harm and benefits of PAS and then do choices

