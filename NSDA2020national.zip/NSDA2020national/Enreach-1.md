# $\texttt{Definitions}$

#### Euthanasia

Euthanasia, "merci killing", is the act of **deliberately** ending one's life to relieve **chronic and persistent pain or suffering**. 

Four types: voluntary, involuntary, passive, active

#### Assisted suicide

Assisted suicide is the practice of **deliberately** aiding a person to commit suicide.

Physician-assisted suicide, involves providing a person with the means to end their life.

![image-20200613110328081](C:\Users\chris\AppData\Roaming\Typora\typora-user-images\image-20200613110328081.png)

- **Voluntary**: conducted with consent

- **Involuntary**: does not give consent (doctors kill w/o agreement)
- **Not Voluntary**: unable to consent (eg. Vegetative)
- **Passive**: withhold life-sustaining treatment
- **Active**: use lethal substance to end their life

## $\texttt{Types of Claims}$

- **fact**: true or false
- **value**: good or bad
- **policy**: should or shouldn't

'In cases of terminal illness, physician-assisted suicide should be legal' [**Policy debate**]

## $\texttt{PRO arguments}$

- Status quo bad
- Solvency

## $\texttt{CON arguments}$

- Status quo good, no need to change, It doesn't solve problems, doesn't have advantages
- Make problem worse, other problems 
- Alternative solvency   

## $\texttt{stakeholders}$

- "one who is involved in or affected by a course of action"

Who are the stakeholders in the topic

- patients
- families & friends
- medical professionals
- companies (pharmaceutical, insurance)
- governments
- public (taxpayers, citizens)

### $\texttt{Jack Kevorkian}$

- American physician
- "Dying is not a crime"
- aka Dr.Death
- help 130 patients to end their lives
- convicted of second-degree murder

### $\texttt{Marieke Vervoort}$

- Belgian Paralympics champion
- reflex sympathetic dystrophy, an incurable disease of the muscles and spine, severe pain, paralysis in her legs, and difficult to sleep

### $\texttt{Terri Schiavo}$

- Irreversible persistent vegetative state
- husband didn't want artificial life support, parents did want life support
- 7 years of legal challenges
- finally removed feeding tube

### $\texttt{Brittany Maynard}$

- UC Irvine: MA educati9on
- 2014 brain cancer with 6 months to live
- moved to Oregon and get euthanasia

## $\texttt{What would actually happen}$

- will there be mistakes？
- how to determine true consent？
- who decides?
- what does terminal mean, time frame?
- what if there's a misdiagnosis?
- how to present it as an option without 'selling' it?
- could there be unintended consequences?





