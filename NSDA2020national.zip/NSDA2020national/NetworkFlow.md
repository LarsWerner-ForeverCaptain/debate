# PRO

## C1 Slippery Slope

### Sub 1 Consent

biopower

> pure theory, no actual evi to support

> 2 regulations solve
>
> ​	15 days of re-thinking, and need clear consent from the patients
>
> 3 if it is not legalized it is even worse
>
> ​	if PAS it not legalized, underground and secret PAS would happen as we've mentioned in our contention 1. And that's worse for patients' autonomy if secret PAS is made. But if we legalize it, no unclean PAS need to be done, and we can make PAS clear and regulated, thus making it much better than the status quo.

### Sub 2 Captalism

people don't have autonomy (can't pay for other options)

> 1 PAS is the cheapest way to die in peace, thus in our world, we care for those who can't afford the palliative care. In con's world, those poor people have to toture and suffer until their last second of life, which is truly not what they want to see. But in our world, those poor people can die in less pain and with dignity and with autonomy.

profit-driven insurance company, push to death

> 1 Insurance company need to remove the risk of  people choose to die because of financial burden

​	PAS warrant steps by the insurance industry to seek a contract structure designed to remove the risk that a person would choose that option because of financial concerns. And life insurers should provide generous living benefit options to insureds who contract a terminal illness.



[PAS MAYBE cause that, no actual evi]

## C2 PC

reduce support of PC

> 1 PAS actually IMPROVE PC 
>
> because people care more about end of life

LISA SCHENCKER 

​	Studies in 2015 indicate that Oregon's law has led to improvements in palliative and hospice care. Thirty percent of Oregon doctors who responded to a 1999 survey said they had increased the number of patients they referred to hospice after voters approved the law. Three- quarters of responding doctors who had cared for terminally ill patients said they had worked to improve their knowledge of pain medication for those patients, according to a 2001 article in JAMA. 

## 

PC improve quality of life, reduce suffering (PC best option

> 1 PAS unaffordable for poor
>
> ​	The price of the cheapest hospice & palliative care is \$151 per day, and the most expensive on is \$976. That makes palliative & hospice care unaffordable for many people. Then our opponent is depriving the right of the poor to have a peaceful death, which is truly discrimination against the poor.
>
> 2 PAS not satisfying
>
> ​	Kaiser Health News discovered there had been 3,200 complaints against hospice agencies across the country in the past five years. [4] Those who die... may be denied the right care because only 11% of hospital trusts in England provide specialist palliative services around the clock. [5] The terminal illness patients can’t get the right palliative care as there are not enough places, and hospice agencies can’t let them satisfied. 
>
> 3 PC have discrimination and bias
>
> ​	The bias in end of life care system is a huge problem. Of all Medicare beneficiaries in these hospices for end of life care, 92 percent were white patients and 8 percent black patients. Also, black hospice patients were significantly more likely than white patients to disenroll from hospice prior to death.
>
> 

fw: risk & benefit analyse, which side can provide a better world

## Moral right to live and die

in our world, we respect people's right to live and right to die, we have regulations to make sure it's true consent and insurance companies protect insureds. 

while under con's resolution, people's right to live is not respected, as some people have to go to unclean and secret PAS as their is no legal and clean PAS. People's right to die is not respected either, for people don't have the right to choose their peacefu death.

## Law & Regulation

1 they drop our c2. the law is unequal in the status quo, for different terminally illed patients were treated differently. Those who can get passive euthanasia can have peaceful but others have to suffer. 

2 underground problem:

if PAS is clean and legalized, people are going to take the clean PAS whether than underground one. thus legalizing reduce underground PAS.

## PAS vs PC

1 their evi about pc solve pain is only about morphine can reduce pain, not hospice

2 PAS have abuses and problems, isn't better than PAS

## Poor's right and autonomy

 in their world, some poor don't have right to have a peaceful death as some can't go to pc and suf ... and some are abused

 in our world, 

## Comment

1 right to die expalnation, why need to have the choice

2 why legalized PAS lead to clean PAS, recod of countries

3 PAS is still exist in con worlds --> should we make it clean or not

4 procedure of PAS to prove that ...

5 con: in sws., PAS offered to baby who have disability, give parents choices



# PRO vs WINCC WG

political, economic

PAS not suicide

> def: Oregon Law, from a place which PAS legalized.

## C1 depression1

77% depression

4% psychological 

PAS -> depression death

> Logic 1 regulations about terminal illness
>
> ​	The topic only need to prove that in terminal physical illness conditions, PAS could be legal. Whether depressed or not does not change people's physical conditions. So stil, those physically suffering ti patients will choose to PAS.
>
> Logic 2 people who are severely depressed can still make medical decisions wisely
>
> ​	According to Arizona Lar Review, Researchers found that people who are severely depressed generally retained the capacity to make treatment decisions. Most hospitalized patients with serious mental illness have abilities similar to persons without mental illness for making treatment decisions.
>
> Logic 3 if not legalized worse
>
> ​	If PAS is legalized, we at least have the psychological examination be regulated. And we can regulate those PAS that only ti patients can take PAS.
>
> ​	But in co's world, those who are depressed would go to underground PAS only becasue they want to die, ...

## C2 other deaths

### Sub1 burden

60% burden

desperation

option of PAS open

> Logic 1 non-unique
>
> Pressure appears in everything in healthcare system, and not legalizing PAS can't make it better, so it don't affect autonomy.
>
> Logic 2 
>
> ​	A study by Battin and colleagues published in ***Journal of Medical Ethics* that analyses existing databases from Oregon and the Netherlands**... **They found no increased incidence of PAS in vulnerable groups. including those who have financial burden
>

### Sub2 suicide contagion

suicide a way out

> 1 no direct link of their evidence
>
> ​	They mentioned evidence that the sicide rate goes up, but not all of them is directly linked to the PAS
>
> 2 Suicide rate don't goes up
>
> ​		In Belgium, the suicide rate from 2005 to 2015 has an 8.5% decrease (23 to 21). That means the PAS don't pose much impact to suicide.

### Sub3 abuse

no safeguards

> Logic 1 Leglizing reduce abuses compare to their world
>
> ​	According to E Dahl and N Levy, J Medical Ethics, Permitting PAS may actually decrease the number of cases in which doctors withhold or withdraw life sustaining medical treatment without the patient's explicit request.
>
> ​	As we've proved in our contention that in con's world ... still happen, ...
>
> Logic 2 Abuse in PC of their side worse
>
> ​	black ... disenroll 
>
> ​	black children 44%

## 1 Laws and Regulations

in con's world, laws are unequal for many suffering pats, while in our world 

## 2 Underground PAS

whether make PAS clean or not

in con's ..., secret, unregulated, no consent, involuntary, no autonomy

our, regulated, 

## 3 Suicide contagion , misdiagnosis , burden

depression: no a single evi said that no physically suffering with depression will love to still suffer after cured

in con's world, underground suicide makes much impact and pain, while in our world, it's only abou ti and regulated.  oregon: other factors, evi fal

## 4 Abuse

in con's world, blacks are abused in pc, painful pats and non ti pats are abused in underground in pc, people who can't do passive euthanasia are abused in unequal law

in our world, suffering pats are getting autonomy and peaceful death, and abused pats in con's world can have autonomy.



## PRO vs WFLA CL

fw: live most valuable

6 months

## C1 failure

### 1 misdiagnosis

9.2% choose PAS

> 1 no exact evidence to prove how many people who can live more than 6 months but are misdiagnosed and euthanized.
>
> 2 if the doctors or hospital make a mistake and a healthy person take PAS, they will sued for hundred thousand dollars or even millions of dollars according to sutliffstout, so even from a money perspective they will make sure they don't make a mistake. So, for not to lose such much money, when PAS is legalized, doctors would try even better not to misdiagnose.
>
> 3 regulation: 15 days, more diagnosis

### 2 PAS failure

>1 better than suffering through weeks or even months
>
>2 PC worse
>
>in con's world, in the palliative care, 80% of falicies have deficiency, whichi is worse
>
>3 Underground PAS in con's world worse
>
>PAS exist in both worlds as our opponent have agreed.
>
>So it's a question of whether to make PAS clean and regulated. In con's world, PAS are acted out w/o clear consent and in a unclean way, much more painful. While in our world, PAS is professional, regulated and clean, and minimize the pain.

## C2 Pressure

### Sub1 financial pressure

> 1 we need to respect poors' and disabled's autonomy to have peaceful death
>
> The poor can't afford treatment —— According to The Guardian, 2020, Millions of Americans – as many as 25% of the population can't get enough medical help because of skyrocketing costs. And palliative care, which can cost at least \$ 150 per day is also unaffordable for the poor. If we don't legalize PAS, then those poor people will die in severe pain. But if we legalize it, the bias in way to end their lives can be solved, and poor can have such peaceful death with dignity.
>
> 2 	A study by Battin and colleagues published in ***Journal of Medical Ethics* that analyses existing databases from Oregon and the Netherlands**... **They found no increased incidence of PAS in vulnerable groups.** 

### Sub2 family pressure

> 1 According to Ganzini, Linda, Only 3 percent reported that the family members of patients who received prescriptions were more financially burdened. 

## C3 Discrimination for poor

> 1 opp's world more discrimination in pc (ppor)
>
> 2 poor's autonomy
>
> ​	The price of the cheapest hospice & palliative care is \$151 per day, and the most expensive on is \$976. That makes palliative & hospice care unaffordable for many people. Then our opponent is depriving the right of the poor to have a peaceful death, which is truly discrimination.



## clash 1 Pain

in con's world, ti have to suffer from months of torture, and those defiency facilities, and pain from unclean PAS, and 20.4% of physicians give overdose w/o regulations

in our world, we provide a much painless way for people to die in peace

## clash 2 Laws & Regulations

inequality: in the status quo, people who can't have passive euthanasia have to suffer while others don't which is truly unequal for those who can't have passive euthanasia

regulations: 15 days time of decision, make sure it's autonomy and voluntary, and reduce risk of misdiagnosis

## clash 3 Misdiagnosis & Presure

1 no specific evi to prove that prove how many people who can live more than 6 months but are misdiagnosed and euthanized.

2

## clash 4 Poor&VG's rights

in con's world, poor's right to live is not respected, for underground PAS in con's world is involuntary and in severe pain.  And poors' right to die is not respected either, as they can only suffer until death.

in our world, we've mentioned that there are no inc in vulnerable group pas, while we also give choices of peaceful death with digity



# CON vs BJNUHS GY

## FW

ti: suffer, 6 months

PAS

fw: choice

## Contention 1 die with individual right

### SubA: control

good death: control death

> 1 doctors influence choice, which means it's not their own control
>
> ​	According to Dutch News, Boost of suicide death which is the doctors are using their authority both intentionally and unintentionally encourage the patient who are hesitating to choose PAS instead of palliative care. Convincing patients to suicide are nothing different to abet in a murder which is obviously harmful to the society. That is not autonomy and not own choices, when physicians urge pats to die.
>
> 2 PAS happen w/o consent and become involuntary, which is not control of own death
>
> ​	According to NCBI, One in every 5 people is euthanized without having given explicit consent. Attempts at bringing those cases to trial have failed, proving that regulations can't help. A recent study found that in the Flemish part of Belgium, 32% of hastening death are lack request or consent.

### SubB: dignity

80% lose of dignity as a reason

> 1 PAS can have failure, which is even worse and less dignified death
>
> ​	It turns out that many things can go wrong during an assisted suicide. Patients vomit up the pills they take. They don’t take enough pills. They wake up instead of dying. Patients in the Dutch study **vomited up their medications in 7 percent of cases**; **in 15 percent of cases, patients either did not die or took a very long time to die — hours, even days**.
>
> 2 autonomy isn't w/o boundaries. when it harm other people, we should also consider about other people's lives
>
> ​	We've said that the legislation of PAS lead to many innocent lives harmed. The UN has found that the pas law in the Netherlands is in violation of its *Universal Declaration of Human Rights* because of the risk it poses to the rights of safety and integrity for every person’s life. The UN has also expressed concern that the system may fail to detect and to prevent situations. 

## Contention 2 no better alternative

### SubA: palliative care bad

no many palliative care

> 1 PAS make palliative care worse in legalized states 
>
> ​	According to Hospice Volunteer Association, Legalised euthanasia has led to a severe decline in the quality of palliative care for terminally-ill patients in Holland, it has been claimed. Even the architect of the controversial law has admitted she may have made a mistake. Without elaborating, she admitted that palliative care care for the terminally-ill had declined since the law came into effect.
>
> 2 palliative don't harm others like pas

### SubB: pain

> 1 after legalizing, pain went up because worse end of life care
>
> ​	The prevalence of family-reported moderate or severe pain or distress before death in Oregon decedents increased from 30.8% to 48% after legalising PAS.
>
> ​	Decedents in 2000–2002 (after PAS legalized) remained approximately twice as likely to be reported to be in moderate or severe pain or distress during the last week of their live.
>

25% 

minority, pain untreated

> 1 minority harmed in pas
>
> 

### SubC: cheaper, safer, quicker

choose specific day

> 1 children pushed
>
> 2 



suicide contagion

evi: they themselves don't have evi from all over the world, while we give more countries, oregon, belgium, netherland etc.

## Clash1 freedom to choose

our opponent claimed that people have the freedom to choose their own death with dignity, but the truth is far from that.

first, pas can have failure, with patients suffering for hours or even days w/o dignity.

second, physicians are using authority to urging patients to die for reasons.

third, PAS are carried out involuntary and the evidence of 30% of people involuntary death shows that the impact are huge.

thus, their are no dignity, and no 

## Clash2 vulnerable groups

our opponent claimed that vg only harmed in pc, but..



## Clash3 extra death caused by PAS

our opponent claimed that it doesn't better that people die of misdiagnosis, and physicians won't ..

suicide: 6.3% inc, 41% total inc

doctors push: 15% promp physicians to urge pas

family push: chil

misd:

1 op claim non-ti die

2 



# HS Final

# PRO

pas: doctor improve

6 months, should we have choice to die

fw: morallt, ulta

## Contention 1 pat

45% in urgent need

### SubA dignity

right to die

agaist wishses

> doctors lobby pas before choice
>
> 61 cases
>
> undermines other treament
>
> we don't deny right to die
>
> they take away choices -> not right to die

### Sub B suffering

w/o life support suffer

12 hours struggle to breathe, refuse to admit

limited 

> only 5% have extreme pain
>
> twice as likely to pain aft pas legalized

## Contention 2 social

### Sub A Family

2 times lower 

### Sub B Economy

CBS News, 600m dollars

60k dollars hospital

20k dollars family

> saving money -> being pushed to death

### Sub C Depression

pas treat depression?

### Sub D Organ Donation

20 reports

5% organ in canada

100 needs

20 days each day

> canada, 2/3 unable to donate
>
> life not valuable

## Contention 3 Overuse

### Sub A painkiller Overdose

painkiller overdose now

2018, 41 / day, opiods

those people still die, painful expensive

### Sub B Underground

60% at least ... even not legal

> -> regulations failing
>
> new regulations fail



# CON

pas: commit suicide

## Contention 1 reverse incentive

subject pats to a risk

deny treatment --> assisted suide

> logic is poor who can't afford pc
>
> 1 pas self complimentary
>
> pas save 600m for us 
> ti gonna die sonner less suffering cheaper
>
> 2 pas bad
>
> WHO, 2020, only 14% receive pc
>
> 40.8% low quality of life, last 2 weeks
>
> 63% last 1 week
>
> 0 aut
>
> cost too much

### 1 inc profic --> reduce care (urge doctors to reduce treatment)

2017, bryan, transfer pats to other hospital

other hospital deny treatment, suggest pas

chepaer than treatment

1994, OAMP, terminate funding.

put lethal ... on list of treatment

OAMP slash on medical funding on service, people with disab.

### 2 saving resources

shortage 50k us doctors

kill pats

## Contention2 slippery slope

> 1 no slippery slope
>
> people in hospice well educated, take medication
>
> pas in orgon, only 0.3% of all death pas
>
> 2 reduce underground pas
>
> pas unlawful, involuntary euthansai 5 times higher than netherland
>
> hasten death, even not legal
>
> at contagion:
>
> 1 no correlation
>
> top 10 suicide country no pas
>
> 

children, euthanized

depression

suicide normalized (contagion)

13 reasons why, 29% inc suicide

24 people in belgium --> 4000 cases in belgium

pas a lot



# CF

1 pro: euth vs pas

2 con: pats want to live a longer time, right to live

> washington post, 54% ti pats urgent need of pas

3 pro: suicide contagion correlation problem

> tell eveyone that suicide ok --> inc suicide

4 con: 45%, are they actively

> washington post

5 con: evi about depression?

6 pro: live w/o autonomy true good life?

> give aut hurt society
>
> > citizens don't have aut

1 pro: how many people deny treatment

2 con: why ss don't work

> go to euthanasia
>
> killing is solvency
>
> > for those who can't afford
> >
> > > worse, for they kill them

3 pro: live or freedom

> life > death
>
> freedom > life

4 con: why unimportant

> slavery
>
> > undermines other treatment
> >
> > the quality of treatment







# PRO vs Starriver ZW

fw: everywhere:

if con said they want to legalize everywhere, con should give out somewhere why they shouldn't but they didn't so their fw can's stand

also, the topic is analyzing the world w/o legalizing and also getting experiences from whether those places' which pas is legalized decision is right by analyzing risk and benefits, not to leglize it everywhere in the world.

## Contention 1 Vulnerable Group

>	1 
>
>	​	A study by Battin and colleagues published in ***Journal of Medical Ethics* that analyses existing databases from Oregon and the Netherlands**... **They found no increased incidence of PAS in vulnerable groups.** 
>
>	2 palliative care in con's world is more discriminative for african american
>
>	​	Black hospice patients were significantly more likely than white patients to disenroll from hospice prior to death.  According to NY Times, 2019, While 74 percent of white patients with bone fractures received pain medications, 57 percent of black did. African-American children with an appendicitis were only 44 percent as likely to receive medications for pain as white children.
>
>	3 con's worlds palliative care is more discriminative for poor
>
>	​	WHO, 14% who need can actually use. discriminate poor ...

### 

African American

elderly, income, education

murdering

## Contention 2 consent problem & abuse

psychological

involuntary euthanasia

72% problem: 

> 1 evi fal
>
> that is from euthanasia from netherland, which is not pas which is talked in the topic, while they still say that as pas which is not euthanasia, so their evi can't stand
>
> 2 legalizing reduce abuse & involuntary
>
> ​	Permitting PAS may actually decrease the number of cases in which doctors withhold or withdraw life sustaining medical treatment without the patient's explicit request. 	Accoridng to J Medical Eth, .That it is possible that legalising PAS reduces the number of abuses, for several reasons: because patients are able to remain  rational longer when they do not fear losing control over the timing and manner of their death; because the stricter oversight reduces the potential for abuses, and because doctors respond to requests for PAS by improving end of life care.
>
> ​	And the reduce of underground pas also reduce abuse, as we make the underground pas clean and regulated
>
> 3 only little w/o clear physician consnet and action
>
> ​	From 1998 until 2008, more than 2 million cases have been reported to the review committees. Only in 38 cases they have concluded that the doctor had not satisfied the legal criteria of careful action.

overdose pas 61% w/o consent

## Contention 3 bad regulation, corruption

corrupt government, can't regulate pas

oregon, penalty of pas

doctor lack of regulations

> 1 non-unique
>
> 2 
>
> 3 regulations work
>
> ​		There are now also a number of reports around the world concluding that safe reform is possible. This was the view of the [Quebec Select Committee on Dying with Dignity](http://www.assnat.qc.ca/en/actualites-salle-presse/nouvelle/actualite-25939.html) in 2012 and the position taken in Tasmania by the premier, Lara Giddings, and leader of the Greens, Nick McKim, in their 2013 [consultation paper](http://www.premier.tas.gov.au/__data/assets/pdf_file/0007/185578/Voluntary_Assisted_Dying_-_A_Proposal_for_Tasmania.pdf).





Our opponent has admitted the benefit that PAS have in cf by saying those in legalized country can get the benfit but others can't, so if we can successfully rebut their fw, only by this point we can win this debate.

fw: 

1 every country has its own law, legalizing in one place don't mean this law discriminate other countries' people

2 the topic only argued that legalzing PAS make more benefit than risk, not to analyse every single places in the world

also, palliative care is the things that ti patients choose when pas isn't legalized, so if pas is better than the status quo, it should be legalized

## Clash 1 Regulations & Laws

in both worlds, pas can still exist, so it's a matter of ..

in con worlds, pas , ... , unequal law

in our worlds, regulated, less abuse ...

## Clash 2 Vulnerable group

no inc in pats

status quo harm more (pc)

## Clash 3 Morol

autonomy

regulation work --> autonomy



# PRO vs SH YK Pao XW

all areas

ti: death; short term & long term

> fw: we only need to prove that legalizing pas have more benefits than risk, like analyzing  the already legalized countries and the future of world

## Contention 1 regulation fail

### Sa: organization effect

ask for pas 

80% reported death

> 1 worse if not legalization
>
> ​	

insurance company

>​	PAS warrant steps by the insurance industry to seek a contract structure designed to remove the risk that a person would choose that option because of financial concerns. And life insurers should provide generous living benefit options to insureds who contract a terminal illness.

> ​	Insurance Company don't pay for the most expensive option, but pay for the reasonably priced palliative care. And patients still have to pay to companies when they're still alive, so that means in order to get more money, insurance companies won't urge patients to die. 

pressured

### Sb: corruption

columbia

hc sys

inc treatment and drug cost

forced to provide pas

> 1 columbia, only 1 country
>
> and they said columbia legalize pas, but no evi on how many people die or harmed be.. pure speculation and imagination, nbo specifi evi
>
> 2 we need to solve the medical corruption problem, not to escape from it. our opponent is not only too relying on the status quo, but also escape from things happening in the medical field.
>
> corruption is not permanent, and columbia is solving corruption now, we need to respec their result of solving corrutpio

## Contention 2 individual harm

### Sa: misdiagnosis

>1 no exact evidence to prove how many people who can live more than 6 months but are misdiagnosed and euthanized.

> 2 patients will go to many doctors to make sure it's true

> https://www.sutliffstout.com/wrongful-death-guide/average-settlement-amount/

> 3 if the doctors or hospital make a mistake and a healthy person take PAS, they will sued for hundred thousand dollars or even millions of dollars according to sutliffstout, so even from a money perspective they will make sure they don't make a mistake. So, for not to lose such much money, when PAS is legalized, doctors would try even better not to misdiagnose.

> 4 the misdiagnosis that con is talking about is usually not a healthy person misdiagnosed into terminal illness. the misdiagnosis they  mean is usually some moderate terminal illness who are judged into serious terminal illness, or even some patients' life expectancy be overestimated.

### Sb: inequality

minority, poor

> 1 in con's world, the end of life care worse
>
> The bias in end of life care system is a huge problem. Of all Medicare beneficiaries in these hospices for end of life care, 92 percent were white patients and 8 percent black patients. Also, black hospice patients were significantly more likely than white patients to disenroll from hospice prior to death.
>
> ​	There are also bias in treatment and care. According to NY Times, 2019, While 74 percent of white patients with bone fractures received pain medications, 57 percent of black did. African-American children with an appendicitis were only 44 percent as likely to receive medications for pain as white children.

### S2: family pressure

> 1 family members are all with loves, and they are not evil to each others on considering. and finally it's their own decisions to whether take the pill or not, whether to consider about family or not
>
>  2
>
> ​	Only 3 percent reported that the family members of patients who received prescriptions were more financially burdened. 
>
> # 

## Contention 3 social harm

### Sa: slippery slope

1 involuntary, worse in underground

> 1 rebuttal (trafficking)
>
> pas good, but underground bad
>
> 2 underground
>
> 20.4% w/o consnet

### Sb: suicide contagion

1 evi no correlation

​	a lot of

2 

> https://www.macrotrends.net/countries/BEL/belgium/suicide-rate

​	In Belgium, the suicide rate from 2005 to 2015 has an 8.5% decrease (23 to 21).

> https://en.wikipedia.org/wiki/List_of_countries_by_suicide_rate

​	In Netherland, where PAS has been legalized for a long time, the suicide rate is only ranked 81 on the list of countries by suicide rate. And no PAS legalized states is in the top 20 countries where the suicide rate is the highest.



# CON vs YKPAO LT

# 不能单调队列别人，就只能等着被单调队列

impact:


97.5% of false terminal rate of lung cancer, 80% of wrong prognosis lead to wrongful death of thosuands and millions of people, families break and members are suffering from mental illness

41% of suicide rate higher than national dat, 14.5% of suide rate increase for elderly 

61% of people involuntary death, can't get any autonomy of decision

15% of physicians are pushed by hospital's pressure and prompt patients to pas





# REBUTTAL

fw: comparing future

## COntention 1 freedom

sub a : conversation

> 1 conversation can be practiced in many circumstances, and can be improved not only through pas, ...
>
> 2 family psychology harm because of pas
>
> ​	A larger quantitative study from Oregon, published in 2009, examined family members of patients... After a mean of 14 months post-death, 11% of family members in the medical assistance in dying group were depressed, 2% had prolonged grief, and 38% were receiving mental health care. One study from Switzerland published in 2012, 13% met the criteria for full PTSD, the prevalence of depression was 16%.
>
> the conversation not inc family benefit, but the effect of pas reduce it
>
> 3 pats pushed to pas because of family burden
>
> national right to life news
>
> ... Boer explained, Around one in five patients who choose euthanasia in the Netherlands acts under pressure from family members, therefore children who die by PAS are also likely to be pressured by family members. 	

choose of death, moral life

conversation between, alleviating mental

change mind

sub b: autonomy



## Contention 2 reduce abuse

provide safeguard, truly vonluntary

3.2% no consent -> 1.7%

> 1 regulation: if not following...
>
> 2 hospital abuse
>
> ​	According to NEJM, of the 3882 deaths due to physician-assisted suicide or euthanasia in Flanders, Belgium, in the year 2013 alone, 1047 (27%) involved physicians deciding to administer medication dosages to hasten death without patients’ consent.
>
> > https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/
>
> ​	One in every 5 people is euthanized without having given explicit consent. Attempts at bringing those cases to trial have failed, providing evidence that the judicial system has become more tolerant over time of such transgressions.
>
> ​	A recent study found that in the Flemish part of Belgium,32% of euthanasia occurred in the absence of request or consent.

## Contention 3 medical improvement

help doctor further improve end of life care

improve knowledge

69% inc recognition

future pats, understand more

> 1 end of life care worse
>
> > https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3070710/
>
> ​	At the UK parliamentary hearings, one Dutch physician asserted that “We don’t need palliative medicine, we practice PAS.”
>
> ​	In Switzerland in 2006, the hospital in Geneva reduced its already limited palliative care staff after a hospital decision to allow PAS.
>
> ​	Attracting doctors to train in and provide palliative care was made more difficult because of access to PAS.
>
> oregan pall care study
>
> The prevalence of family-reported moderate or severe pain or distress before death in Oregon decedents increased from 30.8% to 48% after legalising PAS.
>
> ​	Decedents in 2000–2002 (after PAS legalized) remained approximately twice as likely to be reported to be in moderate or severe pain or distress during the last week of their live.

# FF

## Clash 1 Underground Problem & Legalization

1 if people are not going to follow the basic pas law in the status quo: no pas, then how are they gonna follow all the complicated pas laws

2 in our world, pas at least choose whether to go to the underground or not, and doctors are not gonna to murder pats

while in opp's world, underground pas could still exist while pats also begin to kill pats w/o consent and push pats to death. And opp's never said regulations will work

## Clash 2 Individual harm

1 in opp's world, ti pat's autonoomy is never respected, they are pushed by 

poor also pushed by insurance cmpany because insurance company don't want them to use companies' money to have pc

right to live abandoned, consent

in our world, none exist, and w/o having option of pas, insurance ... 

## Clash 3 Society harm

suicide rate 41%, 14.%







impact:

97% of false terminal rate of lung cancer, 80% of wrong prognosis lead to wrongful death of thosuands and millions of people, families break and members are suffering from mental illness

41% of suicide rate higher than national dat, 14.5% of suide rate increase for elderly 

61% of people involuntary death, can't get any autonomy of decision

15% of physicians are pushed by hospital's pressure and prompt patients to pas

