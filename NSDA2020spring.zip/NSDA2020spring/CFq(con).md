## AT： Education

Is data privacy of students' important?

Why we have to use students' real name to use this system? (We can still use this by not having "personal data" because w/o letting login with real name the data are not "identifiable")

## AT: Epidemic

How many people are saved using epidemic prevention that our opponent said?

## AT: Healthcare

Is letting hackers control healthcare equipment safe for patients?

Is health data fraud safe for weak elder people?

## AT: Personalization

Is political manipulation caused by "personalized ads" a democratic and good thing ?

Is the right decision for companies to Personalize Consumer's Services when 78% of users don't want?

## AT: IoT

Is a home a good one when hacker can supervise and control your home?

## AT: poor

According to Michele Gilman, University of Baltimore, the poor are classified and denied in many algorithm such as "how much potential an employee will perform, whether student cam graduate, how much credit a person has etc.". Is denying and discriminating the poor a good way to help the poor?

## AT: AI

> https://www.mckinsey.com/featured-insights/future-of-work/ai-automation-and-the-future-of-work-ten-things-to-solve-for
>
> https://www.forbes.com/sites/gilpress/2019/07/15/is-ai-going-to-be-a-jobs-killer-new-reports-about-the-future-of-work/#251187dbafb2

According to McKinsey&Company, workers displaced after aplying data to AI: 400million, 15%globally. And this will also cause 47% of American's jobs at risk. As we all know, AI can still work without personal data, why will we sacrisfy such many people's jobs at risk and add data to AI?

## AT: Crime

> Datanami, October 12, 2016 https://www.datanami.com/2016/10/12/criminals-are-using-big-data-tech-and-so-should-you/

“The sophistication, agility, and speed at which a cybercriminal operates have improved through the use of data analytics,” Kate McGavin wrote. That means criminals have better skills to do crime. Is it actually safer for us when criminals have better skills to commit crimes?

## AT: wield (?) kinds of benefits (about lives)

traffic: turn off location tracking, 

payment: 

subscription: 