# <font color = red>PRO Evidence</font>

## <font color=orange>Location data=personal data</font>

> https://phys.org/news/2018-12-personal.html

​    In addition, location data can provide information about an individual, including a visit to some particular hospital, a political assembly or religious places.



## <font color = orange>Healthcare</font>

### Polularity

#### Popularity (SAKOVCH)

> SAKOVICH, NATALLIA. 4-9-2019, "The Importance of Data Collection in Healthcare and Its Benefits," SaM Solutions, https://www.sam-solutions.com/blog/the-importance-of-data-collection-in-healthcare/

 	According to the survey by Statista dated 2018, <font color = green>44% of US adult respondents have accessed their EHR</font> and only 6% of respondents opted out of having an EHR.

### Data base (datapine)

> https://www.datapine.com/blog/big-data-examples-in-healthcare/, https://medium.com/the-research-nest/real-world-applications-of-big-data-in-healthcare-5c84696fd3d4

​		Optum Labs, an US research collaborative, has collected EHRs of over 30 million patients to create a database for predictive analytics tools that will improve the delivery of care. 

### Economy Benefit

#### \$ 300 b ~ \$ 450 b

> https://www.mckinsey.com/industries/healthcare-systems-and-services/our-insights/the-big-data-revolution-in-us-health-care, https://healthcareweekly.com/big-data-in-healthcare/

​	[Research conducted by McKinsey & Company](https://www.mckinsey.com/industries/healthcare-systems-and-services/our-insights/the-big-data-revolution-in-us-health-care) showed that big data could save Americans between $300 billion to \$450 billion per year on health-care spending.

#### \$ 350 b ~ \$ 500 b

>  https://www.columnit.com/how-big-data-could-save-billions-for-healthcare.html

​	According to CIO, recent studies suggest the healthcare industry could save between \$348 and ​\$493 billion by applying big-data analysis to existing data sets.

### Usage examples

> https://www.datapine.com/blog/big-data-examples-in-healthcare/

​    A [Forbes article](https://www.forbes.com/sites/bernardmarr/2016/12/13/big-data-in-healthcare-paris-hospitals-predict-admission-rates-using-machine-learning/#79f2f6ff79a2) details how four hospitals which are part of the Assistance Publique-Hôpitaux de Paris have been using data from a variety of sources to come up with daily and hourly predictions of how many patients are expected to be at each hospital.

### Security

#### Blockchain

> [https://www.forbes.com/sites/forbestechcouncil/2019/06/18/blockchain-in-healthcare-how-it-could-make-digital-healthcare-safer-and-more-innovative/#26ac027d3e5a](#26ac027d3e5a)

​	<font color = green> Blockchain technology is being leveraged to remodel the collaborative exchange of vital research and useful healthcare data, thereby enabling key stakeholders such as clinical researchers, doctors, pharmacists, and other healthcare providers to gain secure, faster, simplified and reliable access to electronic medical information.</font> The industry already has a similar platform called the [health information exchange](https://www.healthit.gov/topic/health-it-and-health-information-exchange-basics/what-hie) (HIE). Many healthcare technology vendors -- including my company, a medical data and image management cloud-based service -- can integrate with HIE systems.

#### Medical Data Protection

> Ben Yates, Rico Chan, http://hk-lawyer.org/content/blockchain-and-future-data-protectio

​	Developers are building new infrastructure to <font color = green>allow medical records to be stored on a “permissioned” blockchain where only members of a closed group will have access rights. With this technology, medical records will be encrypted.</font>

​	There is no "back door" through which a third party could access users’ information; nobody other than the holder of the decryption key is able to unlock the encrypted data.

### Effect

> https://www.datapine.com/blog/big-data-examples-in-healthcare/

​    U.S. has made a major leap with 94% of hospitals adopting EHRs according to this HITECH research.

### Prevent people have drugs

> https://www.datapine.com/blog/big-data-examples-in-healthcare/

​    Using years of insurance and pharmacy data, Fuzzy Logix analysts have been able to identify 742 risk factors that predict with a high degree of accuracy whether someone is at risk for abusing opioids.

### Opt-out (not invasion of privacy)

> https://cnsnews.com/news/article/hhs-everyone-can-opt-out-government-mandated-electronic-health-records-system   

​    The U.S. Department of Health and Human Services (HHS) says that everyone **can opt out** of having an **electronic health record** included in the federally mandated national **electronic-health-record** system created by the stimulus law enacted in February.

## <font color = orange>Epidemic</font>

### Corona virus

Countries who track: South Korea, Iran, Israel, Austria, Belgium, Germany, Italy, China

##### Vox, Recode, Why having personal data fight virus ok

> Recode, https://www.vox.com/recode/2020/3/18/21184160/government-location-data-coronavirus

​	The United States government [wants tech companies to tell it where you’ve been](https://www.washingtonpost.com/technology/2020/03/17/white-house-location-data-coronavirus/) as part of its effort to fight [the Covid-19 coronavirus pandemic](https://www.vox.com/2020/1/31/21113178/what-is-coronavirus-symptoms-travel-china-map), according to the Washington Post.

​	“We are in the middle of a public health crisis,” Schwartz told Recode. “And some rebalancing of collective and individual interests may be appropriate.“

##### South Korean Eg 

> https://www.lawfareblog.com/lessons-america-how-south-korean-authorities-used-law-fight-coronavirus

​	This explains how the South Korean government has been able to rapidly “contact-trace” hundreds of thousands of its own citizens to curb the outbreak.

​	Fifty-four days since its first case, South Korea has officially turned the tide, [reporting](https://www.reuters.com/article/us-health-coronavirus-southkorea/south-korea-reports-more-recoveries-than-coronavirus-cases-for-the-first-time-idUSKBN210051) more recoveries per day than new infections.

### Prevent  outcome

> https://www.wsj.com/articles/scientists-crunch-data-to-predict-how-many-people-will-get-coronavirus-11584479851

​	As Brian Hopkins, a vice president and principal analyst at Forrester Research Inc. said, “Besides advancements in medicine, <font color = green>advancements in information technology and digital data are how we defeat this pandemic and prevent another Spanish flu-like outcome.”</font>

### Epidemic (Forbes)

> Bernard Marr [https://www.forbes.com/sites/bernardmarr/2020/03/13/coronavirus-how-artificial-intelligence-data-science-and-technology-is-used-to-fight-the-pandemic/#324561e05f5f](#324561e05f5f)

#### Forecast

<font color = green>By analyzing news reports, social media platforms, and government documents, AI can learn to detect an outbreak.</font> Tracking infectious disease risks by using AI is exactly the service Canadian startup[ BlueDot](https://bluedot.global/) provides. In fact, <font color = green>the BlueDot’s AI warned of the threat several days before the Centers for Disease Control and Prevention or the World Health Organization issued their public warnings.</font>

#### Diagnosing

Imaging departments in healthcare facilities are being taxed with the increased workload created by the virus. This solution <font color = green>improves CT diagnosis speed. Chinese e-commerce giantAlibaba also built an AI-powered diagnosis system they claim is 96% accurate at diagnosing the corona virus in seconds.</font>

#### Identification of infectious group

<font color = green>The Chinese government has also developed a monitoring system called Health Code that uses big data to identify and assesses the risk of each individual</font> based on their travel history, how much time they have spent in virus hotspots, and potential exposure to people carrying the virus. Citizens are assigned a color code (red, yellow, or green), <font color = green>which they can access via the popular apps WeChat or Alipay to indicate if they should be quarantined or allowed in public.

> min https://www.wired.co.uk/article/uk-coronavirus-spread-app-phone-data

​	<font color = green>In China, ‘health code’ add-ons</font> for Alibaba’s Alipay payment platform and Tencent’s WeChat <font color = green>have been used to restrict the movement of potentially infected people.</font>

---

### What will happen without data

> https://www.britannica.com/event/Black-Death

​    25 million people in [Europe](https://www.britannica.com/place/Europe) died from plague during the Black Death.

## No privacy invasion

> www.forbes.com/sites/zakdoffman/2020/04/12/forget-apple-and-google-heres-the-real-challenge-for-covid-19-contact-tracing/#6de389392709

It enforces a decentralized approach, where no personal data leaves your device.





## <font color = orange>Agriculture</font>

### Economy

> https://theconversation.com/a-game-plan-for-technology-companies-to-actually-help-save-the-world-105007

​	One estimate suggests that making changes in farming and food practices that enhance productivity, promote sustainable methods and reduce waste <font color = green>could produce commercial opportunities and new savings worth US$2.3 trillion overall worldwide annually.</font>

​	 The start-up CropX offers sensors to help farmers adjust irrigation to the needs of their soil. IBM has developed an agriculture-specific cloud technology.

#### Great potential

> https://www.forbes.com/sites/timsparapani/2017/03/23/how-big-data-and-tech-will-improve-agriculture-from-farm-to-table/#4e58b7c05989

Several well-known investors recently dropped a combined $40 million into Farmers Business Network, a data analytics startup. Venture capital has flooded the ag tech space, with [investment increasing 80% annually since 2012](https://www.bcgperspectives.com/content/articles/process-industries-strategy-lessons-frontlines-agtech-revolution/), as investors realize big data can revolutionize the food chain from farm to table.

### Better seeds

> https://www.cio.com/article/3235141/4-ways-big-data-analytics-is-disrupting-the-agriculture-industry.html

​    We can grow plants faster, taller, and heartier than ever before - and as of last March, [apparently on Mars](https://qz.com/931111/scientists-figured-out-how-to-grow-potatoes-on-mars-thanks-to-the-the-international-potato-center-and-engineers-in-peru/) as well. Chemically engineered seeds designed using big data may sound like a bad thing on the surface and the news usually portrays it that way. However, seeds created using data analytics could put an end to world hunger.

### Plant survey

> https://www.cio.com/article/3235141/4-ways-big-data-analytics-is-disrupting-the-agriculture-industry.html

​    Farmers are using drones with advanced sensors to survey their crops, update their data, and notify them of areas that need improvement. As the technology continues to progress you can expect drones to move from surveying to planting and harvesting themselves.

### Climate change

> https://www.theguardian.com/sustainable-business/food-blog/sustainable-agriculture-10-things-climate-change

​    **Agricultural GHG emissions, make up about 25% of global GHG emissions**, but there's a lot that can be done to reduce this.

​    **Richard Waite**, associate, Food, Forests and Water Program, [World Resources Institute](http://www.wri.org/) explains: "By intensifying agriculture on existing land and protecting the remaining forests, we can **eliminate emissions from land-use change**. And by **addressing key emissions from agricultural production** – from cows and other ruminants, from fertilizers, and from rice production practices, **using sustainable agriculture, that is**, we can greatly reduce emissions from agricultural production."

### Adoption rate

> https://www.supplychaindigital.com/technology/comment-how-can-ai-help-food-supply-chain

According to a report by Accenture, 85% of organisations have planned to adopt digital or AI technologies in their supply chains during 2017. 

### Market size

> https://www.bloomberg.com/press-releases/2020-01-08/artificial-intelligence-in-agriculture-market-size-worth-2-9-billion-by-2025-cagr-25-4-grand-view-research-inc

The global artificial intelligence in agriculture market size is expected to reach USD 2.9 billion by 2025, according to a new report by Grand View Research, Inc. The market is anticipated to register a CAGR of 25.4% from 2019 to 2025.

### Improve plant growth

To address this issue, Kantor and his colleagues recently launched FarmView, a project that combines AI with robotics to improve the agricultural yield of certain staple crops, in particular sorghum, a valuable cereal crop in developing countries like India, Nigeria, and Ethiopia due to its drought- and heat-tolerance.

FarmView is not a single example. Similar efforts in combining AI analysis and targeted aiding totaled up to 17 goals and 169 corresponding targets to be reached in 12 years from now.

> https://medium.com/@ODSC/the-future-of-artificial-intelligence-and-agriculture-540c39208df6

The plant, through aeroponics gets exposed to soil water for 99.98% of the time, but for the remaining 0.02% of the time, it is exposed to a solution (water + plant decompose) that is rich in micronutrients and minerals. This adds to the fertility of the plant and at the same time decreases the water and nutrient requirement of the plant by 40% and 30% respectively.

### Maximize the Current Output

Today, an alarming amount of the world’s food — as much as half — ends up in the trash. The AI-powered TOMRA Sorting Solutions machine analyzes and can separate food more specifically than into “good” and “bad. Similar to a human, it can evaluate food such as a tomato to determine the best way to use it. One fruit might not make it to the salad plate, but it would be perfect to use in the production of ketchup.
Precise Application of Herbicide
Instead of the “spray-and-pray” approach to herbicide application, the LettuceBot from Blue River is working to distinguish between a weed and a sprout of lettuce based on learning from more than a million images of 5,000 young plants. When it identifies a weed, it sprays it directly. This has cut losses by up to 90%. 

### Early Warning Signs of a Crisis

The Nutrition Early Warning System (NEWS) uses big data and machine learning to identify areas at increased risk for food shortages due to droughts, rising food prices, and crop failure. It has already been deployed to warn farmers in Colombia that a drought was on the horizon and suggest they skip the planting season. The 170 farmers that heeded the advice and skipped the planting season saved their planting costs when the drought did occur. 

### Plant Disease

> https://www.sapinsideronline.com/articles/how-artificial-intelligence-can-help-fight-world-hunger/

AI deep learning is being used to help machines identify the health of crops. Once the machine’s ability improves, farmers around the world will be able to leverage its learnings through an app that can diagnose an issue so that the farmers can take action before the losses are catastrophic. 
Internet of Things (IoT) for Agriculture
Sensors and systems that collect and analyze crop-related data is one of the reasons American farms are so productive. The growth of IoT devices should generate 4 million data points each day by 2050, according to one provider, OnFarm. All this data about soil conditions to crop health and climate change will be powerful for deep learning AI and its ultimate application to make agriculture smarter and more efficient.
The use of AI in agriculture and ultimately to solve world hunger is just beginning. Humanitarian organizations and challenges such as the Syngenta AI Challenge, a contest that encourages programmers to use machine learning to improve agricculture, will help accelerate the pace of progress so that when 2050 is here, we have developed solutions to avoid a world hunger crisis.

## <font color = orange>AI </font>

### Consumer benefit

#### Satisfaction

> [https://spd.group/artificial-intelligence/big-data-and-its-business-impacts/#The_Benefits_of_Big_Data_combined_with_the_Artificial_Intelligence](#The_Benefits_of_Big_Data_combined_with_the_Artificial_Intelligence)

 	75% of organizations have increased their sales of new products and service offerings and <font color = green>improved customer satisfaction by more than 10% using implemented AI, according to [Capgemini Digital Transformation Institute](https://www.capgemini.com/gb-en/service/the-digital-transformation-institute/).</font>

#### Economy

>https://www.mckinsey.com/business-functions/mckinsey-digital/our-insights/open-data-unlocking-innovation-and-performance-with-liquid-information

​	Another McKinsey study concluded that free Internet services underwritten by Internet advertising delivered significant benefits to Internet users. <font color = green>It estimated the social surplus from these services at 120 billion euros, 80 percent of which went to consumers.</font>

### Fraud Detect

>https://www.afr.com/technology/ai-and-big-data-knocks-36-4b-off-payments-fraud-20190614-p51xuh

 	Payments giant Visa has applied artificial intelligence algorithms to the surging number of global e-commerce transactions it processes each year, and <font color = green>said the tech smarts have helped it reduce fraud-based losses to financial institutions by \$US25 billion (\$36.4 billion) in the last year. –financial review.</font>

> https://theaims.ac.in/resources/5-ways-big-data-can-change-crime-prevention.html

​	<font color = green>The Nationwide Building Society managed to reduce fraud losses by 75% using SAS software, says David Parsons, head of fraud analytics.</font> "We now have huge amounts of data and can look at any number of parameters to help us spot anomalous behaviour," he says. "And the speed with which we can do this is phenomenal."

### Economy (McKinsey)

>https://www.ced.org/blog/entry/big-datas-economic-impact

 	A report from McKinsey Global Institute estimates that <font color = green>Big Data could generate an additional $3 trillion in value every year in seven industries of global economy. </font>

​	<font color = green>The report from McKinsey also estimated that over half of this value would go to customers</font> in forms such as fewer traffic jams, easier price comparisons, and better matching between educational institutions and students according to Joseph Kennedy, President of Kennedy Search.

### Crime Detect

> https://www.kaspersky.com/blog/big-data-forensics/8300/

​	Criminalists are sure that [crime has its own patterns](http://www.policeone.com/police-products/software/Data-Information-Sharing-Software/articles/6396543-How-Big-Data-is-helping-law-enforcement/), just like any other human activity.

​	Similar [security solutions are already used in police departments](http://www.geekwire.com/2014/big-data-meets-crime-fighting-seattle-police-launch-seastat-quickly-pinpoint-crime-hotspots/) of Seattle, New York, and Los Angeles. The last one has already [reported significant performance improvement](http://www.alleywatch.com/2014/08/catch-me-if-you-can-big-data-and-crime-prevention/) that included <font color = green>a 33% drop in burglaries, a 21% decrease in violent crime, and a 12% reduction in property crime.</font>

​	[Experts say](http://theinstitute.ieee.org/technology-topics/big-data/the-future-of-crime-prevention) that analytical systems can successfully cope with predicting street crimes, such as auto thefts and homicides. They are also good in forecasting street riots and acts of terrorism.

​	Palantir’s software can work with a bunch of messy information. <font color = green>This was already used to prevent acts of terrorism in several countries. It was also used in Afghanistan to predict insurgent attacks. Palantir also helped authorities to locate Osama bin Laden.</font>This software [successfully located Mexican drug cartel members](http://www.forbes.com/sites/andygreenberg/2013/08/14/agent-of-intelligence-how-a-deviant-philosopher-built-palantir-a-cia-funded-data-mining-juggernaut/), tracked down hackers who installed spyware on the Dalai Lama’s PC. ,helped to c[atch a child molester](http://www.forbes.com/sites/andygreenberg/2013/08/14/agent-of-intelligence-how-a-deviant-philosopher-built-palantir-a-cia-funded-data-mining-juggernaut/). 

> https://www.independent.co.uk/news/uk/home-news/police-big-data-technology-predict-crime-hotspot-mapping-rusi-report-research-minority-report-a7963706.html

​	<font color = green>According to Independent, RUSI’s report said the system of Harm Assessment Risk Tool was found to predict low-risk individuals with 98 per cent accuracy and high-risk with 88 per cent accuracy.</font>



## <font color = orange>Poverty & Refugee</font>

> https://www.nbcnews.com/mach/tech/ai-game-changer-fight-against-hunger-poverty-here-s-why-ncna774696

​	NBC News reports researchers fed an algorithm satellite images and household data in countries, then <font color = green> instructed it to predict poverty distribution. The algorithm could predict poverty 81 percent to 99 percent more accurately than previous models. </font>

​	By the end of 2018, <font color = green>more than 7.1 million people were biometrically enrolled in 60 Country Operations over the world, meaning that 8 in every 10 refugees registered by UNHCR now has a biometric identity. </font>

### Satellite image 

#### Machanism

> https://www.nbcnews.com/mach/tech/ai-game-changer-fight-against-hunger-poverty-here-s-why-ncna774696

Burke and his colleagues fed an algorithm both nighttime and daytime images from Uganda, Tanzania, Nigeria, Malawi, and Rwanda, all of which have household survey data available — and instructed the algorithm to find features in the daytime imagery that are predictive of places that are lit up at night. The model found numerous features that relate to such things as agricultural regions, bodies of water, and urban areas, but also various elements that were hard to interpret. Some features, Burke says, “were patterns to the eye that don't look like anything we recognize, but they're patterns that the model found useful.”

The researchers then fed the computer the survey data and instructed it to predict the distribution of poverty throughout the countries. In all, the algorithm could predict poverty 81 percent to 99 percent more accurately than a nightlight-only model.

#### Examples

> https://www.ifc.org/wps/wcm/connect/2cae89ee-dea3-4a7e-ba79-77c9011cbd0f/IFC_2019_Poverty+Estimation+with+Satellite+Imagery+at+Neighborhood+Levels.pdf?MOD=AJPERES&CVID=mHZhcxB

In Guana, a score of 60-64 means that nine percent of the population is likely to fall below the \$2.50/day poverty line; and about 52 percent are likely to fall below the higher $5.00/ day poverty line. 



# <font color = red>PRO BLOCKS</font>

## <font color=orange>AT: big data≠Personal data</font>

> https://gdpr.report/news/2017/07/24/gdpr-big-data-friends-foes/

​    Big Data sets make up of personal data, and it is impossible to separate the personal data from the non-personal data.



## <font color = orange>AT: privacy/data selling</font>

### GDPR

> IT Governance https://www.itgovernance.eu/blog/en/gdpr-when-do-you-need-to-seek-consent

​	<font color = green>GDPR requires a positive opt-in and opt-out, it also requires that individuals can withdraw their data at any time to protect their privacy.</font>

> ICO, https://ico.org.uk/for-organisations/guide-to-data-protection/guide-to-the-general-data-protection-regulation-gdpr/lawful-basis-for-processing/consent/

​	<font color = green>Explicit consent requires a very clear and specific statement of consent,</font> Keep your consent requests separate from other terms and conditions, Keep evidence of consent – who, when, how, and what you told people, Name any third party controllers who will rely on the consent.

### TC260

> data guidance, https://platform.dataguidance.com/news/china-tc260-publishes-cybersecurity-standards

​	The National Information Security Standardisation Technical Committee of China ('TC260') announced, on 7 March 2020, the approval and publication of eight cybersecurity standards ('the Cybersecurity Standards'). 

> TC260, https://www.tc260.org.cn/upload/2018-01-24/1516799764389090333.pdf

​	The types of personal data collected should have a direct relationship with realization of the business functions of the products or services. “Direct relationship” means that without such information, the products or services could not realize their function.

​	Minimize the frequency & quantity of data collected



## <font color = orange>AT: unsafe</font>

### Blockchain

#### (ADB) Safety of Blockchain

> **Lotte Schou-Zibell**,Regional Director, Pacific Liaison and Coordination Office (PLCO), **Nigel Phair**,Director, UNSW Canberra Cyber, https://blogs.adb.org/blog/how-secure-blockchain

​	<font color = green>Blockchain can achieve simultaneous security and privacy in an information system</font> by enabling confidentiality through “public key infrastructure” that protects against malicious attempts to alter data, and by maintaining the size of a ledger.

​	To get around data privacy issues, a blockchain operator may store personal data and the reference to this data off-chain with a “hash” of the information – a one-way transformation of data to an unreadable piece of information.

(Hash is to use safe ways to turn all sorts of operations in to numbers)

​	<font color = green>Blockchain technology can be robust, secure, trustworthy, and private.</font>

#### (Medium) Blockchain Secure Data

> block9solutions, May29 2018, https://medium.com/coinmonks/guarantee-your-patients-privacy-today-securing-sensitive-data-with-blockchain-fcb179f1302c

​	<font color = green>If the hacker isn’t using the right files on the right computer, it is impossible for him to get to the point where it is even possible to crack the password.</font>

#### (NGA) Transparency of Transaction against fraud

> Anita Lettink, https://www.ngahr.com/blog/use-of-blockchain-secures-personal-data

​	<font color = green>Blockchain contains an audit trail allowing you to see how a third-party uses your data. Also, you can revoke access. Such control shifts the power of (and profit from) data back to individual users.</font>

​	<font color = green>The blockchain records each transaction and maintains a permanent and unalterable historical record of transactions in the ledger. Therefore, the potential for fraud is virtually eliminated.</font>



## <font color = orange>AT: Monopoly</font>

### Google IS NOT a monopoly

> https://www.forbes.com/sites/timworstall/2017/05/10/google-and-facebook-are-dominant-but-not-monopolies/#2ac775c436d4   

​    Mono has the same meaning as "one" here and if there are other companies out there with 12% of said market then it's simply not a monopoly. Google may very well be market dominant but that again is not the same thing as a monopoly. So the basic definition being used is wrong.

### Benefit of some monopoly

> https://www.economicshelp.org/blog/265/economics/are-monopolies-always-bad/

#### Lower average cost

​	 <font color = green>In an industry with high fixed costs, a single firm can gain lower long-run average costs – through exploiting [economies of scale](https://www.economicshelp.org/microessays/costs/economies-scale/). Small firm has higher average costs, while increasing output which is those big tech leads to lower average costs.</font>

#### Innovation

​	<font color = green>Without patents and monopoly power, companies would be unwilling to invest so much in research. The monopoly power of patent provides an **incentive** for firms to develop new technology and knowledge, that can benefit society.</font>

​	<font color = green>Also, monopolies make supernormal profit and this supernormal profit can be used to fund investment which leads to **improved technology and dynamic efficiency**.</font>

### Prevent some bad monopoly

> https://www.technologyreview.com/s/613640/big-tech-monopoly-breakup-amazon-apple-facebook-google-regulation-policy/

#### Share Anonymous Data

​	<font color = green>Mayer-Schönberger suggests that large companies be required to share anonymized data with less powerful competitors. In Germany, for instance, big insurers already [share some data with smaller ones](https://www.foreignaffairs.com/articles/world/2018-08-13/big-choice-big-tech). That way, startups have a chance too.</font>

#### Stop Locking in their Users

​	Even better is <font color = green>“data interoperability” which enables different services to work together—for instance, allowing Instagram users to post to Snapchat and vice versa.</font> <font color = green>When AOL and Time Warner merged in 2001, the Federal Communications Commission forced AIM Instant Messenger to become compatible with other messaging systems to promote competition.</font>

#### Prevent combining data from different sources

​	In a direct challenge to Facebook’s business model, <font color = green>Germany’s competition authority on Thursday </font> sharply curtailed how the tech giant may profile people, <font color = green>saying that users could refuse to allow the company to combine their Facebook information with data about their activities on other sites.</font>

​	But <font color = green>German regulators ruled that Facebook would now have to stop automatically collecting and combining that data and instead give German users a choice. </font>

### Data monopolies worse than traditional ones

> Stucke, Maurice E., Should We Be Concerned About Data-opolies? (March 19, 2018). 2 Georgetown Law Technology Review 275 (2018); University of Tennessee Legal Studies Research Paper No. 349. Available at SSRN: https://ssrn.com/abstract=3144045 or http://dx.doi.org/10.2139/ssrn.3144045 

​    **First**, the harms from data-opolies can exceed that of earlier monopolies. They can **affect not only our wallets but our privacy, autonomy, democracy, and well-being**. **Second**, **the data-driven markets dominated by these firms will not necessarily self-correct. Third, antitrust enforcement can play a key role. But antitrust enforcement, while a necessary tool to prevent data-opolies and deter their abuses, is not sufficient.** Antitrust enforcers must coordinate with privacy and consumer protection officials to ensure that the conditions for effective privacy competition are in place.

​    My antitrust professor presciently forewarned, in 1979, how it was “bad history, bad policy, and bad law to exclude certain political values in interpreting the antitrust laws.” 215 Professor Pitofsky raised several concerns: first, “how excessive concentration of economic power will breed antidemocratic political pressures”; second, a “desire to enhance individual and business freedom by reducing the range within which private discretion by a few in the economic sphere controls the welfare of all”; and third, “that if the free-market sector of the economy is allowed to develop under antitrust rules that are blind to all but economic concerns, the likely result will be an economy so dominated by a few corporate giants that it will be impossible for the state not to play a more intrusive role in economic affairs.”216

## <font color = orange>AT: discrimination</font>

### Prevention

> https://www.technologyreview.com/s/613640/big-tech-monopoly-breakup-amazon-apple-facebook-google-regulation-policy/

​	<font color = green>[Hal Singer](https://gwipp.gwu.edu/hal-singer-senior-scholar-non-resident) proposes a non-discrimination principle that would prevent this. This is how cable channels are already regulated.</font>

​	<font color = green>Now, **independent networks** can bring complaints to a **neutral arbitrator** that is responsible for making sure everyone is treated fairly.</font>



## <font color = orange>AT: Political Manipulation</font>

### Study & Prevent

### Anti-Cambrige Analytica

> https://www.nbcnews.com/politics/politics-news/cambridge-analytica-s-effectiveness-called-question-despite-alleged-facebook-data-n858256

​    And a Democratic operative who works in the digital realm said claims of Cambridge Analytica's effectiveness in 2016 are very much overstated.

​    Jessica Baldwin-Philippi, an assistant professor at Fordham University who has studied the digital efforts of political campaigns said that there is little evidence to support claims that Cambridge Analytica helped swing the election.

​    "Time and again, studies have shown us that **the most persuasive targeting metrics are not crazy-specific microtargeting data** but public-record voting history data and geography," she said.

> https://www.theatlantic.com/technology/archive/2018/06/did-cambridge-analytica-actually-change-facebook-users-behavior/562154/

​    The majority of Facebook users in my survey—68.6 percent—said that without Facebook their social life would suffer.

### Ban political ads

> https://www.vox.com/recode/2019/11/15/20966908/twitter-political-ad-ban-policies-issue-ads-jack-dorsey

​    CEO Jack Dorsey [announced](https://www.vox.com/recode/2019/10/30/20940612/twitter-political-ads-announcement-jack-dorsey-facebook) on Twitter that his firm would ban political ads.

> https://www.washingtonpost.com/technology/2020/01/09/facebook-wont-limit-political-ad-targeting-or-stop-pols-lying/

​    Facebook lets users opt-out of political ads.

## <font color=orange>AT: Targeted Ads to vulnerable groups (adiction)</font>

### pd from social media help treat addictions

> Kim SJ, Marsch LA, Hancock JT, Das AK. Scaling Up Research on Drug Abuse and Addiction Through Social Media Big Data. J Med Internet Res 2017;19(10):e353. DOI: 10.2196/jmir.6426 https://www.jmir.org/2017/10/e353/

​    Performing big data analytics on social media content allows researchers to **generate data-informed insights into the phenomena of interest**, such as the promotional communication of problematic substance use shared on social media platforms. The use of social media data to monitor and observe problematic use of prescription drugs, such as nonmedical use of analgesic opioid drugs, is as yet an unexplored area of biomedical research. In our reviewed studies reported in a typology, **the communication properties were used to identify high-risk events [90], indicating the potential utility of social media data as a resource in scaling up surveillance systems for substance use problems**. More specifically, social media communication data aggregated by **drug use–related search keywords** can **indicate the level and stage of drug dependence**, **the actions of patients engaging in addiction recovery support groups, former users with or without relapse episodes, or current users with or without dependence**. Given the large scale of social media communications posted by people who have engaged or are engaging in nonmedical use of prescription drugs such as opioids, **harnessing social media platforms and data will provide insight into important novel discoveries of collective public health risk behavior.**
Social media big data on the nationwide public health problem of nonmedical use of prescription drugs in the United States can also have a practical impact at the individual level (eg, seeking social support for addiction recovery support), as well as at the societal level (eg, public health campaign efforts on this topic).

## <font color=orange>AT: Targeted Pricing</font>

### No Conclusive Evi

> https://one.oecd.org/document/DAF/COMP/WD(2018)150/en/pdf

​    There is no conclusive empirical evidence that personalised pricing actually exists in online markets. For example, the report of OFT (2013) argues that personalised pricing is technically possible, but found no evidence that it was used by online firms

### Have consent

> https://one.oecd.org/document/DAF/COMP/WD(2018)150/en/pdf

​	In consumer protection rules, The first and most basic degree is that consumers are informed that the price they are offered is personalised.

## <font color=orange>AT: False Product</font>

### Ways to prevent customers buy it

> https://www.businessinsider.sg/how-to-find-fake-products-online-shopping-amazon-ebay-walmart-2018-3?r=US&IR=T

​    Find out who's selling the product. If it's not coming from the retailer, look up the seller. Spot the fake reviews, look into shipping logistics, examine product photos, watch out for unrealistic ideals, inspect the product for suspect packaging. 

### Amazon spokesman

> https://www.businessinsider.sg/how-to-find-fake-products-online-shopping-amazon-ebay-walmart-2018-3?r=US&IR=T

​    We strictly prohibit the sale of counterfeit products and invest heavily-both funds and company energy-to ensure our policy against the sale of such products is followed. Our global team is available 24 hours a day, 7 days a week to respond to and take action on reported violations and notices of potential infringement.

​    In order to detect bad actors and potentially counterfeit products, we make significant investments in machine learning and automated systems. We employ dedicated teams of software engineers, research scientists, program managers, and investigators to operate and continually refine our anti-counterfeiting program. **Over 99.9% of all Amazon page views by our customers landed on pages that did not receive a notice of potential infringement.**

## <font color=orange>AT: Crime </font>





# <font color = red>CON Evidence</font>

## <font color=orange>Privacy</font>

> https://www.forbes.com/sites/daveywinder/2019/08/20/data-breaches-expose-41-billion-records-in-first-six-months-of-2019/#10f5b7dbd549

​    According to Risk Based Security research newly published in the 2019 MidYear QuickView Data Breach Report, the first six months of 2019 have seen more than 3,800 publicly disclosed breaches exposing an incredible 4.1 billion compromised records. 

   Perhaps even more remarkable is the fact that 3.2 billion of those records were exposed by just eight breaches. As for the exposed data itself, the report has email (contained in 70% of breaches) and passwords (65%) at the top of the pile.

> https://www.forbes.com/sites/maggiemcgrath/2014/01/10/target-data-breach-spilled-info-on-as-many-as-70-million-customers/#555874eae795

​    The information stolen between November 27 and December 15, 2013 included personal information of as many as 70 million people -- more than the 40 million the company originally estimated.



## <font color = orange>Political Manipulation</font>

### (The New Republic) Undermines Democracy

> The New Republic, Sue Halpern is a scholar-in-residence at Middlebury College and the author, most recently, of the novel *Summer Hours at the Robbers Library.*https://newrepublic.com/article/151548/political-campaigns-big-data-manipulate-elections-weaken-democracy

##### 	Cambridge Analytica

​	 In interviews with *The Guardian* and *The New York Times*, Wylie confirmed that his company had taken data from millions of Facebook users without their knowledge or consent—as many as 87 million users, he later revealed.

##### 	Catalist

​	One of these companies, **Catalist**, now controls a data set of 240 million voting-age individuals, each an aggregate, the company says, of hundreds of data points, including “purchasing and investment profiles, donation behavior, occupational information, recreational interests, and engagement with civic and community groups.”

##### 	Undermine Democracy

​	 The manipulation of personal data to advance a political cause undermines a fundamental aspect of American democracy that begins to seem more remote with each passing campaign: the idea of a free and fair election.

​	Cambridge Analytica broke the idea that campaigns work to convince voters that their policies will best serve them. It attempted to use psychological and other personal information to engage in a kind of voluntary disenfranchisement by depressing and suppressing turnout with messaging designed to keep voters who support the opposing candidate away from the polls—as well as using that same information to arouse fear, incite animosity, and divide the electorate.

​	Technology will only carry a candidate so far.

### Easy

>[https://www.google.com/search?biw=1440&bih=820&ei=7tmbXqTbHZLe-gSc9ojIAg&q=tech+manipulation+shift+mind+of+12%25+people&oq=tech+manipulation+shift+mind+of+12%25+people&gs_lcp=CgZwc3ktYWIQAzIECAAQRzIECAAQRzIECAAQRzIECAAQRzIECAAQRzIECAAQRzIECAAQR1DSH1icJGDQJWgAcAJ4AIABowKIAYIIkgEDMi00mAEAoAEBqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwikiv3Q2fPoAhUSr54KHRw7Aik4FBDh1QMIDA&uact=5](https://www.google.com/search?biw=1440&bih=820&ei=7tmbXqTbHZLe-gSc9ojIAg&q=tech+manipulation+shift+mind+of+12%+people&oq=tech+manipulation+shift+mind+of+12%+people&gs_lcp=CgZwc3ktYWIQAzIECAAQRzIECAAQRzIECAAQRzIECAAQRzIECAAQRzIECAAQRzIECAAQR1DSH1icJGDQJWgAcAJ4AIABowKIAYIIkgEDMi00mAEAoAEBqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwikiv3Q2fPoAhUSr54KHRw7Aik4FBDh1QMIDA&uact=5)

​    Big *Tech* manipulations could easily *shift* upwards of *12* million votes

### (NY Times) Dark future

> Warzel ,Charlie and Thompson, Stuart A. 12-21-2019, "Opinion," New York Times, https://www.nytimes.com/interactive/2019/12/21/opinion/location-data-democracy-protests.html

​	The future, however, could get dark quickly. Political candidates rich in location data could combine it with financial information and other personally identifiable details to build deep psychographic profiles designed to manipulate and push voters in unseen directions. Would-be autocrats or despots could leverage this information to misinform or divide voters and keep political enemies from showing up to the polls on election day.

​	Then, once in power, they could leverage their troves of data to intimidate activists and squash protests. Those brave enough to rebel might be tracked and followed to their homes. At the very least, their names could be put into registries.

### Cambridge Analytica link(How many people effected)

>https://www.nature.com/news/facebook-experiment-boosts-us-voter-turnout-1.11401

About 340,000 extra *people voted* in the 2010 US elections because of a single *election*-day Facebook message.

### Example of war

The **Iraq War** was sold to the American public with a collection of claims that ended up being proved false. Iraq was **said to have weapons of mass destruction, but this wasn’t the case**. Advocates for the war insinuated that **Saddam Hussein** was colluding with Al Qaeda and was somehow **involved in the 9/11 attacks**. That, too, **was false**. **Fox viewers** led the way in embracing these false assertions, with **80 percent of them believing at least one of the three**. **Seventy-one percent of CBS viewers also held one of these three false beliefs**.

---

## <font color = orange>Technology Monoply</font>

### (Harvard News Report) Threaten the Economy

> (Harvard News Report), Kira Radinsky,  https://hbr.org/2015/03/data-monopolists-like-google-are-threatening-the-economy

##### Data is the barrier-to-entry to the market

​	Data becomes the barrier-to-entry to the market and thus prevents new competitors from entering. As a result of the established player’s access to vast amounts of proprietary data, overall industry competitiveness suffers. This hurts the economy.

##### Example (Google)

​	Google revolutionized the search market in 1996 when it introduced a search-engine algorithm based on the concept of website importance — the famous PageRank algorithm... [Studies](http://www.mathcs.emory.edu/~eugene/papers/sigir2006ranking.pdf) show that the historical search improves search results up to 31%. In effect, today’s search engines cannot reach high-quality results without this historical user behavior... 

​	This creates a reality in which new players, even those with better algorithms, cannot enter the market and compete with the established players, with their deep records of previous user behavior.

##### (McKinsey) Data Mono hurt both companies

​	While data monopolies hurt both small start-ups and large, established companies, it’s the biggest corporate players who have the biggest data advantage.

​	 [McKinsey](http://www.mckinsey.com/insights/strategy/are_you_ready_for_the_era_of_big_data) calculates that in 15 out of 17 sectors in the U.S. economy, companies with more than 1,000 employees store, on average, over 235 terabytes of data—more data than is contained in the entire US Library of Congress.

### (MAWER) Data Monoply Harms

##### Barrier-to-entry (Google)

> MAWER, Justin Anderson, https://www.mawer.com/the-art-of-boring/blog/the-age-of-data-monopolies/

​	Google’s power as a data monopoly is this: it alone has insight and ownership of that 94% of search data. Even if someone did come up with a better search algorithm, they would struggle to compete for a foothold.

​	Which is to say, it is the programs that have the most data, not the best algorithms, that are the highest-quality.



---

## <font color = orange>Data Breach</font>



The U.S. Department of Justice statistics suggest that 850,000 American adults—mostly women—are targets of cyber-stalking each year, and 40 percent of women have experienced dating violence delivered electronically.

> https://www.cnbc.com/2019/10/13/cyberattacks-cost-small-companies-200k-putting-many-out-of-business.html

More than half of all small businesses suffered a breach within the last year.

> https://www.varonis.com/blog/cybersecurity-statistics/

Only 5% of companies’ folders are properly protected, on average. (Varonis)

> https://www.shrm.org/resourcesandtools/hr-topics/technology/pages/employees-commit-most-data-breaches.aspx

IBM found that 44.5 percent of breaches were done maliciously by employees

>https://time.com/5739688/facebook-hate-speech-languages/

​	It has become easier for Facebook to contain the spread of racial or religious hatred online in the primarily developed countries and communities where global languages like English, Spanish and Mandarin dominate.

### （Varonis）Statistics for data breach

> Varonis, Rob Sobers, Rob Sobers is a software engineer specializing in web security and is the co-author of the book Learn Ruby the Hard Way. https://www.varonis.com/blog/data-breach-statistics/

##### Definition

​	The [U.S. Department of Justice](http://www.justice.gov/opci/breach-procedures.pdf) defines a breach as “the loss of control, compromise, unauthorized disclosure, unauthorized acquisition, access for an unauthorized purpose, or other unauthorized access, to data, whether physical or electronic.”

​	Realized by: Ransomware, Malware, Phishing, Denial of Service

##### Statistics

​	Data breaches exposed 4.1 billion records in the first six months of 2019 ([Forbes](https://www.forbes.com/sites/daveywinder/2019/08/20/data-breaches-expose-41-billion-records-in-first-six-months-of-2019/#3b1c3f98bd54)).

​	Yahoo holds the record for the largest data breach of all time with 3 billion compromised accounts ([Statista](https://www.statista.com/statistics/290525/cyber-crime-biggest-online-data-breaches-worldwide/)).

​	In 2019, Facebook had 540 million use records exposed on the Amazon cloud server ([CBS](https://www.cbsnews.com/news/millions-facebook-user-records-exposed-amazon-cloud-server/))

​	The average time to identify a breach in 2019 was 206 days ([IBM](https://www.ibm.com/downloads/cas/ZBZLY7KL?_ga=2.148238199.1762516747.1577395260-1128561362.1577395260)).

​	(*health*)There was an 80% increase in the number of people affected by health data breaches from 2017 to 2019 ([Statista](https://www.statista.com/statistics/798564/number-of-us-residents-affected-by-data-breaches/))

​	(*IoT*)The overall volume of IoT attacks remained high in 2018 and routers and connected cameras were the most infected devices and accounted for 75% and 15% of the attacks respectively ([Symantec](https://www.symantec.com/security-center/threat-report)).

​	It is estimated that a business will fall victim to a ransomware attack every 11 seconds by 2021 ([Herjavec Group](https://www.herjavecgroup.com/wp-content/uploads/2018/12/CV-HG-2019-Official-Annual-Cybercrime-Report.pdf)).

### (CSO) Example of Data Breach

> Taylow Armerding, Contributing Writer of CSO, https://www.csoonline.com/article/2130877/the-biggest-data-breaches-of-the-21st-century.html

 1 Yahoo (3 billion)

2 Marriott (500 million)

3 Adult Friend Finder (410million)

4 eBay (145 million)

5 Heartland Payment (134 million)

6 Target (110 million)  ...

### Lost trust

> https://www.insidesources.com/consumers-are-losing-trust-in-hacked-companies/

​    According to the non-profit tech think tank Internet Society’s [2016 Global Internet Report](https://www.internetsociety.org/globalinternetreport/2016/), 59 percent of internet users said they were unlikely to engage in a business transaction with a company that had suffered a data breach.

### On avaerage

> https://www.ibm.com/security/data-breach

The average cost of a data breach is 3.92 million, and the average size of a data breach is 25,575 records.

### Financial Trillion

> https://www.herjavecgroup.com/wp-content/uploads/2018/12/CV-HG-2019-Official-Annual-Cybercrime-Report.pdf

​	Cybersecurity Ventures predicts the personal data breach will cost the world 6 trillions dollars annually by 2021.

### Easy

> https://www.cnet.com/news/malware-that-can-steal-your-passwords-spikes-60-security-firm-warns/

​    Malicious software that wants to steal your passwords is on the rise, according to new research from Kaspersky. Fewer than 600,000 consumers were [targeted by password-stealing malware](https://usa.kaspersky.com/about/press-releases/2019_kaspersky-finds-rise-in-users-hit-by-password-stealers) in the first half of 2018, according to a release Tuesday from the [security](https://www.zdnet.com/topic/security/) firm. During the same period in 2019, that number rose to over 940,000 -- a 60% increase. 

60 Percent Of Small Companies Close Within 6 Months Of Being Hacked.

---

## <font color = orange>(Maria) Higher Price</font>

> Gonzalez-Miranda, Maria. 5-29-201 https://www.marketwatch.com/story/how-big-data-and-online-markets-can-lead-to-higher-prices-2018-05-19

​	Online retailers use consumers’ internet activities and other personal data to deliver “targeted pricing.” 
​	Indeed, if you search online for a more expensive car or a more expensive vacation, that fact will be documented by tracking cookies or other means of online surveillance. And with these data, digital advertisers and retailers will offer you more expensive watches, home furnishings, or airline tickets than they would to a lower-income user searching within the same categories.



---

## <font color = orange>Anti-Rebuttal about privacy</font>

### (LA Times) Laws don't work

> Sarah, Suhauna Hussain. 1-14-2020,  Los Angeles Times, https://www.latimes.com/world-nation/story/2020-01-14/dating-apps-leak-personal-data-norwegian-group-says

​	The California law requires companies that sell personal data to third parties to provide a prominent opt-out button.

​	The law does not clearly lay out what counts as selling data, “and that has produced anarchy among businesses in California, with each one possibly interpreting it differently,” said Eric Goldman, a Santa Clara University School of Law professor who co-directs the school’s High Tech Law Institute.

### (Vox) Legal Loopholes

> Morrison, Sara. 12-17-2019, "Facebook is gearing up for a battle with California’s new data privacy law," Vox, https://www.vox.com/recode/2019/12/17/21024366/facebook-ccpa-pixel-web-tracker

##### California Law

​	Companies will be required to tell California residents what data about them is being collected, if it’s being sold, and to whom. It will give California residents the ability to opt out of having their data sold, and in some cases let them access and delete data a company has about them.

##### Facebook's Claim (don't sell)

​	Facebook will claim that it doesn’t sell the data that its web trackers collect; it simply provides a service to businesses and websites that install Pixel on their sites. Because of this, it believes its web trackers are exempt from CCPA’s regulations, which have exceptions for data exchanged with a “service provider” that is “necessary to perform a business purpose.”



### (PCMAG) No realization of data collection

##### SDK

​	App developers may be including tracking SDKs without fully understanding the privacy implications for users and perhaps without ever receiving the data themselves. Developers sometimes get paid for including the SDKs and may include them as tools for debugging or gathering analytics.

##### Google Assistant & Alexa

​	As for devices with built-in digital assistants, such as the Google Home and Amazon Echo, it is true that these services send recordings of your queries back to the respective companies for processing. With the Google Assistant and Alexa voice assistants, you can even listen to recordings of every question you've ever asked.

##### Filters&Regulations don't work

​	"[Companies] are willing to set up privacy filters with regard to other users, because that doesn't affect their bottom line; but they're still getting that data themselves." 

​	"Often, I think, when regulation comes into play, it's ill-worded and misapplied. And because of that, you don't have the necessary protection, and [it] can often do more damage than it does good." -- Budington



----

## <font color = orange>IoT & AI danger</font>

### (Tech Radar) Risk of IoT connection

> Aaron McIntosh, Marketing Work Group Chair at Trusted Computing Group (TCG). https://www.techradar.com/news/the-dangers-of-iot-and-ai

​	IoT track people's behaviour and record them. The recorded data is communicated to a [server](https://www.techradar.com/news/best-small-business-servers), but if this communication link is not secure then it becomes an easy route for hackers to get into your home. Similarly, if the data stored within the server or database is not encrypted, it is at risk of a breach. Access to your data and all of your other connected devices gives a hacker a way into your home that can cause serious security issues.



-----

## <font color = orange>Surveillance bad</font>

### (WBUR) Death of privacy and discrimination

> Keen, Andrew. 2015, "Is the Internet Hurting More Than Helping?" WBUR - Boston's NPR Station, http://www.wbur.org/hereandnow/2015/03/16/internet-economics-keen

​	Rather than creating more democracy, it is empowering the rule of the mob. Rather than encouraging tolerance, it has unleashed such a distasteful war on women that many no longer feel welcome on the network. Rather than fostering a renaissance, it has created a selfie-centered culture of voyeurism and narcissism. Rather than establishing more diversity, it is massively enriching a tiny group of young white men in black limousines.

### (Harvard Law) Gov Surveillance bad

> Harvard Law review, [Neil M. Richards](https://harvardlawreview.org/authors/neil-m-richards/), https://harvardlawreview.org/2013/05/the-dangers-of-surveillance/

##### Laws can't help

​	Although we have laws that protect us against government surveillance, secret government programs cannot be challenged until they are discovered. And even when they are, our law of surveillance provides only minimal protections.

**Harm**

1. chill the exercise of civil liberities

   ​	Surveillance is harmful because it can chill the exercise of our civil liberties. ... Consider surveillance of people ... in order to make up their minds about political and social issues. Such intellectual surveillance is especially dangerous because it can cause people not to experiment with new, controversial, or deviant ideas.

2. Surveillance menaces intellectual privacy and increases the risk of blackmail, coercion, and discrimination

### (CJFE) Mass Surveillance bad

> CJFE, Nathan Munn, https://www.cjfe.org/how_mass_surveillance_harms_societies_and_individuals_and_what_you_can_do_about_it

​	Evidence shows that mass surveillance erodes intellectual freedom and damages the social fabric of affected societies; it also opens the door to flawed and illegal profiling of individuals. Mass surveillance has also been shown to not prevent terrorist attacks.

​	Evidence shows that even the possibility of being under surveillance changes the way people think and act...prevent discussions that are necessary for the functioning of a free society. ... Makes the development of mutual mistrust between the individual and the state.

---



## Synthetic Data

> Tandfonline, https://www.tandfonline.com/doi/full/10.1080/2058802X.2019.1668192

​	Fully synthetic data contains no original data.

​	Generation method: Reproduce artificial data / random data using models.

> https://www.techworld.com/data/what-is-synthetic-data-how-can-it-help-protect-privacy-3703127/

​	Hazy CEO Harry Keen: With synthetic data it's not a record transformation into another record

> https://blog.aimultiple.com/synthetic-data/#benefits

​	Synthetic data [can replicate all important statistical properties of real data](https://news.mit.edu/2017/artificial-data-give-same-results-as-real-data-0303) without exposing real data, thereby eliminating the issue. 



# <font color = red>CON BLOCKS</font>

## <font color = orange>AT: All (synthetic data)</font>

### Privacy

> https://www.samasource.com/blog/2018/01/24/the-advantages-and-limitations-of-synthetic-data

​	<font color = green>Synthetic data can be created by stripping any personal information</font> from a real dataset <font color = green>so it is completely anonymized. Synthetic data is anonymous as all personal information has been removed and the data cannot be traced back.</font>

> https://blog.aimultiple.com/synthetic-data/#benefits

​	<font color = green>Synthetic data does not contain any original data. It can work by observing real statistic distributions and reproducing fake data which can do the same work.</font>

### AT: fraud detect

> https://link.springer.com/chapter/10.1007/3-540-36159-6_23

​	In many cases <font color = green>synthetic data is more suitable than authentic data for the testing and training of fraud detection systems. </font>

​	We <font color = green>identify the important characteristics of authentic data and the frauds we want to detect and generate synthetic data with these properties.</font>

> https://blog.aimultiple.com/synthetic-data/#benefits

​	<font color = green>Fraud protection is a major part of any financial service and with synthetic data</font>, new fraud detection methods can be tested and evaluated for their effectiveness.

### AT: healthcare

​	<font color = green>Synthetic data enables healthcare data professionals to allow the public use of record data while still maintaining patient confidentiality.</font>

### AT: AI

​	<font color = green>Machine learning algorithms are trained </font> with an incredible amount of data; <font color = green>which without synthetic data could be extremely difficult to obtain or generate.</font>

​	<font color = green>(Synthetic Data)</font>It can <font color = green>also play an important role in the creation of algorithms for image recognition and similar tasks that are becoming the baseline for AI. </font>

## <font color = orange>AT: Privacy</font>

> https://www.forbes.com/sites/daveywinder/2019/08/20/data-breaches-expose-41-billion-records-in-first-six-months-of-2019/#10f5b7dbd549

​    According to Risk Based Security research newly published in the 2019 MidYear QuickView Data Breach Report, the first six months of 2019 have seen more than 3,800 publicly disclosed breaches exposing an incredible 4.1 billion compromised records. 

   Perhaps even more remarkable is the fact that 3.2 billion of those records were exposed by just eight breaches. As for the exposed data itself, the report has email (contained in 70% of breaches) and passwords (65%) at the top of the pile.

> https://www.forbes.com/sites/maggiemcgrath/2014/01/10/target-data-breach-spilled-info-on-as-many-as-70-million-customers/#555874eae795

​    The information stolen between November 27 and December 15, 2013 included personal information of as many as 70 million people -- more than the 40 million the company originally estimated.

## <font color=orange>AT: Save money</font>

> https://www.iab.com/news/2018-state-of-data-report/

​    This year, American companies are expected to spend nearly $19.2 billion on the acquisition of data.



## <font color = orange>AT: Education</font>

### Data misuse

>  Forbes, Jordan Shapiro, https://www.forbes.com/sites/jordanshapiro/2014/02/25/whats-so-bad-about-big-data-in-little-classrooms/#2f18ebfe4f04	

​    Common Sense Media explains, “through online platforms, mobile applications, and cloud computing, schools and edtech providers collect massive amounts of sensitive information about students.” 

### Data breach

> Herjavec Group, Steve Morgan, Editor-in-Chief Cybersecurity Ventures,https://www.herjavecgroup.com/wp-content/uploads/2018/12/CV-HG-2019-Official-Annual-Cybercrime-Report.pdf	

​    There will be a data breach caused by ransomware attack every 11 seconds in 2021.



## <font color = orange>AT: Healthcare</font>

### Too expensive

>https://www.theguardian.com/us-news/2020/jan/07/americans-healthcare-medical-costs

Millions of Americans – as many as 25% of the population – are delaying getting medical help because of skyrocketing costs

A study conducted by the American Cancer Society in May 2019 found 56% of adults in America report having at least one medical financial hardship.

In 2018, $3.65tn was spent on healthcare in the United States, and these costs are projected to grow at an annual rate of 5.5% over the next decade.


### No Consent

> https://www.theguardian.com/technology/2019/nov/12/google-medical-data-project-nightingale-secret-transfer-us-health-information

​    In 2017, the transfer of 1.6m patient records at the Royal Free hospital in London to the company’s artificial intelligence arm DeepMind Health was found to have an “inappropriate legal basis” by the [UK’s watchdog on data](https://www.theguardian.com/technology/2017/may/16/google-deepmind-16m-patient-record-deal-inappropriate-data-guardian-royal-free).

> https://www.theguardian.com/technology/2019/nov/12/google-medical-data-project-nightingale-secret-transfer-us-health-information

​    Project Nightingale passed the personal data of 50 million or more patients in 21 states to Google, with 10 million or so files already having moved across – with no warning having been given to patients or doctors.

### Health data breach

> Statista, Matej Mikulic, https://www.statista.com/statistics/798564/number-of-us-residents-affected-by-data-breaches/#statisticContainer	

​    113.2 million people were affected by health data breaches in 2015, and there was an 80% increase in the number of people affected by health data breaches from 2017 to 2019.

> https://www.fiercehealthcare.com/tech/number-patient-records-breached-2019-almost-tripled-from-2018-as-healthcare-faces-new-threats

​    Over 41 million patient records were breached in 2019, with a single hacking incident affecting close to 21 million records.

​    Healthcare data breaches in 2019 almost tripled those the healthcare industry experienced in 2018 when 15 million patient records were affected by breach incidents, according to a [report](https://www.protenus.com/resources/category/industry-reports/) from Protenus and DataBreaches.net.

### Racial Bias

> https://www.nature.com/articles/d41586-019-03228-6

​    Only* 17.7% of *patients* that the *algorithm* assigned to receive extra care *were black*

### Data destruction

> https://healthitsecurity.com/news/45-health-cisos-faced-cyberattacks-focused-on-destroying-data

   The healthcare sector’s leading chief information security officers have seen an increase in the sophistication of cyberattacks, with 45 percent of surveyed leaders experiencing an attack with a primary focus of data destruction in the past year 

### **Health data misstep**

> Varonis, Rob Sobers, https://www.varonis.com/blog/data-breach-statistics/	

​    To keep those data anonymous, scrubbing timestamps is important. While, this past June, **Google and the University of Chicago Medical Centre were sued for allegedly failing to scrub timestamps from anonymized medical records**. The lawsuit claims those **timestamps could provide breadcrumbs that could reveal the identities of individual patients, a potential HIPAA violation**. 

### Impact small

>FDA, https://www.fda.gov/consumers/health-fraud-scams

​	According to [FDA](https://www.fda.gov/consumers/health-fraud-scams), health fraud scams waste money and can lead to **delays in getting proper diagnosis and treatment**. They can also **cause serious or even fatal injuries**. 

> Competition Bureau Ca., https://www.competitionbureau.gc.ca/eic/site/cb-bc.nsf/eng/04219.html

   According to [Competition Bureau of Canada](https://www.competitionbureau.gc.ca/eic/site/cb-bc.nsf/eng/04219.html), some times you just lose money, **many of scam medicine can actually put your health at significant risk**. 

### **Hacker**

> Barber, Gregory. 11.11.2019"Google Is Slurping Up Health Data—and It Looks Totally Legal," Wired, https://www.wired.com/story/google-is-slurping-up-health-dataand-it-looks-totally-legal/

​	Despite the intelligent healthcare technology that these devices provide, they are **at risk of malware as a result of the low-level cybersecurity that is installed on them**. This means that the data stored is **vulnerable to being read by a third party** and being pulled from the devices, for example, **a hacker could access a pacemaker and deactivate it or deliberately cause it to malfunction.** [10]

### **Expensive**

> No Lables 4.4.2019 "Five Facts: Why U.S. Health Care is So Expensive" RealClearPolicy https://www.realclearpolicy.com/articles/2019/04/04/five_facts_why_us_health_care_is_so_expensive__111148.html

​	In 2017, Americans spent close to $3.5 trillion on health care alone.

### Increase gap between rich and poor

> https://www.npr.org/sections/health-shots/2019/06/28/736938334/the-gap-between-rich-and-poor-americans-health-is-widening 

   And race, gender and income play a bigger role in predicting health outcomes now than they did in 1993. Overall, white men in the highest income bracket were the healthiest group.



## <font color = orange>AT: Lower Price</font>

### Target pricing

> Gonzalez-Miranda, Maria. 5-29-201 https://www.marketwatch.com/story/how-big-data-and-online-markets-can-lead-to-higher-prices-2018-05-19

​    Online retailers use consumers’ internet activities and other personal data to deliver “targeted pricing.” 
​	Indeed, **if you search online for a more expensive car or a more expensive vacation, that fact will be documented by tracking cookies or other means of online surveillance. And with these data, digital advertisers and retailers will offer you more expensive watches, home furnishings, or airline tickets than they would to a lower-income user searching within the same categories.** 

> CGTN, 2018-03-24 "Does big data increase prices in China?" https://news.cgtn.com/news/7a4d444e306b7a6333566d54/share_p.html

​    Recently in China, many customers found that websites and apps which help customers book flight tickets, hotels, theaters, taxis, etc. set personalized prices based on the device and their purchasing habits. For example, prices shown on iPhones are higher than on Android and prices will increase for customers who have searched for a product or service many times without any actual purchases. 



## <font color = orange>AT: Personalization</font>

### Political Manipulation

> The New Republic,https://newrepublic.com/article/151548/political-campaigns-big-data-manipulate-elections-weaken-democracy

​    Technology such as Cambridge Analytica, **"personalize" your news and manipulate you politically**. **Cambridge Analytica get your data and analyse whether you are a potential voter for the party they support. They will personalize the news based on your data such as your marriage, neighbourhood etc. and  make you vote for that party. If it finds out you are against that party, they will try to manipulate by keep you out of the vote**. According to The New Republic, It attempted to use psychological and other personal information to **engage in a kind of voluntary disenfranchisement**. 

### People don't want it

> [Greg Sterling](https://martechtoday.com/author/greg-sterling) on August 14, 2019 "Personalization offer doesn’t lead to more personal data sharing [Survey]" martech https://martechtoday.com/personalization-offer-doesnt-lead-to-more-personal-data-sharing-survey-234859 

​    Compared with 2018, people demonstrated somewhat **more resistance to sharing personal data**. According to ARF, “The biggest changes in respondents’ willingness to share their data from 2018 to 2019 were seen **in their home address (-10 percentage points), spouse’s first and last name (-8 percentage points), personal email address (-7 percentage points), and first and last names (-6 percentage points)**.”

### Invasion of Privacy & Do little 

> https://www.forbes.com/sites/roberthof/2012/03/09/people-dont-want-personalized-ads-what-should-marketers-do/#2d3587722079

​	According to the survey of about 2,000 American adults early this year, <font color = green>65% of people who were asked how they'd feel if a search engine used the information to personalized future results said it's a bad thing because it limits information they get. Some 73% said it's bad because it's an invasion of privacy.</font>

> https://blog.convert.com/personalization-too-much.html

​	<font color = green> Roughly 65 percent of Americans are concerned about the internet eroding personal privacy. A whopping 78 percent of U.S. citizens think that a brand should not use their personal data to market to them.</font>



## <font color = orange>AT: Data Security</font>

### **Data Breach and Misuse **

> Varonis, Rob Sobers,  https://www.varonis.com/blog/data-breach-statistics/

​	The United States saw 1,244 data breaches in 2018 and had 446.5 million exposed records (Statista).

​	Yahoo holds the record for the largest data breach of all time with 3 billion compromised accounts (Statista).

​	The average time to identify a breach in 2019 was 206 days (IBM).

​	

## <font color = orange>AT: IoT</font>

### **IoT Data Breach & hacking**

> Tech Radar, Aaron McIntosh, https://www.techradar.com/news/the-dangers-of-iot-and-ai

​	IoT **track people's behaviour and record them**. The **recorded data** is **communicated to a [server](https://www.techradar.com/news/best-small-business-servers)**, but **if** this communication link is **not secure** then it **becomes an easy route for hackers to get into your home**. Similarly, **if** the data **stored within the server or database is not encrypted**, it is **at risk of a breach**. Access to your data and all of your other connected devices gives a hacker a way into your home that can **cause serious security issues**. 

> Varonis, Rob Sobers,  https://www.varonis.com/blog/data-breach-statistics/	

The overall volume of IoT attacks remained high in 2018 and routers and connected cameras were the most infected devices and accounted for 75% and 15% of the attacks respectively ([Symantec](https://www.symantec.com/security-center/threat-report)). 



## <font color = orange>AT: Crime Prevention</font>

### **Breach**

(See ET)

### **Corruption and Tyranny**

​	Corruption -> Change the algorithm -> Tyranny

### **Discrimination**

### **Criminal and hackers use big data to escape**

> Datanami, October 12, 2016 https://www.datanami.com/2016/10/12/criminals-are-using-big-data-tech-and-so-should-you/

​    “The sophistication, agility, and speed at which a cybercriminal operates and monetizes their fraudulent information have improved through the use of data analytics,” Kate McGavin, a senior product marketing manager at RSA, wrote.



## <font color = orange>AT: AI</font>

### **Data AI against privacy **

> Mar 27, 2019 "Rethinking Privacy For The AI Era" Forbes https://www.forbes.com/sites/insights-intelai/2019/03/27/rethinking-privacy-for-the-ai-era/#66ea25957f0a

​	Concerns over consumer privacy have peaked in recent years—in step with the **rise of artificial intelligence**. About **9 in 10 American internet users say they are concerned about the privacy and security of their personal information** online, and **67% are now advocating for strict national privacy laws**, according to a [study by](https://www.intouchsol.com/wp-content/uploads/Blog/PDFs/IntouchPOV_GDPRAIandMachineLearningintheAgeofDataPrivacy.pdf) by Intouch International.

### **Surveillance bad**

> Harvard Law review, [Neil M. Richards](https://harvardlawreview.org/authors/neil-m-richards/), https://harvardlawreview.org/2013/05/the-dangers-of-surveillance/

​	Surveillance menaces intellectual privacy and increases the risk of blackmail, coercion, and discrimination. 

> CJFE, Nathan Munn, https://www.cjfe.org/how_mass_surveillance_harms_societies_and_individuals_and_what_you_can_do_about_it

​	Mass surveillance **erodes intellectual freedom** and **damages the social fabric of affected societies**; it also opens the door to **flawed and illegal profiling of individuals**.  

​	Even the possibility of being under surveillance **changes the way people think and act**...**prevent discussions that are necessary for the functioning of a free society**. ... Makes the development of **mutual mistrust** between the individual and the state. 



## <font color = orange>AT: Poors</font>

### Surveillance

> https://www.theatlantic.com/technology/archive/2016/04/how-big-data-harms-poor-communities/477423/

​	Low-income communities are among the most surveilled communities in America. And it’s not just the police that are watching, says Michele Gilman, a law professor at the University of Baltimore and a former civil-rights attorney at the Department of Justice. **Public-benefits programs, child-welfare systems, and monitoring programs for domestic-abuse offenders all gather large amounts of data on their users, who are disproportionately poor.**

​	Data gathered from those sources can end up feeding back into police systems, leading to **a cycle of surveillance**. “It becomes **part of these big-data invformation flows that most people aren’t aware they’re captured in**, but that can have really **concrete impacts on opportunities**,” Gilman says.

### Discrimination

>MICHELE GILMAN, UNIVERSITY OF BALTIMORE / APRIL 30, 2019 ”Data Insecurity Leads to Economic Injustice – and Hits the Pocketbooks of the Poor Most“ Govtech.com https://www.govtech.com/security/Data-Insecurity-Leads-to-Economic-Injustice--and-Hits-the-Pocketbooks-of-the-Poor-Most.html 

​    Employers are using applicant tracking systems to predict whether potential employees will perform on the job. Colleges are assessing algorithms to determine which prospective students are likely to stick around for graduation. Landlords are scouring credit reports to predict whether prospective tenants will pay the rent. **The poor are classified, in all those algorithms, as unqualified.**

​    A lack of transparency means that **people never learn why they are denied a job, a home or an education**. **Mechanisms to correct faulty data either do not exist or are so Kafkaesque that people give up in frustration**.

>UN, poor discrimination https://www.un.org/en/letsfightracism/poor.shtml

​	<font color = green>Many people who live in poverty are often also victims of discrimination</font> on grounds such as birth, property, national and social origin, race, colour and religion. <font color = green>Poverty is both a cause and a product of human rights violations.</font> 



## <font color = orange>AT: Agriculture</font>

### Farmers reluctant

>###### Farmers and their data: An examination of farmers’ reluctance to share their data through the lens of the laws impacting smart farming https://www.sciencedirect.com/science/article/pii/S1573521418302616

​    Key areas of **concerns for farmers** that discourage the sharing of data including **clarity and transparency** of data terms and conditions; questions of **ownership and the sharing of data**; **privacy** concerns; **inequality of bargaining** power; and a **lack of benefit sharing**. 

### Crop repetition--bad for sustainable agriculture

> A very small number of crops are dominating globally: That's bad news for sustainable agriculture University of Toronto, Feburary 6, 2019 https://www.sciencedaily.com/releases/2019/02/190206161446.htm

​    Study suggests that globally we're **growing more of the same kinds of crops**, and this presents **major challenges for agricultural sustainability** on a global scale. **Large industrial-sized farms in Asia, Europe, North and South America are beginning to look the same**. **Soybeans, wheat, rice and corn are prime examples**. These four crops alone occupy **just shy of 50 per cent of the world's entire agricultural lands**, while the **remaining 152 crops cover the rest**.



## <font color=orange>AT: Corona Virus</font>

### Manual contact tracing better

> Bay, Jason. "Automated contact tracing is not a coronavirus panacea." Medium, 14 Apr. 2020, blog.gds-gov.tech/automated-contact-tracing-is-not-a-coronavirus-panacea-57fb3ce61d98.

​    I think with all the excitement about using technology for contact tracing, as the product lead for TraceTogether, I feel compelled to call out the following section of the policy brief and white paper that we published to accompany the open-sourcing of the BlueTrace protocol and OpenTrace codebase.
**If you ask me whether any Bluetooth contact tracing system deployed or under development, anywhere in the world, is ready to replace manual contact tracing, I will say without qualification that the answer is, No.** Not now and, even with the benefit of AI/[Machine Learning] and — God forbid — blockchain (throw whatever buzzword you want), not for the foreseeable future.

### Need at least 60% population use to be useful

> Doffman, Zak. "Forget Apple And Google—Here’s The Real Challenge For COVID-19 Contact-Tracing." Forbes, 12 Apr. 2020, www.forbes.com/sites/zakdoffman/2020/04/12/forget-apple-and-google-heres-the-real-challenge-for-covid-19-contact-tracing/#4ea517ec2709.

​    That said, [Michael Veale, lecturer in digital rights and regulation at the University College London] also warns that **take-up below 60% “would endanger the quality of the data and its core functionality, so that's where the focus needs to be,”** adding that **“if testing is not widely available, I think an app provides more false security than actual support fighting the virus...** Making it solve societal problems in practice, however, needs much more than just a technical protocol.”

​    Unless and until governments can either develop or mandate a system that deploys this across the majority of its population, and then backs it up with the rigorous testing regime that is stitched into the core concept of operation, such apps will be **helpful but not game-changing**.

## FINANCIAL IMPACT

data breach 6 trillion

## SAVE LIFES

> https://borgenproject.org/how-much-does-it-cost-to-end-poverty/
>
> https://www.washingtonexaminer.com/refugee-costs-88-billion-80-000-per-immigrant-free-welfare-medicaid

we need more than 170 billion dollars to eliminate poverty and save people under poverty line, and using the 6 trillion dollars we've saved, 170 billion is only a small amount. And saving refugees needs 8 billion. We give out real financial plan to save those people.