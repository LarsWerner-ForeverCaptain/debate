# April Sun

# Technology companies use of personal data is more beneficial than harmful.

# (CON)

## CONTENTION ONE: Technology monopoly

Facebook, Google, Amazon, and similar companies are “data-opolies”, which means they control a key platform. <font color = \#0000FF>According to Harvard Business Review, today, around 90% of internet searches are via Google, and [94% of young people](https://marketingland.com/pew-the-average-teenager-has-425-4-facebook-friends-44847) who use social media have a Facebook profile. Just 1% of smartphones use an operating system that isn’t iOS or Android – made by Apple and Google. </font>Also, <font color = \#0000FF>studies show that the historical search improves search results up to 31%. So, today’s search engines cannot reach high-quality results without the database of historical user behavior. This creates a reality in which new players, even those with better algorithms, cannot enter the market and compete with the established players, with their deep records of previous user behavior. [3]</font> These statistics prove that a significant volume of personal data flows through the companies’ leading platforms. The velocity in acquiring and exploiting this personal data can help these companies obtain significant market power.

This kind of monopoly can stop better start-ups to survive in the market. In fact, <font color = \#0000FF>nine out of ten start-ups fail according to Forbes.</font> [4] This leads to weak competition, quote and quote: <font color = \#0000FF>“Without competition, a dominant firm can more easily reduce quality - such as by decreasing privacy protections - without losing a significant number of users,” Assistant Attorney General Makan Delrahim said. That has been a major criticism of both Facebook and Google. [5] </font>Also, technology innovations will be slowed due to lack of competitors.

 

## CONTENTION TWO: Political manipulation

<font color = \#0000FF>According to Time, Cambridge Analytica had gained access before the president election to the data of 50 million Facebook users through highly questionable means. Cambridge Analytica used to that data to manipulate American voters with targeted Facebook ads and social media campaigns. [6]</font> This is a classic example of companies using personal data to manipulate people’s minds and push them to vote for a certain person. What’s more, this technique is becoming increasingly popular.<font color = \#0000FF> According to Techcrunch, new research has found that social media manipulation is getting worse. Computational propaganda and social media manipulation have proliferated massively in recently years — now prevalent in more than double the number of countries, which is seventy now, vs two years ago. An increase of 150%. [7]</font>

The spreading of fake news and toxic narratives has become the dysfunctional new ‘normal’ for political actors across the globe, thanks to social media’s global reach. People can get fooled by supportive articles and ads and when they found out that the president that they elected was unworthy, they would no longer trust their government. <font color = \#0000FF>In the past five years, the European Union’s official research bureau found that less than [30% of Europeans had faith in their national parliaments](https://www.theguardian.com/world/2013/apr/24/trust-eu-falls-record-low) and governments – some of the lowest figures in years.[8]</font> The researchers go on to dub the global uptake of computational propaganda tools and techniques a “critical threat” to democracies.

 

## CONTENTION THREE: Data Breach *

Due to the personal data that big companies store, hackers, scammers and fraudsters are given a chance to steal them, causing data breach. <font color = \#0000FF>Equifax, one of the largest credit bureaus in the US, said on Sept. 7, 2017 that an application vulnerability in one of their websites [led to a data breach](https://www.csoonline.com/article/3444488/equifax-data-breach-faq-what-happened-who-was-affected-what-was-the-impact.html) that exposed about 147.9 million consumers. [9]</font> This happens quite frequently, as <font color = \#0000FF>according to digital guardian, 1,579 data breaches were reported in 2017.[10] And the average cost of a data breach in the U.S. is \$7.91 million, according to the [2018 Cost of Data Breach Study](https://blog.netwrix.com/2018/11/29/what-to-know-about-a-data-breach-definition-types-risk-factors-and-prevention-measures/). Healthcare organizations had the highest costs associated with a lost or stolen record, at $408. [11]</font>

The financial loss data breach brings is severe, not limited to financial terms. The damage a data breach can have on a business Lost confidence, negative press, associated identity theft, and potential customer’s views toward the company can all take a hit, leaving dark clouds over your reputation and creating long-term complications. <font color = \#0000FF>Survey research shows, in the event of a breach, consumers are quick to turn their backs, with [65% of data breach victims](https://www.centrify.com/media/4772757/ponemon_data_breach_impact_study_uk.pdf) reporting lost trust in an organization. [12]</font> As for individuals, imagine your credit card numbers, all the websites you’ve visited and all the things you bought, totally exposed to an unknown stranger, and what’s worse, who might sell it to other big companies for profit. That’s completely horrifying.

 

 

 

*recommended to use when Pro mentions healthcare (evi 11)

 

References:

[3] https://hbr.org/2018/03/here-are-all-the-reasons-its-a-bad-idea-to-let-a-few-tech-companies-monopolize-our-data ***\*Harvard Business Review\**** Here are all the reasons it’s a bad idea to let a few tech companies monopolize our data ***\*March 27 2018\****

[4] [https://www.forbes.com/sites/neilpatel/2015/01/16/90-of-startups-will-fail-heres-what-you-need-to-know-about-the-10/#2db96e366679](#2db96e366679) ***\*Forbes billionaires\**** 90% of startups fail: here’s what you need to know about the 10% 

[5] https://apnews.com/a31ee585d23143769823791942e736ab ***\*AP News\**** Top antitrust enforcer warns Big Tech over data collection ***\*November 9, 2019\****

[6] https://time.com/5197255/facebook-cambridge-analytica-donald-trump-ads-data/ ***\*Time\**** Facebook’s new controversy shows how easily online political ads can manipulate you ***\*March 19, 2018\****        

[7] https://techcrunch.com/2019/09/26/voter-manipulation-on-social-media-now-a-global-problem-report-finds/ ***\*Techcrunch\**** Voter manipulation on social media now a global problem, report finds ***\*September 26, 2019\****

[8] https://www.theguardian.com/politics/2016/jun/29/why-elections-are-bad-for-democracy ***\*The Guardian\**** Why elections are bad for democracy ***\*29 June 2016\****

[9] https://www.csoonline.com/article/2130877/the-biggest-data-breaches-of-the-21st-century.html ***\*CSO\**** The 14 biggest data breaches of the 21th century ***\*20 March 2020\****

[10] https://digitalguardian.com/blog/history-data-breaches

The history of data breaches

[11] https://www.nbcnews.com/business/consumer/total-cost-data-breach-including-lost-business-keeps-growing-n895826

 

[12]

 

 

 

 

 

 