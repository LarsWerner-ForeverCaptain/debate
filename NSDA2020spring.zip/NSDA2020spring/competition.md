# BJ ACADEMY YG (0:1)

# CON, First sp

## Rebuttal 

### FW & Def

better than status quo

(fw?) we apply cba fw

### Contention 1  big data

#### sa: crime

**Corruption and Tyranny**

Corruption -> Change the algorithm -> Tyranny

#### sb: fighting frauds

data breach cause frauds



### Contention 2 AI

> predicting poverty

​	They are only predicting poverty by algorithm -- which they said which is 99% -- algorithm are made by codes and programme -- how can we make sure the codes and programme are really based on real code, not code just output "it will solve poverty" -- their evidence can't count.

> privacy

​	It is not clear how much technology is being focused on securing these devices to protect the

people that are using them and their data. And the provider can get all the conversation between

you and AI, or get all the personal data about what you let AI do. That is a violation of privacy,

which is what we don't want to see.

> Surveillance bad

​	Surveillance menaces intellectual privacy and increases the risk of blackmail, coercion, and

discrimination. Evidence shows that mass surveillance erodes intellectual freedom and damages the social

fabric of affected societies; it also opens the door to flawed and illegal profiling of individuals. 

According to CJFE, Evidence shows that even the possibility of being under surveillance changes the way people think and act...prevent discussions that are necessary for the functioning of a free society. ... Makes the development of mutual mistrust between the individual and the state.



## Constructive

### Contention 1 Technology Monopoly

re: monopoly no unique, monopoly good, competition bad

### Contention 2 Political Manipulation

re: no magnitude, no impact

timeframe: might happen

> The New Republic

​	Cambridge Analytica broke the idea that campaigns work to convince voters that their policies will best serve them. It attempted to use psychological and other personal information to engage

in a kind of voluntary disenfranchisement by depressing and suppressing turnout with messaging

designed to keep voters who support the opposing candidate away from the polls—as well as

using that same information to arouse fear, incite animosity, and divide the electorate.

### Data Breach

magnitude: clash

scope: how users will harm

non-unique







they are keep talking about life saving -- but they are not. their data can be unreal by predicting programes which can be fake.

we mentioned all our points in our summary, while they didn't mentioned our manipulation

| crime fraud data breach              |      |      |
| ------------------------------------ | ---- | ---- |
| non unique                           |      |      |
| they rebut it by saying impact small |      |      |
|                                      |      |      |

impact: do you want your data to fall into scammers hand? Do you want those elder people being cheated and risk their money, health or even life? Our opponent is supporting data breach, our opponent is supporting those scammers doing frauds to the children and elder people. They are supporting kidnapping, and broke millions of families by data breach fraud and scams. 

| monopoly & AI                                                |      |      |
| ------------------------------------------------------------ | ---- | ---- |
| no innovation & do whatever they want                        |      |      |
| AI don't need personal data. Do the cleaning ai in ur home use personal data? |      |      |
| they use surveillance to do tyranny                          |      |      |

they make the monopoly tech do anything they want

they r telling the false truth that every ai needs personal data

they are not saving poors lives, but use surveilance to kill their freedom and democracy

| manipulation |      |      |
| ------------ | ---- | ---- |
| democracy    |      |      |
|              |      |      |
|              |      |      |



overall, they are undermine democracy, kill freedom, 













# SHFLS XZ PRO (1;0)

## Rebuttal

### FW: 

bring no harms --> impossible

everything have harm, internet has harm, cars has harm, but these are not the reasons that we don't use them

we only have to prove that our impact outweighs 

### Contention 1 data breach & hacking

1 non-uniqueness

​	Data breach is more of a hacking -- while everything can be hacked. Even the data in the bank can be hacked -- but that isn't a reason for us to stop use it

2 impact:

​	Magnitude: CSO Online https://www.csoonline.com/article/3434601/what-is-the-cost-of-a-data-breach.html 

​	Only 3 million dollars

2 see rebuttal

3 see rebuttal



### Contention 2 targeted things, random good

1 it's good

​	I've searched a lot of corona virus things, and i get them everyday -- know more
​	I've also searched a lot of histories things, and the targeted things of baidu make me more knowledgable

>  Catherine Tucker MIT Sloan School of Management Joint WPISP-WPIE Roundtable “The Economics of Personal Data and Privacy: 30 Years after the OECD Privacy Guidelines” 1 December 2010 Background Paper#1 “The Economics Value of Online Customer Data ”

​	Targetability increases the value of advertising to firms because they no longer have to pay for wasted “eyeballs‟. In other words, firms do not have to pay money to serve ads to people who are unlikely to buy a car or a vacation or suffer from that particular health complaint. Instead, firms can be reassured they are allocating their money to serve ads to customers who are potentially likely to buy their product. Behavioral targeting has empirically been shown to increase the economic value that firms place on advertising.





## Constructive

evidence of losing bitcoin: bitcoin is nothing about personal data

## Contention 1: 

they misunderstand our contention 1

corona (rebuttal)

China: use personal data to check where u go and make sure public safety -> major decrease in cases of virus

South Korean:

## Contention 2:

they mentioned about  Boeing 737 using AI and failed

1 Boeing 737's AI is not business AI 







| targeted things and business AI |                 |      |
| ------------------------------- | --------------- | ---- |
| better study                    | more convenient |      |



2 economy: mentioned in rebuttal firms can be reassured they are allocating their money to serve ads to customers who are potentially likely to buy their product. no financial waste

boeing 737: not business ones, invalid

also ecnomy can increase by having business

| safety     |                                     |      |
| ---------- | ----------------------------------- | ---- |
| blockchain |                                     |      |
| at home    | not safe<br>virus such as wanna cry |      |
| laws       | get our money back                  |      |

better safety 



| healthcare              |                                                              |      |
| ----------------------- | ------------------------------------------------------------ | ---- |
| hospital not technology | hospital **use** technology companies'<br>service to have better treatment |      |
| disease prevention      | print name on newspaper? 7 billion people                    |      |
| poor place no phone     | Our opponent is abandoning people's life<br />which could be saved as they have phone<br />and for the poors, they don't have too much inflection now |      |

impact: save lives



a world ... knowledgable, more convenient, safety, economy and safety













# SHFLS LG CON2 (2:1)

## Rebuttal 

### fw 

pd: all kinds of information

tech: google, other website

fw: stablize society, con need to prove affect our lives



### contention 1 stablize society (policing & doctor)

they have no evidence

#### Policing

1 how many criminal catched? what's the accuracy? pure speculation, can't be trusted, invalid

2 criminal can get ur personal data and do even more crime (data breach)

(they said it's not tech companies' fault --> we are talking about whether giving data to tech company is good or bad, as we've proved that giving data to tech company is unsafe, is UNSAFE good or bad? We are not talking about whether technology company is good or bad, but talking about whether let them own our data is good or bad.

how is tracking? Consent is not clear)

#### Doctor

​	How did China succeeded? Not because of the alipay things, as it appears only at the end of the corona virus. Chinese succeeded by good leading, good governance, good control, and good treading and studying. And there we saw no need for using personal data to cut the spread.

### Contention 2 society progress (convenient services, education)

​	Xiaoheiban: no need to use telephone actually, because u and teacher contact inside of this app with no need of using telephone

#### Convenient services

1 online debate --> Zoom don't use my personal data as I didn't log in, they don't use pd to make

2 use our pd to do things... data breach, frauds

#### Education

**1 data misuse danger**

​	Common Sense Media explains, “through online platforms, mobile applications, and cloud

computing, schools and edtech providers collect massive amounts of sensitive information about

students.” 

When we apply personal data in education, those technology company can get our personal

data. As for example, we don't have such kind of laws about it yet in China, so those technology

company can use those data to make money, while our data might be used for darker purposes.

For students, it could be dangerous if others get our personal data, and leave our personal data

at risk.

**2 data breach danger**

In our contention 1, we have listed reasons, examples and danger of data breach. Data breach

is not so preventable. According to Herjavec Group, there will be a data breach caused by 

ransomware attack every 11 seconds in 2021. So, educational technology companies have large

percentage to fall victim to such a data breach. Then, those students could face the scams,

frauds, malvertising, and all sorts of bad and unhealthy things. So, giving student's personal data

to technology company does harm to students, and make students' privacy at risk.



## Constructive



breach insecurity

convenient



| crime and healthcare                                         |      |      |
| ------------------------------------------------------------ | ---- | ---- |
| criminal fault? we r not blaming tech companies<br />we are blaming for letting them own our data |      |      |
| they have no evi about the accuracy, speculation<br />innocent lives<br />no internal link (our evidence ) |      |      |
| healthcare: good governance                                  |      |      |

impact: 

| safety & convenience, education                              |      |      |
| ------------------------------------------------------------ | ---- | ---- |
| at: no evidence of tracking: data breach                     |      |      |
| there are many cases, yahoo, <br>facebook, adobe creative cloud etc |      |      |
| education; the dangerous of using educational data, no rebuttal |      |      |

impact

| monopoly                                                   |      |      |
| ---------------------------------------------------------- | ---- | ---- |
| when they are first established, there are no other giants |      |      |
| when having pd, small companies can't go up                |      |      |
|                                                            |      |      |

impact

| manipulation (no reb)                                        |      |      |
| ------------------------------------------------------------ | ---- | ---- |
| undermine democracy                                          |      |      |
| It attempted to use psychological and other personal information to engage |      |      |
| in a kind of voluntary disenfranchisement by depressing and suppressing turnout with messaging |      |      |

impact



overall impact: 



## Judge: de-anonymized data (synthetic)







# BJ Keystone YH

