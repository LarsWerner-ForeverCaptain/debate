# April Sun

# Technology companies’ use of personal data is more beneficial than harmful.

# (PRO)

## CONTENTION ONE: Education

Due to its benefits, an increasing number of law makers are making student data legal. <font color = \#0000FF> 24 states in the US passed 38 new laws on secure data linkages to see how different students move through the education pipeline, according to the data quality campaign.[3] </font>Educational technology companies sell their database and platform to schools, which make great use of this privilege. <font color = \#0000FF>According to the student research foundation, the most effective educators use student data to personalize instruction, ensuring that the lessons in the classroom best match with student needs and learning styles.[4] </font>Personal data is at the heart of all of these activities. Data improves performances of both educators and students. <font color = \#0000FF>For example, according to ASCD, providing teachers with graphic displays of students' scores on formative assessments was associated with a 26 percent gain in achievement. And on average, the practice of having students track their own progress with data promoted their achievement by 32 percent.[5]</font>

Data has the potential to transform education into a personalized experience that meets the needs of individuals and ensures that no student is lost along the way. This improves student progress and teacher performance, which leads to more qualified and excellent graduates. With more outstanding candidates, companies can have more top-notch employees and potential leaders, which makes the country more productive and innovative, thanks to personal data.

 

## CONTENTION TWO: Customer experience

It is extremely difficult to sell goods and services without knowing your target audience. Rather than the so-called invasion of privacy, marketers in all domains actively use data collection to better understand their customer requirements and improve sales. <font color = \#0000FF>Data-driven organizations are 23 times more likely to acquire customers, 6 times as likely to retain customers, and 19 times as likely to be profitable as a result, according to Micro Strategy.[6] </font> Collecting data proved to be very effective. <font color = \#0000FF>The [Temkin Group](https://temkingroup.com/product/roi-customer-experience-2018/) found that companies that earn \$1 billion annually can expect to earn, on average, an additional \$700 million within 3 years of investing in customer experience. For [SaaS companies](https://www.superoffice.com/blog/saas/)\* in particular, they can expect to increase revenue by $1 billion. [7]</font> <font color = \#0000FF>There are 11,288 SaaS companies in the world. [8]</font>

As a result, marketers can gain valuable insights and trends, build audience profiles, organize effective marketing campaigns, provide personalized information etc. Also, the customers would be satisfied and are able to enjoy the conveniences personal data brings. Companies are ensuring consumers have a great experience from the first point of contact. And they are trying to build a long-term relationship with their customers to get solid word recommendations, which benefits both the customers and themselves. Business profits also allow companies to improve the livelihood of their owners, managers and employees.  

 

# CONTENTION THREE: Healthcare

<font color = \#0000FF>A personal electronic health record (EHR) is a system that collects information about the patient’s health from a number of sources, which helps to provide adequate treatment and reduce errors, which contribute to approximately 250,000 deaths annually according to CureMD. [9]</font> <font color = \#0000FF>Alerts would be better handled, for the use of EHR-based alerts resulted in an initial response rate of 50 percent according to University of Cincinnati and Ohio State University.[10]</font> Big data also improves accuracy and selectivity in clinical trials and provides actionable insights in hospital settings\*. EHR is also financially-friendly. <font color = \#0000FF>According to a survey released at ONC\*, nearly all of US hospitals are using certified EHRs.[11]  </font>And each hospital is expected to save \$850,000 in overtime costs according to evariant. [12] As for individuals,<font color = \#0000FF> [research conducted by McKinsey & Company](https://www.mckinsey.com/industries/healthcare-systems-and-services/our-insights/the-big-data-revolution-in-us-health-care) showed that big data could save Americans between \$300 billion to \$450 billion per year on health-care spending.[13]</font>

Most people can enjoy the conveniences EHR brings, as <font color = \#0000FF>EHR adoption rates are higher than ever at around 87 percent, according to physician express.[14] </font>>By using a scope of data from digital medical records, doctors can establish a link between fundamentally different symptoms, give an accurate diagnosis and provide adequate treatment to all these people using EHR. Both hospitals and patients can also save a lot of money, which can help hospitals develop faster, producing more medicine to potentially save <font color = \#0000FF>2 billion people suffering from lack of medicine [15]</font>, and increase financial freedom of individuals.

 

 

 

 

 

 

## Annotations:

\* A SaaS company is a company that hosts an application and makes it available to customers over the internet. SaaS stands for Software as a Service. This infers that the software sits on a SaaS company's server while the user accesses it remotely.

 

\* i.e., discharge planning, disease management, quality assurance, performance reporting, etc.

 

\* ONC: the Office of the National Coordinator for Health Information Technology 

 

## References:

[3] https://dataqualitycampaign.org/resource/2018-education-data-legislation/ ***\*student research foundation\****, using Student Data to Benefit Students ***\*December 15, 2017\****

[4] https://www.studentresearchfoundation.org/blog/using-student-data-to-benefit-students/

[5] http://www.ascd.org/publications/educational-leadership/dec09/vol67/num04/When-Students-Track-Their-Progress.aspx ***\*Association for Supervision and Curriculum Development\****, When students track their progress, ***\*January 2010\****

[6] https://www.microstrategy.com/us/resources/blog/bi-trends/16-statistics-showing-data-s-influence-on-customer-experience ***\*MicroStrategy\**** 16 statistics showing data’s influence on customer experience ***\*April 25, 2018\**** 

[7] https://www.superoffice.com/blog/customer-experience-statistics/

***\*S\*******\*uperoffice\**** 37 customer experience statistics you need to know in 2020 ***\*26 February, 2020\****

[8] https://cardconnect.com/launchpointe/tech-trends/rise-of-saas ***\*Cardconnect\**** The rise of software as a service (saas)

[9] https://www.curemd.com/ehr-reduce-medical-errors.asp ***\*CureMD\**** How Do EHR Systems Reduce Medical Errors? 

[10] https://www.adsc.com/blog/bid/185628/How-Electronic-Health-Record-Alerts-Benefit-Physicians-Patients ***\*Advanced Data Systems Corporation\**** How Electronic Health Record Alerts Benefit Physicians & Patients ***\*July 10\*******\*th\**** ***\*2012\****

[11]https://www.selecthub.com/medical-software/emr/electronic-medical-records-future-emr-trends/ ***\*Select Hub\**** Future of Electronic Medical Records: Experts Predict EMR Trends in 2020 

[12] https://www.evariant.com/blog/big-data-creates-big-improvements-in-healthcare ***\*evariant\**** Infographic: big data creates improvements in healthcare ***\*October 12, 2015\****

[13] https://www.mckinsey.com/industries/healthcare-systems-and-services/our-insights/the-big-data-revolution-in-us-health-care ***\*McKinsey & Company\**** The big data revolution in US healthcare : Accelerating value and innovation ***\*April 2013\****

[14] https://physicianxpress.com/15-latest-statistics-ehr-prove-importance/ ***\*Physician Press\**** 15 latest statistics on HER to prove its importance ***\*Dec 15 2017\****

[15] https://www.who.int/publications/10-year-review/medicines/en/ ***\*WHO\**** Access to medicines: making market forces serve the poor 

 

 

#  

 

#  

 

 

 

 