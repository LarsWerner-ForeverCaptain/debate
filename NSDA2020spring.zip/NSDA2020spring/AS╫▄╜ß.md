# PRO



# Rebuttal

## FW

identify person

privacy laws are weak

only on two points

> they only consider two points in their framework
>
> but we consider the overall impact of all aspects, so our framework should be applied

## Contention 1 monopoly

see rebuttal

## Contention 2 privacy issue & identity theft

data theft

privacy laws loophole

> they said that they will have loophole, but they never have any examples about how tech companies find legal loopholes.

> GDPR has never been found a loopohole, and even google has been punished by this regulation

## Contention 3 discrimination

poor

> we help the poor in all sorts of aspect: according to our contention 2, we offer them enough food to eat, humanism aid, and financial aid.
>
> for the poor now, the most thing needed is those aid
>
> and they got no evidence showing exactly how many poor are being discriminated, while we help those 1.2 billion people in extreme poverty and provide food for the whole people on the globe. We provide a stronger magnitude on the impact, and solid evidence showing.
>
> > discriminating







# Constructive

## Contention 1 Healthcare

## Sa: EHR

> no way to make cure
>
> only collection
>
> > collects information about the patient’s health , which helps to provide adequate treatment and reduce errors. The errors used to contribute to approximately 250,000 deaths annually according to CureMD. 

## Sb: Epidemic prevention

> no way to make cure
>
> > China
> >
> > South Korean Example
> >
> > This explains how the South Korean government has been able to rapidly “contact-trace” hundreds of thousands of its own citizens to curb the outbreak. South Korea has officially turned the tide, [reporting](https://www.reuters.com/article/us-health-coronavirus-southkorea/south-korea-reports-more-recoveries-than-coronavirus-cases-for-the-first-time-idUSKBN210051) more recoveries per day than new infections.
> >





## Contention 2 Poverty alleviation

## Sa: Sustainable Agriculture

2.3 trillion dollars



## Sb: Support & Aid

99 percent more accurately

> can't support for their whole lives
>
> > China's supporting poor

## Clashes



framework: our framework consider all aspects and they didn't rebut our fw, so we should apply our fw about economy

| monopoly                          |                   |      |
| --------------------------------- | ----------------- | ---- |
| price lower and more innovation   | good to market    |      |
| share anonymous data (in germany) | help smaller ones |      |
|                                   |                   |      |



| poverty & discrimination |                                                              |                                                        |
| ------------------------ | ------------------------------------------------------------ | ------------------------------------------------------ |
| discrimination           | only in 2005, have fixed                                     |                                                        |
| agirculture              | they give no rebuttal <br>towards that                       | 2.3 trillion economy impact<br>feed billions of people |
| aid                      | they didn't rebut refugee problem<br>predict poverty 99% accuracy<br />save them | save 1.2 billion poverty                               |

| privacy & healthcare              |      |      |
| --------------------------------- | ---- | ---- |
| no evidence of how much data lost |      |      |
|                                   |      |      |
|                                   |      |      |







# PRO

# Rebuttal



## FW 

dehumanization nationlism



## Contention 1 manipulation & digital nationalism

1 racist discrimination

(how many)

2 social media

3 manipulation

won't happen

no impact

no evidence



## Contention 2 







# Constructive

## FW economy & social & poverty

​	The world economy and individual benefits, because our world will collapse without a strong and stable economy, and we prospect social-wellbeing and less poverty.

## Contention 1 Healthcare

## Sa: EHR 



## Sb: Epidemic prevention 





## Contention 2 Poverty alleviation

## Sa: Sustainable Agriculture

2.3 trillion dollars



## Sb: Support & Aid 

99 percent more accurately



# ff

fw: we consider all aspects includes economy, human rights and saving lives.

def: our def is come from General Data Protection Regulation

tech company using: tech company is collecting data, tech company is analysing, tech company use it to identify poverty and refugees

big data: our point is ... not big data

general impact: 



1 their contention about digital nationalism

 	1. out of topic as they changing algorithm has nothing to to with TECH COMPANY using data
 	2. racist: laws to prevent (mentioned in rebuttal)







# vs SHFLS HD (PRO)

## Rebuttal

### FW: CBA

### Contention 1 data breach

misuse, frauds

> how much money loss? how many people are being scammed and under fraud because of data breach?
>
> **1 Blockchain**
>
> > **Lotte Schou-Zibell**,Regional Director, Pacific Liaison and Coordination Office (PLCO), **Nigel Phair**,Director, UNSW Canberra Cyber, https://blogs.adb.org/blog/how-secure-blockchain
> >
> > block9solutions, May29 2018, https://medium.com/coinmonks/guarantee-your-patients-privacy-today-securing-sensitive-data-with-blockchain-fcb179f1302c
> >
> > https://101blockchains.com/companies-using-blockchain-technology/
>
> <font color = green>	Blockchain can achieve simultaneous security and privacy in an information system by enabling confidentiality through “public key infrastructure” </font>
>
> <font color = green>If the hacker isn’t using the right files on the right computer, it is impossible for him to get to the point where it is even possible to crack the password.</font>
>
> ​	Blockchain can protect data in a safe way that no hacker has even hacked. <font color = green>And according to 101blockchains, there are 50 companies using blockchain now and the number is on the rise.</font>
>
> 
>
> **2 laws**
>
> > NCSL, https://www.ncsl.org/research/telecommunications-and-information-technology/2019-security-breach-legislation.aspx
>
> ​	Modifies certain provisions relating to personal information security breach protection, Provides for an affirmative defence to certain claims relating to personal information security breach protection. 
>
> ​	Law have things to be against breach and provide affirmative defence. We can also use laws to protect our self, and get back the money that are stolen.. 
>
> 
>
> **3 rebuttal to their evidence: it's all data breach, not tech companies' personal data data breach**
>
> **4 make data more secure** biometric, secure password etc.

### Contention 2 political manipulation

> how many people are under manipulation and be manipulated, choose the one that he doesn't choose before?
>
> ## AT: Political manipulation
>
> **Analyse**
>
> no internal link between cambridge analytica and trump
>
> **Cambridge Analytica's impact on Trump's success and Brexit is too small**
>
> According to [CNN](https://edition.cnn.com/2016/11/10/politics/why-donald-trump-won/index.html),  they mainly vote for Trump because of 24 reasons while non of them is about Cambridge Analytica. Some of the 24 reasons are "While male resentment, Left and coastal elites shamed Trump supporters, Democratic Party only vote tor him, Reagan #Democrats surged in Michigan and Midwest". And so on..
>
> Brexit: start before ca and end after ca, lots of voting...
>
> 
>
> **After that, people will be aware and no more political manipulation**
>
> People all see how cambridge analytica ends. CA go bankrupt, and they don't give other companies who do the political manipulation, so we can see, the only manipulation companies go bankrupt, so there will be no impact of this from now on.
>
> **non-uniqueness**
>
> It's just like other ads.

### Contention 3 monopoly

> how much money will be loss? they said about economy depression, but now there are some companies who are the "monopoly" as our opponent said, but it caused no economy downturn.
>
> **No evidence about how many small companies close**
>
> **Benefit of some good monopoly**
>
> > https://www.economicshelp.org/blog/265/economics/are-monopolies-always-bad/
>
> According to EconomicsHelp
>
> 1 Lower average cost (economies of scale)
>
> ​	<font color = green> Small firm has higher average costs, while increasing output which is those big tech leads to lower average costs.</font>
>
> ​	And that means those companies can provide us with cheaper products.
>
> 2 More innovation
>
> ​	1 More incentive to innovate
>
> ​	<font color = green>Without patents and monopoly power, companies would be unwilling to invest so much in research. The monopoly power of patent provides an **incentive** for firms to develop new technology.</font>
>
> ​	2 More money to innovate
>
> ​	<font color = green>Also, monopolies make supernormal profit and this supernormal profit can be used to fund investment which leads to **improved technology and dynamic efficiency**.</font>
>
> **Prevention of Bad Sides of Monopoly**
>
> > https://www.technologyreview.com/s/613640/big-tech-monopoly-breakup-amazon-apple-facebook-google-regulation-policy/
>
> According to Technology Review
>
> 1 Share anonymous data
>
> ​	<font color = green>Mayer-Schönberger suggests that large companies be required to share anonymized data with less powerful competitors. In Germany, for instance, big insurers already [share some data with smaller ones](https://www.foreignaffairs.com/articles/world/2018-08-13/big-choice-big-tech). That way, startups have a chance too.</font>
>
> 2 Stop locking users to use only one product
>
> ​	<font color = green>Data interoperability enables different services to work together—for instance, allowing Instagram users to post to Snapchat and vice versa.</font> (When AOL and Time Warner merged in 2001, the FCC forced AIM Instant Messenger to become compatible with them.)
>
> **Small tech will have innovation and can survive**
>
> ​	Google survive, Tik-Tok survive.
>
> ​	In order to compete with tech giants, small tech companies will be innovated, thus providing us with better services. 

impact: 

IMPACT (economy)

​	According to CIO, healthcare industry could save $500 billion by applying big-data analysis to existing data sets.

​	Using data to do sustainable farming <font color = green>could produce commercial opportunities and new savings worth US$2.3 trillion overall worldwide annually.</font>

​	A report from MGI estimates that using personal data could generate an additional $3 trillion in value every year apart from that.

​	The economy impact clearly outweighs any of their contentions' impact.

IMPACT (saving lives)

​	We can let 80% of refugees get their identity and save them, save the 1.2 billion people who live in extreme poverty, 2 billion people who are lack of medicine, feed the whole world of 9.6 billion people w/o expanding the area of farmland.

​	Impact of lives of billions of people and feeding the whole world clearly outweighs any of their impact.

## Constructive

### FW

### Contention 1 Healthcare

### SA EHR

>1 healthcare discrimination
>
>2 discriminate lives -> don't save lives

### SB epidemic

>1 US most sevior (don't have benefit)
>
>​	Not China
>
>2 hospital $\not=$ tech companies
>
>> the cooperate
>
>3 data breach

### Contention 2 alleviation

### SA: Agriculture

>1 misunderstand to education

### SB: Altuistic support

>1 discrimination





### 1 data safety

blockchain: number of using on the rise, safe enough

no evidence about how much economy loss

### 2 manipulation

no internal link, don't directly lead

cambrigde analytica bankrupt, no other manipulation companies

### 3 monopoly

benefit consumers much by offering lower price and more innovation

prevent bad sides of monopoly

overall innovation

### 4 discrimination

saving lives is the most important, financial support to go into society

### 5 healthcare

EHR don't make price expensive: aft public health service as we're doing now,   they don't have extra cost to the poor 

### 6 saving poors

agriculture: 2.3 trillion, whole global

poverty: we give them financial support using money we've benefited and the rate is 99%

## IMPACT (economy)

​	According to CIO, healthcare industry could save $500 billion by applying big-data analysis to existing data sets.

​	Using data to do sustainable farming <font color = green>could produce commercial opportunities and new savings worth US$2.3 trillion overall worldwide annually.</font>

​	A report from MGI estimates that using personal data could generate an additional $3 trillion in value every year apart from that.

​	The economy impact clearly outweighs any of their contentions' impact.

## IMPACT (saving lives)

​	We can let 80% of refugees get their identity and save them, save the 1.2 billion people who live in extreme poverty, 2 billion people who are lack of medicine, feed the whole world of 9.6 billion people w/o expanding the area of farmland.

​	Impact of lives of billions of people and feeding the whole world clearly outweighs any of their impact.





## vs NJFLS GY

## Rebuttal

### Fw  protect user privacy&safety

tech: produce technical products

pd: identify

### Contention 1 privacy

**Impact small**

**Regulation**

​	GDPR Google

> GDPR useless
>
> > Google case

​	Facebook: FTC fines facebook $5 billion for privacy 

**Save the world better by everyone giving out a little bit of his/her privacy**

​	Judge, do you want to see a better world, save billions of people and trillions of dollars? Do you want to see the world that poverty has been solved, refugees can live happier lives, and people are not worried about medical problem? We can reach that, and the cost is very simple: give out a bit of the personal data, and form the data that tech companies can analyse and offer you a better tomorrow. Compare to the whole global prosperity, what is the matter of a bit of personal data given out, with laws and technology protected? Humans want progress, and now, everyone giving a bit of personal data can make society progress, make a better tomorrow. 

### Surveillance

1 nothing with technology companies

​	They are GOVERNMENTS who use personal and do surveillance, not TECH companies.

2 evidence about how many



### Contention 2 data theft

**1 Blockchain**

> **Lotte Schou-Zibell**,Regional Director, Pacific Liaison and Coordination Office (PLCO), **Nigel Phair**,Director, UNSW Canberra Cyber, https://blogs.adb.org/blog/how-secure-blockchain
>
> block9solutions, May29 2018, https://medium.com/coinmonks/guarantee-your-patients-privacy-today-securing-sensitive-data-with-blockchain-fcb179f1302c
>
> https://101blockchains.com/companies-using-blockchain-technology/

<font color = green>	Blockchain can achieve simultaneous security and privacy in an information system by enabling confidentiality through “public key infrastructure” </font>

<font color = green>If the hacker isn’t using the right files on the right computer, it is impossible for him to get to the point where it is even possible to crack the password.</font>

​	Blockchain can protect data in a safe way that no hacker has even hacked. <font color = green>And according to 101blockchains, there are 50 companies using blockchain now and the number is on the rise.</font>

> > blockchain small impact
> >
> > > on the rise, growing trend, 50+



**2 laws**

> NCSL, https://www.ncsl.org/research/telecommunications-and-information-technology/2019-security-breach-legislation.aspx

​	Modifies certain provisions relating to personal information security breach protection, Provides for an affirmative defence to certain claims relating to personal information security breach protection. 

​	Law have things to be against breach and provide affirmative defence. We can also use laws to protect our self, and get back the money that are stolen.. 



**3 rebuttal to their evidence: it's all data breach, not tech companies' personal data data breach**

**4 make data more secure** biometric, secure password etc.

**5 impact **their economy impact is only 1 billion dollars...



tech companies use of pd:

health:

1 ehr: cooperae with hospitale

2 epidemic: wechat, tencent...

poverty:

1 agri: tech comp do analyse and siuggeset

2 alleviation: te





## Constructive

### Fw economy&lives

### Contention 1 health

### SA EHR

>doesn't include accidents
>
>> 1 billion people have died of normal diseases

### SB epidemic

>no evidence of using
>
>> 

### Contention 2 poverty

### SA Agriculture

>

### SB Alleviation

>







### FW

saving lives and better economy, or some bit of privacy

their fw is also bias, our fw impact big

### data loss & privacy

GDPR -> GDPR is useful, preventing Google's invasion of privacy

Other laws -> fining Facebook of invading privacy

surveillance: it's governments' use, not tech companies' use

blockchain -> growing trend, now 50+, never been hacked, still on the rise

protection -> biometrics

### Healthcare

tech companies -> they cooperate with hospitals, collect and analyze data themselves

accidents -> they abandon those lives who can be saved

epidemic -> 

### Poverty

they mentioned big data can solve -> how come big data w/o collecting pd, agreeing on our side

tech comapnes collect and analyse -> their usage

impact huge

## IMPACT (economy)

​	According to CIO, healthcare industry could save $500 billion by applying big-data analysis to existing data sets.

​	Using data to do sustainable farming <font color = green>could produce$2.3 trillion overall worldwide annually.</font>

​	A report from MGI estimates that using personal data could generate an additional $3 trillion in value every year apart from that.

​	The economy impact clearly outweighs any of their contentions' impact.

## IMPACT (saving lives)

​	We can let 80% of refugees get their identity and save them, save the 1.2 billion people who live in extreme poverty, 2 billion people who are lack of medicine, feed the whole world of 9.6 billion people w/o expanding the area of farmland.

​	Impact of lives of billions of people and feeding the whole world clearly outweighs any of their impact.

WOEE









# vs YKPao LT PRO

## Rebuttal

### FW CBA (security risk)



### Contention 1 economy

### SA: 1 billion dollars of cybercrime (data breach)

​	Not all personal data, because of tech companies', not because of personal data.

### SB: bad data 3.1 trillion 

​	Not personal data!!!

### Contention 2 discrimination

>https://www.technologyreview.com/s/613640/big-tech-monopoly-breakup-amazon-apple-facebook-google-regulation-policy/

​	<font color = green>[Hal Singer](https://gwipp.gwu.edu/hal-singer-senior-scholar-non-resident) proposes a non-discrimination principle that would prevent this. This is how cable channels are already regulated.</font>

​	<font color = green>Now, **independent networks** can bring complaints to a **neutral arbitrator** that is responsible for making sure everyone is treated fairly.</font>

> https://fra.europa.eu/en/news/2018/4-possible-ways-avoid-big-data-bias

​	FRA listed that to prevent data discrimination and bias, we should: Being transparent about how algorithms were built so others can detect and rectify discriminatory applications.



2 we save them



**Laws**

Civil Rights Act of 1964





### Contention 3 healthcare bad

### SA anti-vaccination

​	False information

> not personal data

### SB fake medicine

​	Targeted

> EHR save more



in cf: only little percentage: 

​	if you use EHR, you contribute 

impact







## Constructive

### FW：economy&lives

> lives: they only care about data security, while we care about saving people and economy

### Contention 1 healthcare

### SA EHR

>foudner isn;t tech companies
>
>> they cooperate, EHR can never exist w/o the help of tech companies
>
>healthcare bad, people don't want
>
>> 

### SB Epidemic

>not been solved
>
>> We've seen progess.
>
>w/o consent
>
>> no evidence about Chinese govt using data to do bad things
>>
>> no evidence about Chinese govt 

### Contention 2 poverty

### SA Agriculture

>

### SB Altrustic Support

>tech generate refugees
>
>hate speeches
>
>> 







### FW

we care not only about economy, misunderstand our fw, but also about the lives.

### Cybercrime

​	1 not personal data

​	2 data safety: blockchain, better security

### Bad data

​	1 not personal data

### Discimination

​	1 Ways to solve

​	2 FRA (transparent)

### Poverty

​	1 crop data is data, they continuesly misunderstand us

​		we need crops' quality, amount... 

### Health

​	1 anti-vaccination: no internal link, not pd

​	2 fake medicine: be found, we have greater impact

​	3 EHR: we can still use it if some people don't use

​	4 epidemic: countries have progress



## IMPACT (economy)

​	According to CIO, healthcare industry could save $500 billion by applying big-data analysis to existing data sets.

​	Using data to do sustainable farming <font color = green>could produce new savings worth US$2.3 trillion overall worldwide annually.</font>

​	A report from MGI estimates that using personal data could generate an additional $3 trillion in value every year apart from that.

​	The economy impact clearly outweighs any of their contentions' impact.

## IMPACT (saving lives)

​	We can let 80% of refugees get their identity and save them, save the 1.2 billion people who live in extreme poverty, 2 billion people who are lack of medicine, feed the whole world of 9.6 billion people w/o expanding the area of farmland.

​	Impact of lives of billions of people and feeding the whole world clearly outweighs any of their impact.









# vs Starriver CQ CON

## Rebuttal

### FW: con needs status quo, quantifiably

bias. topic is cost benefit analyze, so we should apply pure cba, which is ours

### Contention 1 targeted ads

### SA buy things

> https://www.forbes.com/sites/roberthof/2012/03/09/people-dont-want-personalized-ads-what-should-marketers-do/#2d3587722079

​	According to the survey of about 2,000 American adults early this year, <font color = green>65% of people who were asked how they'd feel if a search engine used the information to personalized future results said it's a bad thing because it limits information they get.</font>

> https://blog.convert.com/personalization-too-much.html

<font color = green> A whopping 78 percent of U.S. citizens think that a brand should not use their personal data to market to them.</font>



**Impact weighing**

​	data breach 6 trillion, and they only have imapact with a billion or two.

​	

### SB analytics&predict

They mentioned that 

**Political Manipulate,Price**

> [8] The New Republic,https://newrepublic.com/article/151548/political-campaigns-big-data-manipulate-elections-weaken-democracy

​	Technology such as Cambridge Analytica, **"personalize" your news and manipulate you politically**. According to The New Republic, It attempted to use psychological and other personal information to **engage in a kind of voluntary disenfranchisement**. 



impact:

https://www.herjavecgroup.com/wp-content/uploads/2018/12/CV-HG-2019-Official-Annual-Cybercrime-Report.pdf

​	6 trillion outwigeh



### Contention 2 protecting

### SA healthcare

**1 Lose trust between hospitals and patients & hacking**

​	<font color = green>This past June, Chicago Medical Centre failed to scrub timestamps from anonymized medical records. </font><font color = green>Those timestamps</font> <font color = green>could reveal the identities of individual patients</font>. $^{[6]}$ 

​	After knowing their data was leaked and data can be hacked, patients could lose trust in the data usage of that hospital, and lose trust of patients & hospitals.  We can never realize better treatment w/o even getting trust between hospital and patients

**2 health fraud**

​	<font color = green>More than 100 million people were affected by health data breaches in 2015, and there was an 80% increase in the number.$^{[3]}$</font> The data which goes into scammers' hands lead to health fraud scams. That could lead to false medicine. 

**3 health monopoly which leads to higher price**

​	As hospitals and tech companies collect too much data and monopoly the research of medical field, this will cause health monopoly. The monopoly of hospitals causes high price. A recent and widely discussed [study](https://healthcarepricingproject.org/papers/paper-1) by Yale economist Zack Cooper has found that if you stay in a monopoly hospital, your bill will be $1,900 higher on average. That's unaffordable for the poor people.

### SB prevent crime

**Not tech campnies**

**Criminal and hackers use big data to escape**

> Datanami, October 12, 2016 https://www.datanami.com/2016/10/12/criminals-are-using-big-data-tech-and-so-should-you/

​    “The sophistication, agility, and speed at which a criminal operates and monetizes their fraudulent information have improved through the use of data analytics,” Kate McGavin, a senior product marketing manager at RSA, wrote. So promote crime.

**More crime and bad results**

> https://www.forbes.com/sites/daniellecitron/2014/12/24/beware-the-dangers-of-location-data/#1caf1b2643cb

​	Geolocation pesonal data tells us intimate, revealing details about people's lives. As AG Harris [told](http://www.usatoday.com/story/news/nation/2014/12/22/california-attorney-general-smartphone-wawrning/20778295/) USA Today, "Broadcasting your personal data can sometimes expose you and your family to risk of theft or physical harm. … A 'selfie' with this kind of personal data can be dangerous, especially for victims of stalking or domestic abuse.'



## Constructive







### FW

pure CBA

### Targeted products

​	1 78% people don't want to use it

​	2 5%return rate->this does not mean that people want targeted ads, it only shows that 		 people are somehow satisfied with some producst, nothing with pd

​	3 politicla manipulation -> they are not under their choice, pyhchological

### Healthcare

​	1 health monopoly -> 1900 dollars more (abandon poor)

​	2 healthcare data breach -> worth impact

​	3 lost trust -> lost trust about all hospitals

### Crime Prevention

​	not tech

​	1 promote crime

### Monopoly

​	1 no innovation

​	2 35% unemployment

### Data breach

​	1 billions of privacy loss

​	2 mentioned in constructive (suicide)

​	3 cause much cybercrime, even if it doens't consist all the cybercrime, the economy loss of data breach is still over trillions



35% unemployment

loss trust in hospitals

medical scamsq

phychological harm to democracy

6 trillions



# vs Tsinghua HS LM  PRO

## Rebuttal

### FW privacy

more important

### Contention 1 data insecurity, privacy

data breach, records stolen

> **1 Blockchain**

> <font color = green>	Blockchain can achieve simultaneous security and privacy in an information system by enabling confidentiality through “public key infrastructure” </font> Blockchain can protect data in a safe way that no hacker has even hacked. <font color = green>And according to 101blockchains, there are 50 companies using blockchain now and the number is on the rise.</font>

> **2 rebuttal to their evidence: it's all data breach, not tech companies' personal data data breach**

> **3 make data more secure** biometric, secure password etc.

inequality, discimination

> ​	<font color = green>Now, **independent networks** can bring complaints to a **neutral arbitrator** that is responsible for making sure everyone is treated fairly. </font> we should: Being transparent about how algorithms were built so others can detect and rectify discriminatory applications.

> **Laws**Civil Rights Act of 1964



crime rate

> crime prevention
>
> Tech companies using data to form crime detection AI and in LA, because of that, we saw a 33% drop in burglaries, 21% decrease in violent crime and 12% reduction in property  crime. According to Kaspersky, this data analytical systems can successfully cope wit predicting street crimes, street riots and acts of terrorism.

### Contention 2 social mobility

poor & rich

> help poor

monopoly, barrier to entry

**Benefit of some good monopoly**

> https://www.economicshelp.org/blog/265/economics/are-monopolies-always-bad/

According to EconomicsHelp

Those companies can provide us with cheaper products.

​	1 More incentive to innovate

​	<font color = green>Without patents and monopoly power, companies would be unwilling to invest so much in research. The monopoly power of patent provides an **incentive** for firms to develop new technology.</font>

​	2 More money to innovate

​	<font color = green>Also, monopolies make supernormal profit and this supernormal profit can be used to fund investment which leads to **improved technology and dynamic efficiency**.</font>

**Prevention of Bad Sides of Monopoly**

According to Technology Review

1 Share anonymous data <font color = green>Mayer-Schönberger suggests that large companies be required to share anonymized data with less powerful competitors.</font>

**Small tech will have innovation and can survive**

### Contention 3 manipulation, kill protest

kill protest

> still can give our idea

targeted

> **non-uniqueness**

> It's just like other ads.             
>
> no link

manipulation

>**Analyse** no internal link

> **Cambridge Analytica's impact on Trump's success and Brexit is too small**

> According to [CNN](https://edition.cnn.com/2016/11/10/politics/why-donald-trump-won/index.html),  they mainly vote for Trump because of 24 reasons while non of them is about Cambridge Analytica. 
>
> **no evidence**
>
> they have no evidence showing "how many people are actually being under the manipulation".

## Constructive

### FW: economy&save lives

### Contention 1 Healthcare

### SA EHR (2 billion people, 500 billion$)

>targeted pricing
>
>> EHR not like that
>>
>> EHR is tech and hospital cooperate and 

### SB Epidemic

>

### Contention 2 Poverty

### SA Agriculture (2.3 trillion$)

>not associated

### SB Altruisic support (80% refugees, 1.2 billion people)

>identity theft
>
>> they have chances to live
>>
>> opponent abandon them





### FW 

economy&lives > privacy

### Data security&privacy

blockchain -> 50+, data safety

laws work(grpr, google)

### Targeted things

discrimination: we help poor

alchohol: no specific evidence showing internal and specific link

political: no evidence, no internal link

### Monopoly & Economy

benefit of some monopoly

prevent bad sides of companes sharing anonymous data(mentioend in rebuttal)

### Healthcare

EHR: save lives

Epidemic: Chines, south kor, europeans

### Poverty&Refugees

agri

pov

refu: find and support





## IMPACT (economy)

​	According to CIO, healthcare industry could save $500 billion by applying big-data analysis 

​	Using data to do sustainable farming <font color = green>could produce US$2.3 trillion annually.</font>

​	A report from MGI estimates that using personal data could generate an additional $3 trillion in value every year apart from that.

​	The economy impact clearly outweighs any of their contentions' impact.

## IMPACT (saving lives)

​	We can let 80% of refugees get their identity and save them, save the 1.2 billion people who live in extreme poverty, 2 billion people who are lack of medicine, feed the whole world of 9.6 billion people w/o expanding the area of farmland.

​	Impact of lives of billions of people and feeding the whole world clearly outweighs any of their impact.















