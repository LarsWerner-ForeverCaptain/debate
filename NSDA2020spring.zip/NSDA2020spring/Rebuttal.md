# PRO

# I M P A C T ! ! !

## AT: Data Breach

**Analyze**

Magnitude: small, less than the data of us, and we can save huge numbers of people



**1 Blockchain**

> **Lotte Schou-Zibell**,Regional Director, Pacific Liaison and Coordination Office (PLCO), **Nigel Phair**,Director, UNSW Canberra Cyber, https://blogs.adb.org/blog/how-secure-blockchain
>
> block9solutions, May29 2018, https://medium.com/coinmonks/guarantee-your-patients-privacy-today-securing-sensitive-data-with-blockchain-fcb179f1302c
>
> https://101blockchains.com/companies-using-blockchain-technology/

<font color = green>	Blockchain can achieve simultaneous security and privacy in an information system by enabling confidentiality through “public key infrastructure” </font>

<font color = green>If the hacker isn’t using the right files on the right computer, it is impossible for him to get to the point where it is even possible to crack the password.</font>

​	Blockchain can protect data in a safe way that no hacker has even hacked. <font color = green>And according to 101blockchains, there are 50 companies using blockchain now and the number is on the rise.</font>



**2 laws**

> NCSL, https://www.ncsl.org/research/telecommunications-and-information-technology/2019-security-breach-legislation.aspx

​	Modifies certain provisions relating to personal information security breach protection, Provides for an affirmative defence to certain claims relating to personal information security breach protection. 

​	Law have things to be against breach and provide affirmative defence. We can also use laws to protect our self, and get back the money that are stolen.. 



**3 rebuttal to their evidence: it's all data breach, not tech companies' personal data data breach**

**4 make data more secure** biometric, secure password etc.



## AT: Security

pd -> biometrics protection

> https://duo.com/decipher/stop-the-pwnage-81-of-hacking-incidents-used-stolen-or-weak-passwords

​	According to the 10th edition of the Verizon Data Breach Investigations Report, 81 percent of hacking-related breaches leveraged stolen and/or weak passwords.

> https://www.forbes.com/sites/louiscolumbus/2020/03/08/why-your-biometrics-are-your-best-password/#70fb4a0a6c01

​	Biometrics are proving to be better than passwords because they’re easier to use, provide greater privacy and security

> https://samsungnext.com/whats-next/why-biometrics-are-on-track-to-replace-the-password/

​	“It disrupts a hacker’s attack vector,” he says, “as they can no longer focus on huge server stockpiles of user credentials." And make it much safer.

## AT: frauds

**Tech companies use data to prevent fraud**

>Adam C. Uzialko, 2018 "How and Why Businesses Collect Consumer Data," Business News Daily, https://www.businessnewsdaily.com/10625-businesses-collecting-data.html

​	These systems work by marrying data from a customer's interaction with a call center and machine learning algorithms that can identify and flag potentially fraudulent attempts to access a customer's account. 

> https://theaims.ac.in/resources/5-ways-big-data-can-change-crime-prevention.html

<font color = green>The Nationwide Building Society managed to reduce fraud losses by 75% using SAS software, says David Parsons, head of fraud analytics.</font> "We now have huge amounts of data and can look at any number of parameters to help us spot anomalous behaviour," he says. 



## AT: Technology Monopoly

**Benefit of some good monopoly**

> https://www.economicshelp.org/blog/265/economics/are-monopolies-always-bad/

According to EconomicsHelp

1 Lower average cost

​	<font color = green> Small firm has higher average costs, while increasing output which is those big tech leads to lower average costs.</font>

​	And that means those companies can provide us with cheaper products.

2 More innovation

​	1 More incentive to innovate

​	The monopoly power of patent provides an **incentive** for firms to develop new technology.

​	2 More money to innovate

​	<font color = green>Also, monopolies make supernormal profit and this supernormal profit can be used to fund investment which leads to **improved technology and dynamic efficiency**.</font>

evidence：

​		It has positive signiﬁcant impact on both new product and new process innovations. The eﬀect is large in magnitude increasing the probability of new product innovation by 31%。

**Prevention of Bad Sides of Monopoly**

> https://www.technologyreview.com/s/613640/big-tech-monopoly-breakup-amazon-apple-facebook-google-regulation-policy/

According to Technology Review

1 Share anonymous data

​	<font color = green>Mayer-Schönberger suggests that large companies be required to share anonymized data with less powerful competitors. In Germany, for instance, big insurers already [share some data with smaller ones](https://www.foreignaffairs.com/articles/world/2018-08-13/big-choice-big-tech). That way, startups have a chance too.</font>

2 Stop locking users to use only one product

​	<font color = green>Data interoperability enables different services to work together—for instance, allowing Instagram users to post to Snapchat and vice versa.</font> (When AOL and Time Warner merged in 2001, the FCC forced AIM Instant Messenger to become compatible with them.)

**Small tech will have innovation and can survive**

​	Google survive, Tik-Tok survive.

​	In order to compete with tech giants, small tech companies will be innovated, thus providing us with better services. 





## AT: Data Transaction

> [4] **Lotte Schou-Zibell**,Regional Director, Pacific Liaison and Coordination Office , **Nigel Phair**,Director, UNSW Canberra Cyber, https://blogs.adb.org/blog/how-secure-blockchain
>
> [5] Anita Lettink, https://www.ngahr.com/blog/use-of-blockchain-secures-personal-data

**Regulation**

All on people's will:

> IT Governance https://www.itgovernance.eu/blog/en/gdpr-when-do-you-need-to-seek-consent

​	<font color = green>GDPR requires a positive opt-in and opt-out, it also requires that individuals can withdraw their data at any time to protect their privacy.</font>



**Blockchain**



​	

## AT:  Discrimination

>https://www.technologyreview.com/s/613640/big-tech-monopoly-breakup-amazon-apple-facebook-google-regulation-policy/

​	<font color = green>[Hal Singer](https://gwipp.gwu.edu/hal-singer-senior-scholar-non-resident) proposes a non-discrimination principle that would prevent this. This is how cable channels are already regulated.</font>

​	<font color = green>Now, **independent networks** can bring complaints to a **neutral arbitrator** that is responsible for making sure everyone is treated fairly.</font>

> https://fra.europa.eu/en/news/2018/4-possible-ways-avoid-big-data-bias

​	FRA listed that to prevent data discrimination and bias, we should: Being transparent about how algorithms were built so others can detect and rectify discriminatory applications.

**It reduce discrimination**

1 Machines are less biased than human.

2 Algorithms' bias can be better fixed, while human's can't

**So, by using personal data and machines, we can better fix the discrimination than the human.**

> https://www.verdict.co.uk/ai-and-bias/

​	Data scientists and statisticians assess a system’s underlying data and judge its representativeness . Once biases are identified, adjustments can be made, typically without the emotional resistance that comes from directly confronting human prejudices. This means that machines biases will tend to decrease over time.

>https://www.nytimes.com/2019/12/06/business/algorithm-bias-fix.html

​	Changing people’s hearts and minds is no simple matter. In contrast, Discrimination by algorithm can be more readily discovered and more easily fixed. With proper regulation,  algorithms can become a potentially powerful force for good: they can dramatically reduce discrimination of multiple kinds. ([here](https://academic.oup.com/jla/article/doi/10.1093/jla/laz001/5476086))

**Laws**

Civil Rights Act of 1964



## AT: target ads to vulnerable groups (addiction)

> Kim SJ, Marsch LA, Hancock JT, Das AK. Scaling Up Research on Drug Abuse and Addiction Through Social Media Big Data. J Med Internet Res 2017;19(10):e353. DOI: [10.2196/jmir.6426](https://doi.org/10.2196/jmir.6426) https://www.jmir.org/2017/10/e353/

​	Performing data analytics on social media content allows researchers to generate data-informed insights intosocial media communication data aggregated by drug use–related search keywords can indicate the level and stage of drug dependence, the actions of patients engaging in addiction recovery support groups, former users with or without relapse episodes, or current users with or without dependence.

​	Social media big data on the nationwide public health problem of nonmedical use of prescription drugs in the United States can also have a practical impact at the individual level (eg, seeking social support for addiction recovery support), as well as at the societal level (eg, public health campaign efforts on this topic).



## AT: Overconsumption

1 economy

​	



## AT: Political manipulation

**Analyse**

no internal link

**Cambridge Analytica's impact on Trump's success and Brexit is too small**

According to [CNN](https://edition.cnn.com/2016/11/10/politics/why-donald-trump-won/index.html),  they mainly vote for Trump because of 24 reasons while non of them is about Cambridge Analytica. Some of the 24 reasons are "While male resentment, Left and coastal elites shamed Trump supporters, Democratic Party only vote tor him, Reagan #Democrats surged in Michigan and Midwest". And so on..

Brexit: start before ca and end after ca, lots of voting...

**After that, people will be aware and no more political manipulation**

People all see how cambridge analytica ends

**non-uniqueness**

It's just like other ads.

**no evidence**

they have no evidence showing "how many people are actually being under the manipulation".





## AT: misuse

1 laws regulation (et)

2 at: against minority

​	Not tech companies' use of pd： they are forced to hand it to govt



## AT: cybercrime

**Tech companies use pd to reduce cybercrime**

> https://www.wired.com/beyond-the-beyond/2018/01/google-fighting-cybercrime-big-data/

​	Google can make the speak of investigating cybercrime 10 times faster.



## AT: irl crime

**using personal data to do crime prevention**

> https://www.kaspersky.com/blog/big-data-forensics/8300/
>
> https://www.independent.co.uk/news/uk/home-news/police-big-data-technology-predict-crime-hotspot-mapping-rusi-report-research-minority-report-a7963706.html

​	Criminals have their own patterns, making it necessary for us to use personal data to detect crime. Tech companies using data to form crime detection AI and in LA, because of that, we saw a 33% drop in burglaries, 21% decrease in violent crime and 12% reduction in property  crime. According to Kaspersky, this data analytical systems can successfully cope wit predicting street crimes, street riots and acts of terrorism.

​	And this prediction accuracy is also high, according to RUSI's report said that it can predict by 88 percent accuracy, much higher than man can do.



## AT: privacy

**Impact small**

**Regulation**

**Save the world better by everyone giving out a little bit of his/her privacy**

​	Judge, do you want to see a better world, save billions of people and trillions of dollars? Do you want to see the world that poverty has been solved, refugees can live happier lives, and people are not worried about medical problem? We can reach that, and the cost is very simple: give out a bit of the personal data, and form the data that tech companies can analyse and offer you a better tomorrow. Compare to the whole global prosperity, what is the matter of a bit of personal data given out, with laws and technology protected? Humans want progress, and now, everyone giving a bit of personal data can make society progress, make a better tomorrow. 





## AT: targeted ads

**some targeted things good**

> Kim SJ, Marsch LA, Hancock JT, Das AK. Scaling Up Research on Drug Abuse and Addiction Through Social Media Big Data. J Med Internet Res 2017;19(10):e353. DOI: 10.2196/jmir.6426 https://www.jmir.org/2017/10/e353/
>
> https://americanaddictioncenters.org/rehab-guide/addiction-statistics?__cf_chl_jschl_tk__=d2adefaa9f9fd832bcfff2f476e07a34ad215c4f-1587223956-0-AWSO5do6anhZNAH363jGJpgxAUpbj9fxKc-8W6oGUkhMjWZ_LUl8YqlIP_w8sjbPbQ7GBMTFVvEXXKVxCkIrN4P3Vgj39xIkQR961hDpr6VjtJJGWeWKVIqU2eEksjoymWPg_ZTOmmZJZHN508gXY3_ETNAKQj5AOByPvpFlBYzow4XyTXq4BEWkqBzEa2lsjcyAiNny4f4FqhVmHR-dhsT2KbrmF5V3MlBlatFTM0g7Y-yP7hY3mx0HRSq-4xlV3VcrCkP2IsEmPYqDffRWiqnP7-_R7efYb57ZTnPvZtg0Dq7lNtOkZZwWzJEtSh6R8sSnon9bIFzSKAsgemDjo9fwKRtuab9wIDZOgjvOi3WSuUP0D3Mn3n8-3AeU9BiF4g

​	A personalized surveillance system, personal data showing how well it is going, collecting data to show what to do next in order to get away from addiction.

​	Only in America, 19 million adults are addicted to drugs, and this cost <font color =green>more than 700 billion dollars.</font> We can save them better, and save those more than 700 billion dollars.

​	

**consents, opt-out**

​	.GDPR



## AT: fake medicine

> https://www.theguardian.com/global-development/2019/jun/05/fake-medicine-makers-blockchain-artificial-intelligence

​	The Nigerian start-up RxAll, for instance, has created a handheld scanner that can assess the compound of a drug in real time.

​	It has been in use commercially in Myanmar and has been sold to a large Nigerian teaching hospital and to Nigeria’s [National Agency for Food & Drug Administration and Control](https://www.nafdac.gov.ng/), whose officials have started training to use it.

​	“Happily, from when we began to now, the prevalence of counterfeiting has dropped to less than 10% today,” Branttie says.

> https://www.ifpma.org/partners-2/1236/

​	Fight the Fake projects

## Corona Virus

Countries who track: South Korea, Iran, Israel, Austria, Belgium, Germany, Italy, China

##### Vox, Recode, Why having personal data fight virus ok

> Recode, https://www.vox.com/recode/2020/3/18/21184160/government-location-data-coronavirus

​	The United States government [wants tech companies to tell it where you’ve been](https://www.washingtonpost.com/technology/2020/03/17/white-house-location-data-coronavirus/) as part of its effort to fight [the Covid-19 coronavirus pandemic](https://www.vox.com/2020/1/31/21113178/what-is-coronavirus-symptoms-travel-china-map), according to the Washington Post.

​	“We are in the middle of a public health crisis,” Schwartz told Recode. “And some rebalancing of collective and individual interests may be appropriate.“

##### South Korean Eg 

> https://www.lawfareblog.com/lessons-america-how-south-korean-authorities-used-law-fight-coronavirus

​	This explains how the South Korean government has been able to rapidly “contact-trace” hundreds of thousands of its own citizens to curb the outbreak.

​	Fifty-four days since its first case, South Korea has officially turned the tide, [reporting](https://www.reuters.com/article/us-health-coronavirus-southkorea/south-korea-reports-more-recoveries-than-coronavirus-cases-for-the-first-time-idUSKBN210051) more recoveries per day than new infections.





## Emotion

​	For those people still in poverty, they got no food to eat, no money to use, and according to the UN, 1 in 5 children in poor area of South Sudan can't make it to their 5th birthday. We want to help them with compassion, let those children survive, let the refugees and poor people to survive. While our opponent, only thinking about their little benefit, REFUSE to help those poor people, ABANDON their chances to survive. 



## IMPACT (economy)

​	According to CIO, healthcare industry could save $500 billion by using data.

​	Using data to do sustainable farming and <font color = green>could produce commercial $2.3 trillion annually.</font>

​	A report from MGI estimates that it could generate an additional $3 trillion.

​	The economy impact clearly outweighs any of their contentions' impact.

## IMPACT (saving lives)

​	We can avoid death of thousands of people, let millions of refugees get their social status and jobs, save the 1 billion people who live in extreme poverty, 2 billion people who are lack of medicine, feed the whole world of 9 billion people w/o expanding the area of farmland.

​	Impact of lives of billions of people and feeding the whole world clearly outweighs any of their impact.



## Impact saying in Rebuttal

​	In our contention 2 we mentioned that the data agriculture brings an additional 2.3 trillion dollars. Added the additional 3 trillion dollars economy benefit according to MGI report estimation, (https://www.ced.org/blog/entry/big-datas-economic-impact), that trillions of dollars economy impact clearly outweighs any of their impact.

​	(https://www.usnews.com/news/best-states/articles/2017-03-16/internet-access-a-staple-of-american-life-yet-millions-remain-under-connected)

​	There are 1.2 billion people still in poverty, and according to us news, 91% of them can get access to the internet. That means, more than 1 billion people can be saved and get away from poverty. Thus, our impact of saving billions of lives clearly outweighs any of their impact.



## Impact (MS)

(We can fix the almost 80% of data beaches which are caused by password error)

Using data to do sustainable farming and could produce commercial $2.3 trillion annually.

A report from MGI estimates that it could generate an additional $3 trillion.

The economy impact clearly outweighs any of their contentions' impact.

Our resolution provide opportunity for the 1.5 million refugees, and predict poverty at a rated of 90%, thus saving 1 billion people from poverty, while also save 100 thousands people from human trafficking. 

The live saving impact clearly outweighs any of their contentions' impact.





## AT: Terrorist manipulation

**AT: Facebook**

> https://www.thedailybeast.com/report-terror-groups-are-still-posting-on-facebook

​	“There is no place for terrorists or content that promotes terrorism on Facebook, and we remove it as soon as we become aware of it,” the company told *Bloomberg* in a statement.

> https://www.thedailybeast.com/report-terror-groups-are-still-posting-on-facebook

​	Mark Zuclerberg he said algorithms would eventually be able to spot terrorism, violence, bullying and even prevent suicide.

> https://www.theguardian.com/technology/2019/sep/17/facebook-teams-up-with-police-to-stop-live-streaming-of-terror-attacks

​	Facebook is working with the [Metropolitan police](https://www.theguardian.com/uk/metropolitan-police) to improve the social network’s ability to detect live streaming of terrorism and potentially alert officers about an attack sooner.

> https://time.com/5739688/facebook-hate-speech-languages/

Facebook removed more than seven million instances of hate speech in the third quarter of 2019, the company claimed, an increase of 59% against the previous quarter. More and more of that hate speech (80%) is now being detected not by humans, they added, but automatically, by artificial intelligence.







------

# CON

## POOR No ACCESS

> https://www.usnews.com/news/best-states/articles/2017-03-16/internet-access-a-staple-of-american-life-yet-millions-remain-under-connected

Digital exclusion is a growing problem in the United States – about one-fifth of Americans don’t have internet access at home

Meanwhile in [Mississippi](https://www.usnews.com/news/best-states/mississippi), 34 percent of households are living without a broadband internet subscription

## <font color = orange>AT: All (synthetic data)</font>

### Privacy

> https://www.samasource.com/blog/2018/01/24/the-advantages-and-limitations-of-synthetic-data

​	<font color = green>Synthetic data can be created by stripping any personal information</font> from a real dataset <font color = green>so it is completely anonymized. Synthetic data is anonymous as all personal information has been removed and the data cannot be traced back.</font>

> https://blog.aimultiple.com/synthetic-data/#benefits

​	<font color = green>Synthetic data does not contain any original data. It can work by observing real statistic distributions and reproducing fake data which can do the same work.</font>

### AT: fraud detect

> https://link.springer.com/chapter/10.1007/3-540-36159-6_23

​	In many cases <font color = green>synthetic data is more suitable than authentic data for the testing and training of fraud detection systems. </font>

​	We <font color = green>identify the important characteristics of authentic data and the frauds we want to detect and generate synthetic data with these properties.</font>

> https://blog.aimultiple.com/synthetic-data/#benefits

​	<font color = green>Fraud protection is a major part of any financial service and with synthetic data</font>, new fraud detection methods can be tested and evaluated for their effectiveness.

### AT: healthcare

​	<font color = green>Synthetic data enables healthcare data professionals to allow the public use of record data while still maintaining patient confidentiality.</font>

### AT: AI

​	<font color = green>Machine learning algorithms are trained </font> with an incredible amount of data; <font color = green>which without synthetic data could be extremely difficult to obtain or generate.</font>

​	<font color = green>(Synthetic Data)</font>It can <font color = green>also play an important role in the creation of algorithms for image recognition and similar tasks that are becoming the baseline for AI. </font>

## AT: Education

> [1] Forbes, Jordan Shapiro, https://www.forbes.com/sites/jordanshapiro/2014/02/25/whats-so-bad-about-big-data-in-little-classrooms/#2f18ebfe4f04
>
> [2]  Herjavec Group, Steve Morgan, Editor-in-Chief Cybersecurity Ventures,https://www.herjavecgroup.com/wp-content/uploads/2018/12/CV-HG-2019-Official-Annual-Cybercrime-Report.pdf

**1 data misuse danger & lost trust**

​	Common Sense Media explains, “through online platforms, mobile applications, and cloud computing, schools and edtech providers collect massive amounts of sensitive information about students.” $^{[1]}$

​	data breach

​	lost trust

**2 students feel worried when there is too much technology in the classroom**

> Crocker, Sara G. and Joseph P. Mazer. "Associations among community college students’ technology apprehension and achievement emotions in developmental education courses." Technology, Pedagogy and Education, vol. 28, no. 1, 1 Jan. 2019, pp. 37-52, doi:10.1080/1475939X.2018.1562624.

​	Technology in learning environments can create feelings of apprehension in students who are not technologically savvy



## AT: health care

> [3] Statista, Matej Mikulic, https://www.statista.com/statistics/798564/number-of-us-residents-affected-by-data-breaches/#statisticContainer
>
> [3] Varonis, Rob Sobers, https://www.varonis.com/blog/data-breach-statistics/
>
> [4] FDA, https://www.fda.gov/consumers/health-fraud-scams
>
> [6] Barber, Gregory. 11.11.2019"Google Is Slurping Up Health Data—and It Looks Totally Legal," Wired, https://www.wired.com/story/google-is-slurping-up-health-dataand-it-looks-totally-legal/
>
> https://openmarketsinstitute.org/explainer/hospitals-and-monopolies/



**1 Lose trust between hospitals and patients & hacking**

​	<font color = green>This past June, Chicago Medical Centre failed to scrub timestamps from anonymized medical records. </font><font color = green>Those timestamps</font> <font color = green>could reveal the identities of individual patients</font>. $^{[6]}$ 

​	After knowing their data was leaked and data can be hacked, patients could lose trust in the data usage of that hospital, and lose trust of patients & hospitals.  We can never realize better treatment w/o even getting trust between hospital and patients

**2 health fraud**

​	<font color = green>More than 100 million people were affected by health data breaches in 2015, and there was an 80% increase in the number.$^{[3]}$</font> The data which goes into scammers' hands lead to health fraud scams.

​	According to [FDA](https://www.fda.gov/consumers/health-fraud-scams), health fraud scams waste money and can lead to delays in getting proper diagnosis and treatment. That means the data breach get people away from proper diagnosis and treatment.

**3 health monopoly which leads to higher price**

​	As hospitals and tech companies collect too much data and monopoly the research of medical field, this will cause health monopoly.

​	The monopoly of hospitals causes high price. A recent and widely discussed [study](https://healthcarepricingproject.org/papers/paper-1) by Yale economist Zack Cooper has found that if you stay in a monopoly hospital, your bill will be $1,900 higher on average. That's unaffordable for the poor people.

**4 less efficient**

>Ehrintelligence. "61% of Physicians Say EHR Systems Reduce Clinical Efficiency." EHRIntelligence, 2 Oct. 2018, ehrintelligence.com/news/61-of-physicians-say-ehr-systems-reduce-clinical-efficiency.

​	86 percent of doctors reported a negative experience with EHR.

​	Overall, the majority of surveyed physicians reported that EHR systems have had a negative impact on the patient-provider relationship, clinical workflows, and clinical productivity.

**5 EHR Error**

> https://khn.org/news/death-by-a-thousand-clicks/

​	The EHR would sometimes display one patient’s medication profile accompanied by the physician’s note for a different patient, making it easy to misdiagnose or prescribe a drug to the wrong individual. 

> https://www.pewtrusts.org/en/research-and-analysis/issue-briefs/2019/04/poor-usability-of-electronic-health-records-can-lead-to-drug-errors-jeopardizing-pediatric-patients

 EHRs may display information in confusing ways, or data may be hard to find or missing.

Entering data in an EHR can be challenging, which may cause delays for orders and lead to clinicians using workaround solutions.

**6 Failure & Error**

> https://www.ehrinpractice.com/ehr-failure-statistics.html

​	 More than 50% EHR systems either fail or fail to be properly utilized. Research published in the journal Procedia Computer Science, shows health care technology projects fail at a rate of up to 70% of the time.

​	Medication-ordering functionality of hospital EHRs failed to flag potentially harmful drug orders in 39 percent of cases in a test simulation.

> https://khn.org/news/death-by-a-thousand-clicks/

​	21% of patients faced EHR errors.

## AT: epidemic

**1 no evidence about how many people will be saved using personal location**

**2 still work this out w/o getting location data** 

> blog.gds-gov.tech/automated-contact-tracing-is-not-a-coronavirus-panacea-57fb3ce61d98

​	Manual Tracing is better -- with no need for tech companies to get in.

**3 it's not a best way**

> https://www.kooslooijesteijn.net/blog/mass-surveillance-will-not-stop-corona

​	Mass surveillance would be impractical and ineffective to fight the pandemic.

1 inaccuracy 2 takes too long time

> www.forbes.com/sites/zakdoffman/2020/04/12/forget-apple-and-google-heres-the-real-challenge-for-covid-19-contact-tracing/#4ea517ec2709.

​	If the users using this is below 60% the it “would endanger the quality of the data and its core functionality, ..., providing more false security than actual support fighting the virus..

**4 it's an extremely rare event** using data this time does not mean using data forever is ok

**5 later will be worse**

> https://www.kooslooijesteijn.net/blog/mass-surveillance-will-not-stop-corona

Technology doesn't care about intentions -- this is a mass surveillance and will bring harm

And Mass surveillance systems are sensitive to corruption. (fake news)

> https://www.forbes.com/sites/daniellecitron/2014/12/24/beware-the-dangers-of-location-data/#1caf1b2643cb

​	Geolocation data tells us intimate, revealing details about people's lives. As AG Harris [told](http://www.usatoday.com/story/news/nation/2014/12/22/california-attorney-general-smartphone-wawrning/20778295/) USA Today, "Broadcasting your location can sometimes expose you and your family to risk of theft or physical harm. … A 'selfie' with location data can be dangerous, especially for victims of stalking or domestic abuse.'







## AT: Lower Price

> [7] Gonzalez-Miranda, Maria. 5-29-201 https://www.marketwatch.com/story/how-big-data-and-online-markets-can-lead-to-higher-prices-2018-05-19

**Price will higher, Target Pricing**

​	Online retailers use consumers’ internet activities and other personal data to deliver “targeted pricing.” 
​	Indeed, if you search online for a more expensive car or a more expensive vacation, that fact will be documented by tracking cookies or other means of online surveillance. And with these data, digital advertisers and retailers will offer you more expensive watches, home furnishings, or airline tickets than they would to a lower-income user searching within the same categories. $^{[7]}$



## AT: Personalization

**Analyse**

magnitude: small, smaller than our contention

**Political Manipulate,Price**

> [8] The New Republic,https://newrepublic.com/article/151548/political-campaigns-big-data-manipulate-elections-weaken-democracy

​	Technology such as Cambridge Analytica, **"personalize" your news and manipulate you politically**. According to The New Republic, It attempted to use psychological and other personal information to **engage in a kind of voluntary disenfranchisement**. 

​	

**People don't want it**

> [Greg Sterling](https://martechtoday.com/author/greg-sterling) on August 14, 2019 "Personalization offer doesn’t lead to more personal data sharing [Survey]" martech https://martechtoday.com/personalization-offer-doesnt-lead-to-more-personal-data-sharing-survey-234859 

​	  Compared with 2018, people demonstrated somewhat **more resistance to sharing personal data**. According to ARF, “The biggest changes in respondents’ willingness to share their data from 2018 to 2019 were seen **in their home address (-10 percentage points), spouse’s first and last name (-8 percentage points), personal email address (-7 percentage points), and first and last names (-6 percentage points)**.”

> https://www.forbes.com/sites/roberthof/2012/03/09/people-dont-want-personalized-ads-what-should-marketers-do/#2d3587722079

​	According to the survey of about 2,000 American adults early this year, <font color = green>65% of people who were asked how they'd feel if a search engine used the information to personalized future results said it's a bad thing because it limits information they get.</font>

> https://blog.convert.com/personalization-too-much.html

<font color = green> A whopping 78 percent of U.S. citizens think that a brand should not use their personal data to market to them.</font>



## AT: Data Security

**Analyse**

Magnitude: but putting them in tech companies are safer

**Data Breach and Misuse (c2)**

> [9] Varonis, Rob Sobers,  https://www.varonis.com/blog/data-breach-statistics/

​	The United States saw 1,244 data breaches in 2018 and had 446.5 million exposed records (Statista).

​	Yahoo holds the record for the largest data breach of all time with 3 billion compromised accounts (Statista).

​	The average time to identify a breach in 2019 was 206 days (IBM).

​	And the average cost of a data breach in the U.S. is $7.91 million, according to the 2018 Cost of data breach study.



​	

## AT: IoT

> [10] Tech Radar, Aaron McIntosh, https://www.techradar.com/news/the-dangers-of-iot-and-ai

**IoT Data Breach & hacking**

​	IoT track people's behaviour and record them. The recorded data is communicated to a [server](https://www.techradar.com/news/best-small-business-servers), but if this communication link is not secure then it becomes an easy route for hackers to get into your home. Similarly, if the data stored within the server or database is not encrypted, it is at risk of a breach. Access to your data and all of your other connected devices gives a hacker a way into your home that can cause serious security issues. $^{[10]}$

​	The overall volume of IoT attacks remained high in 2018 and routers and connected cameras were the most infected devices and accounted for 75% and 15% of the attacks respectively ([Symantec](https://www.symantec.com/security-center/threat-report)). $^{[9]}$

**Impact**

​	IoT controlled by hacker, especially routers and connected cameras, could be dangerous. For example, those things could fail to work , leading to a malfunction of the whole system, and might cause danger to the house and the living, such as making the room extremely hot or cold.  It makes no convenience but only mess and danger.



## AT: Crime Prevention

**Criminal and hackers use big data to escape**

> Datanami, October 12, 2016 https://www.datanami.com/2016/10/12/criminals-are-using-big-data-tech-and-so-should-you/

​    “The sophistication, agility, and speed at which a cybercriminal operates and monetizes their fraudulent information have improved through the use of data analytics,” Kate McGavin, a senior product marketing manager at RSA, wrote.

**Hate speech and terrorists' manipulation**

>https://time.com/5739688/facebook-hate-speech-languages/

​	It has become easier for Facebook to contain the spread of racial or religious hatred online in the primarily developed countries and communities where global languages like English, Spanish and Mandarin dominate.





## AT: AI

> [11] Harvard Law review, [Neil M. Richards](https://harvardlawreview.org/authors/neil-m-richards/), https://harvardlawreview.org/2013/05/the-dangers-of-surveillance/
>
> [12] CJFE, Nathan Munn, https://www.cjfe.org/how_mass_surveillance_harms_societies_and_individuals_and_what_you_can_do_about_it

**Data AI against privacy **

​	It is not clear how much technology is being focused on securing these devices to protect the people that are using them and their data. And the provider can get all the conversation between you and AI, or get all the personal data about what you let AI do. That is a violation of privacy, which is what we don't want to see.

**Surveillance bad**

​	Surveillance menaces intellectual privacy and increases the risk of blackmail, coercion, and discrimination. $^{[11]}$

​	Evidence shows that mass surveillance erodes intellectual freedom and damages the social fabric of affected societies; it also opens the door to flawed and illegal profiling of individuals.  $^{[12]}$

​	Evidence shows that even the possibility of being under surveillance changes the way people think and act...prevent discussions that are necessary for the functioning of a free society. ... Makes the development of mutual mistrust between the individual and the state. $^{[12]}$



## AT: poor

> https://www.theatlantic.com/technology/archive/2016/04/how-big-data-harms-poor-communities/477423/

​	Low-income communities are among the most surveilled communities in America. **Public-benefits programs, child-welfare systems, and monitoring programs for domestic-abuse offenders all gather large amounts of data on their users, who are disproportionately poor.**

​	Data gathered from those sources can end up feeding back into police systems, leading to **a cycle of surveillance**. 

>UN, poor discrimination https://www.un.org/en/letsfightracism/poor.shtml

​	<font color = green>Many people who live in poverty are often also victims of discrimination</font>. <font color = green>Poverty is both a cause and a product of human rights violations.</font> 

>MICHELE GILMAN, UNIVERSITY OF BALTIMORE / APRIL 30, 2019 ”Data Insecurity Leads to Economic Injustice – and Hits the Pocketbooks of the Poor Most“ Govtech.com https://www.govtech.com/security/Data-Insecurity-Leads-to-Economic-Injustice--and-Hits-the-Pocketbooks-of-the-Poor-Most.html 

​    **The poor are classified, in all those algorithms such as job employment, schools, as unqualified.**

​    A lack of transparency means that **people never learn why they are denied a job, a home or an education**. **Mechanisms to correct faulty data either do not exist or are so Kafkaesque that people give up in frustration**.

​	That means the poor will get discriminated by those data analysing algorithm.

**connected $\not=$  have data $\not=$ give data**



## AT Agriculture

<font color = green>Key areas of **concerns for farmers** that discourage the sharing of data including **clarity and transparency** of data terms and conditions;</font> questions of **ownership and the sharing of data**; **privacy** concerns; **inequality of bargaining** power; and a **lack of benefit sharing**. 

**Crop repetition--bad for sustainable agriculture**

> A very small number of crops are dominating globally: That's bad news for sustainable agriculture University of Toronto, Feburary 6, 2019 https://www.sciencedaily.com/releases/2019/02/190206161446.htm

​    <font color = green>We're **growing more of the same kinds of crops**, and this presentzs **major challenges for agricultural sustainability** on a global scale.</font> **Large industrial-sized farms in Asia, Europe, North and South America are beginning to look the same**. 

​	(**Soybeans, wheat, rice and corn are prime examples**. These four crops alone occupy **just shy of 50 per cent of the world's entire agricultural lands**, while the **remaining 152 crops cover the rest**.)

so, spending more time in growing same crop does harm..



**Crop Data Not Personal data**

**Agriculture Company Not Technology Company**

​	Technology Company 's primary jobs is technology, not agriculture. And they use the technology as the high tech of internet, while it has nothing to do with personal data.



## AT: price reduction

**overconsumption -> rise of demand -> higher price**

> https://medium.com/@varsha.ravindranath/advertising-over-consumption-584fbf721115
>
> https://www.thebalance.com/causes-of-inflation-3-real-reasons-for-rising-prices-3306094

​	According to Varsha Adibhatla, MA Sociology, the sale of Lucky Strikes went from 14 billion to 40 billion because of targeted advertising. And that leads to overconsumption. The overconsumption of products leads to the rise of demands.

​	According to The Balance, The rise of demands leads to the higher price because of the lack of materials. That's because in order not to sale out, companies must increase price that less people will buy. So, this targeted ads actually increase the price because of the supply and demand theory.



## AT: smart grid

​	While modernization of electrical grids into smart grids allows for optimization of everyday processes, a smart grid, being online, can be vulnerable to cyberattacks.[[87](https://en.wikipedia.org/wiki/Smart_grid#cite_note-:0-87)]

​	Hackers have the potential to disrupt these automated control systems, severing the channels which allow generated electricity to be utilized.[[89\]](https://en.wikipedia.org/wiki/Smart_grid#cite_note-:12-89)

​	Insurance company Lloyd's of London has already modeled the outcome of a cyberattack on the one smart grid, which has the potential to impact 15 states, put 93 million people in the dark, and cost the country's economy to $1 trillion.[[98\]](https://en.wikipedia.org/wiki/Smart_grid#cite_note-98)



## AT: interesting points

 1 no link to tech company

2 no evidence showing impact

3 impact small



## Hatred&Extreme

> https://www.theguardian.com/technology/2019/feb/07/facebook-myanmar-genocide-violence-hate-speech

​	1 hate speech keep raising, 7 million

​	2 can't detect different languages



## IMPACT



6 trillion (trillions of) dollars loss because of data breaches and cybercrime

60% of SMBs closed down

100 thousand local stores

700 thousand refugees for only one case

1.4 million hate speeches remained









# ```include<bits/stdc++.h>```

magnitude (how big)

possibility

time frame