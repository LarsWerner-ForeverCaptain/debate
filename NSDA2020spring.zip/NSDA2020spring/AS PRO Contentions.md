## April Sun

# Technology companies’ use of personal data is more beneficial than harmful.

# (PRO)

## CONTENTION ONE: Education

Student data is very useful in the educational field. Due to its benefits, an increasing number of law makers are making student data legal. <font color = \#0000FF> 24 states in the US passed 38 new laws on secure data linkages to see how different students move through the education pipeline, according to the data quality campaign.[3] </font>Educational technology companies sell their database and platform to schools, which make great use of this privilege. <font color = \#0000FF>According to the student research foundation, the most effective educators use student data to personalize instruction, ensuring that the lessons in the classroom best match with student needs and learning styles.[4] </font>Personal data is at the heart of all of these activities. Data improves performances of both educators and students. <font color = \#0000FF>According to ASCD, providing teachers with graphic displays of students' scores on formative assessments was associated with a 26 percent gain in achievement. And on average, the practice of having students track their own progress with data promoted their achievement by 32 percent.[5]</font>

Data has the potential to transform education into a personalized experience that meets the needs of individuals and ensures that no student is lost along the way. This improves student progress and teacher performance, which leads to more qualified and excellent graduates. With more outstanding candidates, companies can have more top-notch employees and potential leaders, which makes the country more productive and innovative, thanks to personal data. (1:24) 

 

## CONTENTION TWO: Client Satisfaction (customer experience)

It is extremely difficult to sell goods and services without knowing your target audience. Rather than the so-called invasion of privacy, marketers in all domains actively use data collection to better understand their customer requirements and improve sales. <font color = \#0000FF>Data-driven organizations are 23 times more likely to acquire customers, 6 times as likely to retain customers, and 19 times as likely to be profitable as a result, according to Micro Strategy.[6] </font> Collecting data proved to be very effective. <font color = \#0000FF>The Temkin Group found that companies that earn $1 billion annually can expect to earn, on average, an additional$700 million within 3 years of investing in customer experience. For Software-As-a-Service companies* in particular, they can expect to increase revenue by $1 billion. [7]</font> <font color = \#0000FF>There are 11,288 SaaS companies in the world. [8]</font>

As a result, marketers can gain valuable insights and trends, build audience profiles, organize effective marketing campaigns, provide personalized information etc. Also, the customers would be satisfied and are able to enjoy the conveniences personal data brings. Companies are ensuring consumers have a great experience from the first point of contact. And they are trying to build a long-term relationship with their customers to get solid word recommendations, which benefits both the customers and themselves. Business profits also allow companies to improve the livelihood of their owners, managers and employees.  (1:25)

 

## CONTENTION THREE: Healthcare

<font color = \#0000FF>A personal electronic health record (EHR) is a system that collects information about the patient’s health from a number of sources, which helps to provide adequate treatment and reduce errors. The errors used to contribute to approximately 250,000 deaths annually according to CureMD. [9]</font> Big data also improves accuracy and selectivity in clinical trials and provides actionable insights in hospital settings\*. Plus, all those services are financially-friendly to both hospitals and individuals. <font color = \#0000FF>According to a survey released at ONC\*, nearly all of US hospitals are using certified EHRs.[11]  </font>And <font color=blue>each hospital is expected to save \$850,000 in overtime costs according to Evariant. [12]</font> As for individuals, they won't need to spend so much time in hospitals waiting for medical care and occupying sources, which will save them a lot of money. <font color = \#0000FF>research conducted by McKinsey & Company showed that big data could save Americans between ​\$300 billion to​ $450 billion per year on health-care spending.[13]</font>

Most people can enjoy the conveniences EHR brings, as <font color = \#0000FF>EHR adoption rates are higher than ever at around 87 percent, according to physician express.[14] </font>By using a scope of data from digital medical records, doctors can establish a link between fundamentally different symptoms, give an accurate diagnosis to all these people using EHR. Both hospitals and patients can also save a lot of money, which can help produce more medicine to potentially save <font color = \#0000FF>2 billion people suffering from lack of medicine [15]</font>, and increase financial freedom of individuals. 

 

##  CONTENTION FOUR: Artificial Intelligence

Data is the lifeblood of AI. The number of AI applications is growing, as is the need for data and the types of data required. The perfect combination of data analytics and AI can provide us with the following benefits:

### Sub-A Finance (business)

The internet now provides a level of concrete information about consumer habits, likes and dislikes, activities, and personal preferences. <font color=blue> As Umbel puts it, using data from multiple sources, AI can build a store of knowledge that will ultimately enable accurate predictions about you as a consumer that are based not just on what you buy, but on how much time you spend in a particular site or store– and a host of other data that AI can synthesize and add to, ultimately getting to know what you want very well.[16]</font> This helps companies to earn more profit. <font color = \#0000FF>75% of organizations have increased their sales of new products, service offerings and improved customer satisfaction by more than 10% using implemented AI, according to Capgemini Digital Transformation Institute.[17] </font> 

### Sub-B Crime avoidance (crime prevention)

<font color=blue>A new report has put a number on it: Worldwide cybercrime costs an estimated $600 billion USD a year.[18]</font> The combined technology of data and AI can solve this problem. <font color=blue> Senior Quantitative Analyst at Mercury Processing Services International. Quote and quote: "We use AI to analyze normal behaviors of most people, and then use the method to recognize unusual behavioral patterns. "[19]</font> This proved to be sufficient, as <font color=blue>72.7% of firms are currently using AI for payment fraud detection.[20]</font> <font color=blue>Similar security solutions are used in police departments of Seattle, New York, and Los Angeles. The last one has already reported significant performance improvement that included a 33% drop in burglaries, a 21% decrease in violent crime, and a 12% reduction in property crime.[21]</font> This is achieved because of companies' use of personal data.

By improving sales rates of firms, AI contributes to the world economy and the market flow. By analyzing criminal behavior, AI detects crime and prevent them efficiently, saving all those people losing huge amounts of money or even their lives due to savere crime, and lead to a peaceful society.(2:05)

 

## CONTENTION FIVE: Poverty alleviation (poverty reduction)

<font color=blue>Approximately 1.2 billion people in the world live in extreme poverty, which means they earn less than one dollar per day according to the WHO.[22] </font> These people are suffering from lack of food, water, medicine etc. Personal data can save those innocents:

### Sub-A Sustainable Agriculture

<font color=blue>The United Nations estimates that about 10% of the world population are suffering from hunger.[23]</font> However, using sustainable agriculture with data analytics, <font color=blue>farmers collect crop data and sell it to companies. Other farmers use those data provided by tech companies to apply the correct rate of fertilizer and pesticide; manage drainage;  and use right management practices. Advanced systems that deliver decision support tools are also developed.[24]</font> This technology is realizing its tremendous benefits, as <font color=blue>sustainable agricultural practices can deliver an annual $2.3 trillion windfall, as a new study shows.[25]</font> 

### Sub-B Altruistic support (humanitarian aid)

We can only help the poor if we know who they are. But <font color=blue>14 African countries carried out no national poverty surveys at all, the World Bank says.[26]</font> That's where data collection helps predict poverty. <font color=blue>NBC News reports researchers fed an algorithm satellite images and household data in countries, then instructed it to predict poverty distribution. The algorithm could predict poverty 81 percent to 99 percent more accurately than previous models. [27]</font>. Personal data is also giving refugees identity.  <font color=blue>By the end of 2018, more than 7.1 million people were biometrically enrolled in 60 Country Operations over the world, meaning that 8 in every 10 refugees registered by UNHCR now has a biometric identity.[28]</font> 

By applying data analytics, everybody get benefits. Farmers sell their data and earn profit;other farmers  enforce sustainable agriculture, which leads to less crop failure. The Guardian reports that <font color=blue>sustainable and organic farming can feed a world population of 9.6 billion people by 2050 without expanding the area of farmland, if people eat a more plant-based diet.[29] </font> As for aiding the poor, satellite images have already proved efficient, and with identity, refugees are granted fundamental rights like residing in a country and finding a stable job. They can ultimately blend in to the society. 





## Annotations:

\* A SaaS company is a company that hosts an application and makes it available to customers over the internet. SaaS stands for Software as a Service. This infers that the software sits on a SaaS company's server while the user accesses it remotely.

 

\* i.e., discharge planning, disease management, quality assurance, performance reporting, etc.

 

\* ONC: the Office of the National Coordinator for Health Information Technology 

 

## References:

[3] https://dataqualitycampaign.org/resource/2018-education-data-legislation/ ***\*student research foundation\****, using Student Data to Benefit Students ***\*December 15, 2017\****

[4] https://www.studentresearchfoundation.org/blog/using-student-data-to-benefit-students/

[5] http://www.ascd.org/publications/educational-leadership/dec09/vol67/num04/When-Students-Track-Their-Progress.aspx ***\*Association for Supervision and Curriculum Development\****, When students track their progress, ***\*January 2010\****

[6] https://www.microstrategy.com/us/resources/blog/bi-trends/16-statistics-showing-data-s-influence-on-customer-experience ***\*MicroStrategy\**** 16 statistics showing data’s influence on customer experience ***\*April 25, 2018\**** 

[7] https://www.superoffice.com/blog/customer-experience-statistics/

***\*S\*******\*uperoffice\**** 37 customer experience statistics you need to know in 2020 ***\*26 February, 2020\****

[8] https://cardconnect.com/launchpointe/tech-trends/rise-of-saas ***\*Cardconnect\**** The rise of software as a service (saas)

[9] https://www.curemd.com/ehr-reduce-medical-errors.asp ***\*CureMD\**** How Do EHR Systems Reduce Medical Errors? 

[10] https://www.adsc.com/blog/bid/185628/How-Electronic-Health-Record-Alerts-Benefit-Physicians-Patients ***\*Advanced Data Systems Corporation\**** How Electronic Health Record Alerts Benefit Physicians & Patients ***\*July 10\*******\*th\**** ***\*2012\****

[11]https://www.selecthub.com/medical-software/emr/electronic-medical-records-future-emr-trends/ ***\*Select Hub\**** Future of Electronic Medical Records: Experts Predict EMR Trends in 2020 

[12] https://www.evariant.com/blog/big-data-creates-big-improvements-in-healthcare ***\*evariant\**** Infographic: big data creates improvements in healthcare ***\*October 12, 2015\****

[13] https://www.mckinsey.com/industries/healthcare-systems-and-services/our-insights/the-big-data-revolution-in-us-health-care ***\*McKinsey & Company\**** The big data revolution in US healthcare : Accelerating value and innovation ***\*April 2013\****

[14] https://physicianxpress.com/15-latest-statistics-ehr-prove-importance/ ***\*Physician Press\**** 15 latest statistics on HER to prove its importance ***\*Dec 15 2017\****

[15] https://www.who.int/publications/10-year-review/medicines/en/ ***\*WHO\****Access to medicines: making market forces serve the poor 

 [16] https://online.maryville.edu/blog/big-data-is-too-big-without-ai/ ***\*maryvile.edu*\*** Big data is too big without AI

[17] https://enterprisersproject.com/article/2019/10/how-big-data-and-ai-work-together ***\*The Enterprisers project*\*** 

[18] https://www.internetsociety.org/blog/2018/02/the-cost-of-cybercrime/ ***\*Internet Society*\*** The cost of cyber crime ***\*23 Feburary 2018*\*** 

[19] https://inpaymentsmag.com/en/june-2017/feature-theme/using-ai-and-big-data-in-fraud-prevention ***\*In-Payments*\*** Using AI and big data in fraud prevention: feeding big data to help prevent cybercrime 

[20] https://www.forbes.com/sites/louiscolumbus/2019/09/05/how-ai-is-protecting-against-payments-fraud/#55afa7a34d29 ***\*Forbes*\*** How AI is protecting against payments fraud ***\*Sep 5, 2019*\*** 

[21] https://www.kaspersky.com/blog/big-data-forensics/8300/ ***\*Kaspersky lab*\*** How big data helps to catch criminals

[22] https://www.who.int/hdp/poverty/en/ ***\*WHO*\*** Poverty and health 

[23] https://www.worldhunger.org/world-hunger-and-poverty-facts-and-statistics/ ***\*Hunger Notes*\*** 2018 World hunger and poverty facts and statistics 

[24] https://www.frontiersin.org/articles/10.3389/fsufs.2019.00054/full ***\*frontiers*\*** Big Data Analysis for Sustainable Agriculture on a Geospatial Cloud Framework ***\*16 July 2019*\***

[25] https://www.greenbiz.com/article/sustainable-agriculture-can-unlock-23-trillion-report-says ***\*Greenbiz*\*** Sustainable agriculture can unlock 2.3 trillion, report says ***\*October 17, 2016*\***

[26] https://www.washingtonpost.com/news/wonk/wp/2016/08/24/how-satellite-images-are-helping-find-the-worlds-hidden-poor/ ***\*Washington Post*\*** How satellite images are helping find the world’s hidden poor ***\*August 24 2016*\***

[27] https://www.nbcnews.com/mach/tech/ai-game-changer-fight-against-hunger-poverty-here-s-why-ncna774696 ***\*NBC News*\*** AI: a game-changer in the fight against hunger and poverty. Here's why. ***\*June 22, 2017*\***

[28] https://www.unhcr.org/blogs/data-millions-refugees-securely-hosted-primes/ ***\*UNHCR*\*** Data of millions of refugees now securely hosted in PRIMES (Population Registration and Identity Management EcoSystem) ***\*Jan 28, 2019*\***

[29] https://www.theguardian.com/sustainable-business/2016/aug/14/organic-farming-agriculture-world-hunger ***\*the Guardian*\*** Can we feed 10 billion people on organic farming alone? ***\*14 Aug 2016*\***

 

 