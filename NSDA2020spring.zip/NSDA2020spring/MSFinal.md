# CON

> ### cybercrime , databreach
>
> > 1 solve cybercrime (Russian example)
> >
> > 2 help consumers from cybercrime (Google)
> >
> > 3 prevent (inc security)
> >
> > > scams impact big
> > >
> > > tech can't stop
> > >
> > > why is 5 trillion loss
> > >
> > > > all kinds of breaches not pd
> > > >
> > > > personal data
> > > >
> > > > only hackers use not tech;s use
>
> 2 data breach
>
> > 1 prevent small companies from data breach (Google)
> >
> > > impact big
>
> ### 2 barrier to entry (monopoly)
>
> > 1 not monopoly (has competitors)
> >
> > 2 not harm (innovation, they spent 60 billion on innovation)
> >
> > 3 option to step away (Google win Yahoo)
> >
> > > small business still
> > >
> > > > monopoly good for consumers
> > > >
> > > > innovation
> > > >
> > > > consumers choose
> > > >
> > > > big only have market share
> > > >
> > > > not hurting, only innovation (small companies more innovation)
> > > >
> > > > > monopoly have impact
> > > > >
> > > > > >  consumer benefitf



# PRO

fw: only status quo

> not tech's ads
>
> can't persuade
>
> big data $\not=$ pd
>
> > tech better choices for ads
> >
> > target potential buyers
> >
> > GDPR, big data also pd
> >
> > > don't make buyers, only make them buy earlier
> > >
> > > not tech

2 protection

>> save lives
>>
>> lower crime rate











# CF

1 hospital pd better or tech pd better

> cooperate

---

1 targeted ads are benefiting, saving time (71%)

> Some ads are not tech company (schools use)

2 are there comp competing?

3 how tar ads persuade? (buy apples they don't want)

> 71% potential buyers
>
> different kinds of targeting

4 no impact of cybercrime

---

1 google protect

> police contact social media
>
> > google?
> >
> > > 70% contact
> > >
> > > > data about drop
> > > >
> > > > > 20% drop
> > > > >
> > > > > > not only google
> > > > > >
> > > > > > > facebook. twitter
> > > > > > >
> > > > > > > > pd $\not=$ data

2 save life is the most important thing

> fw also save

3 data breach trillions of dollars

> not pd, data $\not=$ data



$2\sqrt{2}$



ff con

