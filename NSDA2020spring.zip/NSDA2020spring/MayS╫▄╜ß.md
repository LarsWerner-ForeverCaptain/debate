# TJ Heping MT PRO

## Rebuttal

## FW

harmful, CBA

## C1 security problem

sell data & breaches

privacy

> 3 impact small
>
> economy benefit of trillions of dollars
>
> save people's lives (poor people's lives, victims of human trafficking's lives, refugees lives)
>
> privacy impact: happiness: you are giving our your data to the tech companies every day, and enjoy the services (online shopping, map services ... ) -> happiness
>
> and also, food important, lives most important...

> 1 improve data security from hackers
>
> ​	According to the 10th edition of the Verizon Data Breach Investigations Report, 81 percent of hacking-related breaches leveraged stolen and/or weak passwords.
>
> Accordng to fobes, louis columbus
>
> ​	Biometrics are proving to be better than passwords because they’re easier to use, provide greater privacy and security
>
> ​	And that disrupts a hacker’s attack vector,” he says, “as they can no longer focus on huge server stockpiles of user credentials." And make it much safer.

> 2 Regulation
>
> GDPR
>
> GDPR requires a positive opt-in and opt-out, it also requires that individuals can withdraw their data at any time to protect their privacy.
>
> fine Google for that -> effective & stop tech companies from selling

## C2 surveillance of govt

FBI

> 1 gov use not technology companies' use
>
> 2 FBI usage of data is good (crime detection)
>
> ​	We saw a 33% drop in burglaries, 21% decrease in violent crime and 12% reduction in property  crime. According to Kaspersky, this data analytical systems can successfully cope wit predicting street crimes, street riots and acts of terrorism.
>
> ​	And this prediction accuracy is also high, according to RUSI's report said that it can predict by 88 percent accuracy, much higher than man can do.



environment problem: building better agriculture w/o expanding farmland -> better for environment

they mentioned that humanatirian is not importantd: but...

## Clashes

no evidence

### Privacy & Humanitarian

1 improve safety

2 regulations (GDPR) -> prevent

3 government 

4 impact small: we save trillions of dollars, and millions of people

### Productivity & Environment

1 better agi -> save people from hunger

2 inc food w/o hurting more environment by expending farmland

3 usage : more than 85% use it (mentioned in constructive)

### Epidemic

1 neccesary  ->  China, Korean, SIngapore (successful examples)

because of pd

reduce people's dying





# TJ Shuangling MW PRO

# Rebuttal

## FW

pd: related

tc: business, develop, serv

fw: social injustice

big data & AI

1 pd: RELATED to individuals, big data needs people's data and is consists of them

2 AI: need pd to work better

## Contention 1 data leakage | data selling

1 at data leakage

> their are still be



2 data selling impact (vs extremesim)  



3 GDPR



4 impact 

## Contention 2 political manipulation

1 they have no evidence showing "how many people are actually being under the manipulation".

2 non-uniqueness

3 





AI jobs: 

the AI they describes are AI used in factories and build things, NOTHING TO DO WITH OUR CONTENTION 1 (misrebuttal)

contention 2 is not healthcare -- it's agriculture (misrebuttal)



### Data security

1 blockchain: 50 + companies, no hack

2 GDPR (regulations)

3 less hacks (password & biometrics)

### Manipulation

1 extra vote: no inner link as more people vote doesn't equally means that they are manipulated -- they are thinking all people using facebook that vote for the other sides are being manipulated

2 the only manipulation company Cambridge analytica went bankrupted.  No other manipulation companies now. 

### Epidemic

1 personal data: need location data & health data of single individuals, and must be identified or you don't know whether you have virus or not

2 many successful examples

### Agriculture

no rebuttal

1 supply chain & smart farming

2 2.3 trillion dollars & billions of people in hunger

### Humanitarianism Aid

1 no rebuttal

2   1.5 million refugees' jobs, predict poverty 90% rate (people in poverty), save 100,000 victims of human trafficking

impact:

2.3 trllions of dollars

lives



# YKPAO GD PRO

# Rebuttal

## FW 

1 tech: rely on tech

fw: morality

## C1 data ...

## SA data breach

**1 Blockchain**

> **Lotte Schou-Zibell**,Regional Director, Pacific Liaison and Coordination Office (PLCO), **Nigel Phair**,Director, UNSW Canberra Cyber, https://blogs.adb.org/blog/how-secure-blockchain
>
> block9solutions, May29 2018, https://medium.com/coinmonks/guarantee-your-patients-privacy-today-securing-sensitive-data-with-blockchain-fcb179f1302c
>
> https://101blockchains.com/companies-using-blockchain-technology/

<font color = green>	Blockchain can achieve simultaneous security and privacy in an information system by enabling confidentiality through “public key infrastructure” </font>

<font color = green>If the hacker isn’t using the right files on the right computer, it is impossible for him to get to the point where it is even possible to crack the password.</font>

​	Blockchain can protect data in a safe way that no hacker has even hacked. <font color = green>And according to 101blockchains, there are 50 companies using blockchain now and the number is on the rise.</font>

2 the financial loss does not crom from just personal data breach -- many kinds of data beach

**more secure**

## SB false & bad data

1 the bad data & false data does not come from personal data -> if they don't use personal data and only collect such kinds of data, this will still cause bad data & false data

2 the personal data must relate to the identifiable person -- the fake and false data don't meet that need -> invalid



## C2 discrimination

## SA machine bias

compare to human's judgement

machine bias can be much more easily found

1 Machines are less biased than human.

2 Algorithms' bias can be better fixed, while human's can't

> https://www.verdict.co.uk/ai-and-bias/

​	Data scientists and statisticians assess a system’s underlying data and judge its representativeness . Once biases are identified, adjustments can be made, typically without the emotional resistance that comes from directly confronting human prejudices. This means that machines biases will tend to decrease over time.

>https://www.nytimes.com/2019/12/06/business/algorithm-bias-fix.html

​	Changing people’s hearts and minds is no simple matter. In contrast, Discrimination by algorithm can be more readily discovered and more easily fixed. With proper regulation,  algorithms can become a potentially powerful force for good: they can dramatically reduce discrimination of multiple kinds. ([here](https://academic.oup.com/jla/article/doi/10.1093/jla/laz001/5476086))

## SB targeted ads (jobs)

1 people don't only find jobs / somewhere to live by ads -- targeted ads does not directly lead to the unemployment of some people 

-> impact

2 no evidence show that how many people can't find jobs BECAUSE of that targeted ads





## FF

### FW

morality:

the greatest morality is live saving -- and we protect the lives and save lives

and w/o economy, live saving is impossible as we can't have money to save those people

### Data problem

1 false data not pd, bad data not pd either as they are not identifiable and related -- and they are also mainly produced by the fake investigation data not pd

2 we decrease data breach of **80%** by having a better password

### Agri

the companies monopoly & doing bad things: 

there are lots of companies apart from that companies, just for example in China, such as Mecai we've mentioned.

2.3 trillion dollars, billions of people from extreme hunger

### Healthcare problem & Epidemic

1 anti-vaccination: nothing to do with pd as anti-vaccination is not targetted to person, only the overall thing with tech companies.

2 no alternatives, successful examples (China, Singapore, Korean, ...)

3 gover: tech collect and operate, not govt

3 stop a great epidemic, which could cause millions of people's death

### Discrimination & Humanitarianism Aid

1 100 thousands victims from human trafficking

2 1.5 millions refugee to jobs

3 predict poverty 90% accuracy

4 machine bias more easier to find & fix than human





# YK Pao XW CON

# Rebuttal

## FW

on all aspects

# 1

## Contention 1 healthcare

### develop cure

> https://www.ehrinpractice.com/ehr-failure-statistics.html

Medication-ordering functionality failed to flag potentially harmful drug orders in 39 percent of cases in a test simulation.

Overall, the majority of surveyed physicians reportedit had a negative impact on the clinical productivity.

### accessbility

**health monopoly which leads to higher price**

​	As hospitals and tech companies collect too much data and monopoly the research of medical field, this will cause health monopoly.

​	A recent and widely discussed [study](https://healthcarepricingproject.org/papers/paper-1) by Yale economist Zack Cooper has found that if you stay in a monopoly hospital, your bill will be $1,900 higher on average. That's unaffordable for the poor people.

### Epidemic

inaccuracy

> www.forbes.com/sites/zakdoffman/2020/04/12/forget-apple-and-google-heres-the-real-challenge-for-covid-19-contact-tracing/#4ea517ec2709.

​	If the users using this is below 60% the it “would endanger the quality of the data and its core functionality, ..., providing more false security than actual support fighting the virus..

later worse (location)

> https://www.forbes.com/sites/daniellecitron/2014/12/24/beware-the-dangers-of-location-data/#1caf1b2643cb

​	As AG Harris [told](http://www.usatoday.com/story/news/nation/2014/12/22/california-attorney-general-smartphone-wawrning/20778295/) USA Today, "Expose of location data can sometimes expose you and your family to risk of theft or physical harm. …

### Wearable things diabetes

health fraud --> make it worse

100 million people health data breach 2015 -> health fraud. According to [FDA](https://www.fda.gov/consumers/health-fraud-scams), health fraud scams waste money and can lead to delays in getting proper diagnosis and treatment. It could be worse for diabetes patients

## police prevent crime

1 crime

criminal use data to escape

> Datanami, October 12, 2016 https://www.datanami.com/2016/10/12/criminals-are-using-big-data-tech-and-so-should-you/

​    “The sophistication, agility, and speed at which a cybercriminal operates and monetizes their fraudulent information have improved through the use of data analytics,” Kate McGavin, a senior product marketing manager at RSA, wrote.



2 terrorism

cause it: contention 3 about extrememsm



# 2 economy

all sorts of things

data breach (6 trillion)

### Efficeincy

1 benefit about consumers

consumers don't want

Compared with 2018, people demonstrated somewhat **more resistance to sharing personal data**.

A whopping 78 percent of U.S. citizens think that a brand should not use their personal data to market to them.

2 development

monopoly make less innovation as the less of competition





## Monopoly & Innovation

startup decline 22%, birth rate smaller than death rate -- less competitors for tech giants

mentioned, 60% close down

mentioned in constructive, more money on Washington lobbying than innovation

less innovation

## Healthcare

1900 dollar highr on average for all people-- still exist and not affordable

still can't goto hospital

fail to recognize hamrful medicine

health fraud make it worse

in the early period of china -- didn't use it and get quite well

use location data of epidemic -- stalking & physical harm

## Crime & extremism

crime usage -- crime get data from data breach -- tech comapny

they use data to manipulate and target you to beleive them

make it worse about extremism

## Economy

cyber stalking -- danger 

cybercrime -- 6 trillion

consumers -- they don't want



millions of hate speechs, thousands of death

6 trillion dollarsn







# SHFLS GC

# Rebuttal

## FW healthy&stable society

data: link to ind

tech: development & manufacture, service

## Contention 1 privacy

selling & breach

> How much financial loss?  How many crimes are produced because of data leak? How many people died because of that? NO EVIDENCE

> data safer -- biometrics
>
> pd -> biometrics protection
>
> > https://duo.com/decipher/stop-the-pwnage-81-of-hacking-incidents-used-stolen-or-weak-passwords
>
> ​	According to the 10th edition of the Verizon Data Breach Investigations Report, 81 percent of hacking-related breaches leveraged stolen and/or weak passwords.
>
> > https://www.forbes.com/sites/louiscolumbus/2020/03/08/why-your-biometrics-are-your-best-password/#70fb4a0a6c01
>
> ​	Biometrics are proving to be better than passwords because they’re easier to use, provide greater privacy and security
>
> > https://samsungnext.com/whats-next/why-biometrics-are-on-track-to-replace-the-password/
>
> ​	“It disrupts a hacker’s attack vector,” he says, “as they can no longer focus on huge server stockpiles of user credentials." And make it much safer.

crime: 

>Tech companies using data to form crime detection AI and in LA, because of that, we saw a 33% drop in burglaries, 21% decrease in violent crime and 12% reduction in property  crime. According to Kaspersky, this data analytical systems can successfully cope wit predicting street crimes, street riots and acts of terrorism.

> r	And this prediction accuracy is also high, according to RUSI's report said that it can predict by 88 percent accuracy, much higher than man can do.



## Contention 2 monopoly

> **Benefit of some good monopoly**

> https://www.economicshelp.org/blog/265/economics/are-monopolies-always-bad/

> According to EconomicsHelp

> 1 Lower average cost

> ​	<font color = green> Small firm has higher average costs, while increasing output which is those big tech leads to lower average costs.</font>

> ​	And that means those companies can provide us with cheaper products.

> 2 More innovation

> ​	1 More incentive to innovate

> ​	The monopoly power of patent provides an **incentive** for firms to develop new technology.

> ​	2 More money to innovate

> ​	<font color = green>Also, monopolies make supernormal profit and this supernormal profit can be used to fund investment which leads to **improved technology and dynamic efficiency**.</font>

> ​		It has positive signiﬁcant impact on both new product and new process innovations. The eﬀect is large in magnitude increasing the probability of new product innovation by 31%。

unemployment

> jobs: we provide jobs
>
> 1.5 million for refugees 
>
> African people: we save them









# Constructive PRO

## FW



## Contention 1 Epidemic

Korean, China, Singapore ...

millions of people's lives

> prevention > cure
>
> > we provide prevention by using this
>
> normal illness
>
> > they can't provide other ways to cure normal illness
> >
> > while we give refugees and poor financial support, we help them
>
> govt usage: tech companies collect data and anylyse

## Contention 2 Agri

#### Sustainable Agri

2.3 trillion

#### Suply Chain

1.5 trillion

> poor
>
> > many poor people died of hunger -- and we're using this to save them

## Contention 3 Humanitarianism Aid

#### Poverty

90% (1 billion people)

#### Human Trafficking

100 thousand every year

#### Refugee

1.5 million

> AI bad
>
> > We don't use AI!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

--> no valid rebuttal





no evidence througout the debate to prove that monopoly & data breach make the poor people better

AI: the only thing we do is to analyse things using AI, with no need to replace the human

## Data safety

biometrics reduce **$80$ percent** of the breahces

no evi

## Health & Disease

mask & no go out

> pd help, and reduce death
>
> our opponent is giving up chances to reduce death of people

AI: we only use AI to analyse, not replace jobs

## Poor people's lives

agri: never mentioned anything about AI in that point, so rebuttal invalid

2.3 trillion + 

impact



