vs BJ academy:

1 at fighting frauds

2 at preventing crime

3 at predicting poverty

4 democracy impact of political manipulation not mentioned earlier

5 their at technology monopoly: non uniqueness, monopoly good competition bad, impact small

6 their at political manipulation: impact small, possibility low

7 their at data breach: magnitude small, users don't harm too much, non uniqueness



vs BJ keystone

1 at predicting poverty and refugees

2 at consumers' and companies' experience

3 their at technology monopoly: still other companies who managed to survived

4 their at data breach: impact small

5 their at political manipulation: evidence to show "how many votes are changed"



they both seems to care a lot about predicting poverty and saving lives...

