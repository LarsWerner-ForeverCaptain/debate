## FW:

provide technology service

pd: identifiable

social vs individual harm

# Reb 1 emergency response

> depth of surrounding water (not personal)
>
> location data: I send my location data to the government saving group, what does it have to do with ...
>
> no need for tech companies to keep it



# Reb 2 personalization

medical thing

> hospital not tech company
>
> now the medical things is recorded on a book, which can replace the personal data recording in technology companies
>
> healthcare data breach: <font color = green>113.2 million people were affected by health data breaches in 2015, and there was an 80% increase in the number of people affected by health data breaches from 2017 to 2019.$^{[3]}$</font> That shows our health data will have high possibility to face data breach, leading to the leak of personal health information. Then, health fraud and scams can happen. 

cost reduction

> > [7] Gonzalez-Miranda, Maria. 5-29-201 https://www.marketwatch.com/story/how-big-data-and-online-markets-can-lead-to-higher-prices-2018-05-19
>
> **Price will higher, Target Pricing**
>
> ​	Online retailers use consumers’ internet activities and other personal data to deliver “targeted pricing.” 
> ​	Indeed, if you search online for a more expensive car or a more expensive vacation, that fact will be documented by tracking cookies or other means of online surveillance. And with these data, digital advertisers and retailers will offer you more expensive watches, home furnishings, or airline tickets than they would to a lower-income user searching within the same categories. $^{[7]}$

# Reb 3 unemployment

target unemployment

> government not technology companies
>
> data provided by tech companies: if i provide a book for my friend, does that mean I use that book?,1





## FW

location data is

# Cons 1 political manipulation

> it can't
>
> no internal link
>
> 0.2% more likely to do so
>
> no trusting ads
>
> non-unique

# Cons 2 data breach

> blockchain
>
> no internal link





| data safety                                                  |      |      |
| ------------------------------------------------------------ | ---- | ---- |
| blockchain fail<br>no evidence about <br>how many companies use data |      |      |
|                                                              |      |      |
|                                                              |      |      |

| personalisation & <br>manipulation                    |      |      |
| ----------------------------------------------------- | ---- | ---- |
| 300 million                                           |      |      |
| we've mentioned the war<br>and people are manipulated |      |      |
|                                                       |      |      |

| government use of data                                       |      |      |
| ------------------------------------------------------------ | ---- | ---- |
| government get the data<br>w/o the help of tech company<br>for the emergency<br>government just get the location data |      |      |
|                                                              |      |      |
|                                                              |      |      |

