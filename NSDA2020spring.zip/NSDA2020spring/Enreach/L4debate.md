| PRO              | constr/rebut                                                 | cf                                             | sum                                                          | ff   |
| ---------------- | ------------------------------------------------------------ | ---------------------------------------------- | ------------------------------------------------------------ | ---- |
| fw               | individual                                                   |                                                |                                                              |      |
| c1 healthcare    | accuracy&flexibility<br>financial friendly<br>save hc spending<br>link of diseases | evi: eco<br>blockchain                         | save money<br>at data br: no imp<br>blockchain               |      |
| c2 AI            | AI need data<br>SA: business<br>  targeted serv&ad<br>SB: crime prevent<br>  evi: drop crime rate | how long take to search<br>find things quickly | inc selling<br>no evi about targetted ads<br><br>only in movie |      |
| at c1 privacy    | no impact<br/>anonymous<br/>whether share                    |                                                | they are same<br>no imp/wa                                   |      |
| at c2 data equal | same contention<br/>why will predict                         |                                                | same with c1                                                 |      |
|                  |                                                              |                                                |                                                              |      |

| CON                      | constr/rebut                                            | cf                          | sum                                 | ff                              |
| ------------------------ | ------------------------------------------------------- | --------------------------- | ----------------------------------- | ------------------------------- |
| fw                       | CBA (not only ind & fin)                                |                             | their short sight                   |                                 |
| c1 privacy               | consent loophole<br>selling data<br>advertising         |                             | not same<br>                        | violation$\not =$ surv          |
| c2 surveil<br>data equal | data = money?<br>data purchase<br>advertising<br>profit | =surveiliance<br>predicting | taobao not<br />prevention of crime |                                 |
| at c1hc                  | medical data breach                                     | only 1 eg                   |                                     |                                 |
| at c2 ai                 | SA: useless<br>  fraud<br>SB: misdetect<br>  tyranny    | safety/<br>convenience<br>  |                                     |                                 |
|                          |                                                         |                             | data breach<br>blockchain no safe   | fraud: have evidence and impact |





# Contention 1 privacy

**GDPR**

​	GDPR requires a positive opt-in and opt-out, it also requires that individuals can withdraw their data at any time to protect their privacy.

​	Explicit consent requires a very clear and specific statement of consent, Keep your consent requests separate from other terms and conditions.

​	***(CF: loophole in GDPR)***

loophole (no loophole found in gdpr)

GDPR is european union law, almost all companies need to trade with european countries, so they have to obey





discrimination

**LAWS**

Civil Rights Act of 1964

**IMPACT**

no evidence about how many

**Prevent**

https://it.toolbox.com/guest-article/how-to-prevent-data-discrimination

data algorithm transparency

http://www3.weforum.org/docs/WEF_40065_White_Paper_How_to_Prevent_Discriminatory_Outcomes_in_Machine_Learning.pdf

monitor, refine algorithm





# Contention 2 small business

 **there are still small companies who can grow in the so-called monopolies of big companies**

​	The first tech giant so-called "monopoly" is Google. But after that, a small company called Facebook stood up, and now became a well-known one. 

​	Under the monopoly of western monopolies of Apple, Microsoft, Android etc. Huawei, which used to be a small company, stood up, and now is well-known all over the world.

​	Under the monopoly of Weibo and Music Ly, Tik-Tok stood up and quickly became famous among young people.

​	The number of small companies who stood up among monopolies are countless. This makes sure that the new companies have high quality and innovation. 

​	So, so-called "monopoly" doesn't mean that small companies can't grow and stand up, and our opponent has a main misunderstanding about that.

**no evidence about increasing**

 	The share of all businesses that are new firms has fallen since 1978 according to Atlantic. THis happened very early

**impact**



## Clashes

**Consumers and business **

privacy (not mentioned)

small business (not link)

**Lives saving and economy**



