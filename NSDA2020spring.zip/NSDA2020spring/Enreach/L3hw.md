



## Data breach

​	A data breach is the intentional or unintentional release of secure or private information to an untrusted environment, or more commonly, dark net. Hackers can get all your private data from data breach which can be realized by Ransomware, Malware, Phishing, Denial of Service. <font color = \#0000FF> According to Forbes, Data breaches exposed 4.1 billion personal records in the first six months of 2019.  And according to Statista, There was an 80% increase in the number of people affected by health data breaches from 2017 to 2019, showing that the data breach is becoming more and more severe. </font>

​	Data breach could lead to calamitous impact. First, loss for individuals. The loss of personal data can lead to frauds and scams.<font color = \#0000FF> According to FDA, frauds and scams waste money and can lead to delays in getting proper treatment, and according to Competition Bureau of Canada, they can put your health at significant risk.</font> Most of the victims are elder people as they can't recognize such fraud, which means our opponent's resolution is abandoning those elder people's money and health. Second, loss for companies and overall economy. <font color = \#0000FF> According to the [2018 Cost of Data Breach Study](https://blog.netwrix.com/2018/11/29/what-to-know-about-a-data-breach-definition-types-risk-factors-and-prevention-measures/), the average cost of a data breach in the U.S. is $7.91 million and according to Norton, there’re more than 3800 of them in the first half of 2019. </font> This is going to be a greater financial lass in 2021 as <font color = \#0000FF> According to Herjavec Group, It is estimated that a business will fall victim to a ransomware attack every 11 seconds by 2021. </font> This can lead to the great financial loss or even bankruptcy for small companies, resulting in the rise of unemployment rate and decrease in economy. 

## 